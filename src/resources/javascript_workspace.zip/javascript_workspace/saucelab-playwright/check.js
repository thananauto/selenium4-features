// function to calculate two dates  
