import { expect, test as setup } from "@playwright/test";

import { dbSingleton } from "@utilities/mongoclient";

setup("Initiate the mongo DB connection", async () => {
  console.log("set up DB client instance ......");
  //const dbclient = Object.freeze(await MongoClient.getInstance())
  // expect(dbclient).not.toBe(undefined)
 await dbSingleton.initClient();
  //expect(client).not.toBe(undefined);
});
