import { expect, test as teardown } from "@playwright/test";

import {
  dbSingleton as MongoClient,
  dbSingleton,
} from "@utilities/mongoclient";

teardown("Initiate the mongo DB connection", async () => {
  console.log("clean up ");
  //const dbclient =await (await MongoClientSingelton.getInstance()).closeConnection()
  //expect(dbclient).toBe(undefined)
  const client = await dbSingleton.closeConnection();
  expect(client).toBe(undefined);
});
