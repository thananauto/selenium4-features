import { dbSingleton } from "@utilities/mongoclient";

async function teardown() {
  console.log("clean up ");
  //const dbclient =await (await MongoClientSingelton.getInstance()).closeConnection()
  //expect(dbclient).toBe(undefined)
  const client = await dbSingleton.closeConnection();
}

export default teardown;
