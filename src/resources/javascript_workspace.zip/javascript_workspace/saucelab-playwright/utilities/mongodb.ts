import { MongoClient, ServerApiVersion } from "mongodb";
import { EJSON, ObjectId } from "bson";
import dotenv from "dotenv";
dotenv.config();

interface Student {
  _id?: ObjectId;
  first_name: string;
  last_name: string;
  major: string;
  age: number;
}

class MongoClientSingelton {
  private static singelton: MongoClientSingelton;

  private client: MongoClient;

  private constructor() {
    console.log("constructor called!");
    this.client = new MongoClient(process.env.DB_CONN_STRING as string, {
      serverApi: {
        version: ServerApiVersion.v1,
        strict: true,
        deprecationErrors: true,
      },
    });
    console.log("successfully created");
    this.client.connect();
  }

  static getInstance(): MongoClientSingelton {
    if (!MongoClientSingelton.singelton) {
      MongoClientSingelton.singelton = new MongoClientSingelton();
    }
    return MongoClientSingelton.singelton;
  }

  async closeConnection() {
    if (this.client) {
      console.log("successfully closed");
      await this.client.close();
    }
  }

  async readStudent(studentname: string) {
    const result = await this.client
      .db(process.env.DB_NAME as string)
      .collection(process.env.COLLECTION_NAME as string)
      .findOne<Student>({ first_name: studentname });
    if (result) {
      const student = EJSON.stringify(result);
      const stu: Student = JSON.parse(student);
      delete stu._id;
      return stu;
    } else {
      throw Error(`No result returned for Student ${studentname}`);
    }
  }
}

const mongo = MongoClientSingelton.getInstance();
function GetDetails(name: string) {
  return function (target: Object, key: string | symbol) {
    let originalVal: any = target[key];

    const getter = async () => originalVal;
    const setter = async (next: string) => {
      console.log("Inside setter");
      console.log(next);
      originalVal = await mongo.readStudent(name);
    };
    Object.defineProperty(target, key, {
      get: getter,
      set: async () => await mongo.readStudent(name),
      enumerable: true,
      configurable: true,
    });
  };
}

function fullName(title: string) {
  return function (target: Object, key: string | symbol) {
    let val: any = target[key];

    const getter = () => val;
    const setter = (next: string) => {
      val = title + " " + next;
      console.log(val);
    };

    Object.defineProperty(target, key, {
      get: getter,
      set: setter,
      enumerable: true,
      configurable: true,
    });
  };
}

function fullFlavour(stuName: string) {
  return function (
    target: Object,
    name: string | symbol,
    descriptor: PropertyDescriptor,
  ) {
    const original = descriptor.value;

    descriptor.value = async function (...args: any[]) {
      //args[0] = toppins + args[0]
      console.log(`Args are : ${args[0]}`);
      args[0] = await mongo.readStudent(stuName);
      return original.apply(this, args);
    };

    return descriptor;
  };
}

class GetDB {
  //@GetDetails('Vijay')
  // stu: Student

  // constructor (student: Student){
  //    this.stu = student
  //  }

  @fullFlavour("Vijay")
  async getStudent(name: string) {
    console.log(`Modified OP `);
    console.log(name);
    return name;
  }
}
async function test() {
  const mongo = MongoClientSingelton.getInstance();
  //const op = await mongo.readStudent('Vijay')
  //console.log(op)
  let ddb = new GetDB();
  const result = await ddb.getStudent("Kumar");
  console.log(result, "write");
  await mongo.closeConnection();
}
