const axios = require('axios');
require('dotenv').config();
(async () => {
  
    //credentails encoding
    const username = process.env.BROWSERSTACK_USERNAME;
    const password = process.env.BROWSERSTACK_ACCESS_KEY;
    const encoded = Buffer.from(username + ':' + password).toString('base64');

    //get the build details
    const response = await axios.get('https://api.browserstack.com/automate/builds.json', {
        headers: {
          'Authorization': 'Basic ' + encoded
        }
      }
    )
     
     let json = await response.data
     json = json.filter(item => item.automation_build.name === 'Test_Tue_Nov_19_2024');
     console.log(json[0].automation_build.hashed_id);
    let hashed_id = json[0].automation_build.hashed_id
    //get the public url from each session of build
    const session_response = await axios.get(`https://api.browserstack.com/automate/builds/${hashed_id}/sessions.json`, {
        headers: {
            'Authorization': 'Basic ' + encoded
          }
    })

    let session_json = await session_response.data
    let publicUrl = session_json.filter(item => item.automation_session.name === 'Login with valid credentials')
    publicUrl = publicUrl[0].automation_session.public_url
    console.log(publicUrl);
    
 
})();
      