// Import Playwright
const { chromium } = require('playwright');
const { expect } = require('@playwright/test');


require('dotenv').config();

(async () => {
  // Launch the browser
        const browser = await chromium.launch({ headless: false }); // Set to `true` for headless mode
    
        const context = await browser.newContext();
        const page = await context.newPage();

  // try code snippet over there
  await page.goto('https://www.corporategear.com/consultation.html')
  await page.waitForTimeout(3000)

  await page.locator('#message').scrollIntoViewIfNeeded()

  const locator =  page.frameLocator('iframe[title="reCAPTCHA"]').locator('.recaptcha-checkbox-checkmark')
  await locator.click({ force : true })
await page.waitForLoadState('domcontentloaded')
  await page.waitForTimeout(3000)
  await expect(page.locator('img')).toHaveText(
 
  
  //await page.close()
  //await context.close()
  //await browser.close()
  
})();

