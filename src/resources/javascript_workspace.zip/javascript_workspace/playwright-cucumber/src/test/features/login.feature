Feature: Validate the sauce lab login Feature

Background: Log in to application
    Given Launch the sauce lab application
    When Login with the username 'standard_user' and password 'secret_sauce'
    
Scenario: Validate the home page
    Then Home page should be displayed

Scenario: Add and item to cart
    And Click an item to cart
    Then User should see the product listing page
    And Item should be in cart page
