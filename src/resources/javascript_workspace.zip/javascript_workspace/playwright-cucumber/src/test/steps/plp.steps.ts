
import{ Then, When } from '@cucumber/cucumber'
import { expect } from '@playwright/test'
import { pageFixture } from '../../hooks/fixture'


Then('User should see the product listing page', async function () {
    await expect( pageFixture.page.locator('.title')).toBeVisible()
  });

  When('Click an item to cart', async  ()=> {
    await pageFixture.page.getByRole('button', { name: 'Add to cart'}).first().click()
  });



  Then('Item should be in cart page', async ()=> {
    const itemCount = await pageFixture.page.locator('.shopping_cart_badge').innerText()
    console.log(`Item count ${itemCount}`)
    expect(Number(itemCount)).toBeGreaterThan(10)
  });