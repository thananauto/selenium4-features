// Base class with some properties and methods
class Animal {
    constructor(public name: string, public age: number) {}
  
    makeSound(): void {
      console.log('Some generic animal sound');
    }
  }
  
  // Interface extending the class Animal
  interface Dog  {
    breed?: string; // New property specific to the Dog interface
    legs(): void
  }
  
  class Puppy extends Animal implements Dog  {
      breed?: string | undefined;
      legs(): void {
          throw new Error("Method not implemented.");
      }
     
      
    
  }
  
  // Implementing the interface in a class
  class Bulldog implements Dog {
    name: string;
    age: number;
    breed: string;
  
    constructor(name: string, age: number, breed: string) {
      this.name = name;
      this.age = age;
      this.breed = breed;
    }
      legs(): void {
          throw new Error("Method not implemented.");
      }
  
    makeSound(): void {
      console.log('Woof!');
    }
  }
  
  // Using the Bulldog class
  const myDog = new Bulldog('Max', 4, 'Bulldog');
  console.log(myDog.name); // Output: Max
  console.log(myDog.breed); // Output: Bulldog
  myDog.makeSound(); // Output: Woof!
  