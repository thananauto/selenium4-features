import  GlobalConfig  from "./global.config";
import { setWorldConstructor, World, IWorldOptions } from '@cucumber/cucumber';

 class CusWorld extends World implements GlobalConfig{
    

   
    debug = false
    pageUrl = 'HTTP:localhost'
    
}
setWorldConstructor(CusWorld);

export { CusWorld }