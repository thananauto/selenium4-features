import { Before, After} from '@cucumber/cucumber'
import * as chai from 'chai'
import { Given, When } from '@cucumber/cucumber'

var expect = chai.expect
Before(async function ( { pickle }) {
    //setting the value
    this.a = 8
    this.b = 5
  
})

After(async function ({ pickle, result }) {
    //logging status
    
        if(result?.status){
            this.log(result?.status)
        }
    //logging exception
        if(result?.exception){
            this.attach(result?.exception?.message as string, 'text/html')
        }
        
})

Given('Check the value of `A`', async function () {
    expect(this.a).to.be.eq(8)
})

When('Check the value of `B`', async function () {
    expect(this.a).to.be.eq(5)
})