//class and inheritance

console.log('.............. <> ................')

type IStudent = {
    boys: number
    girls: number
    staff: number
  //  getStudentStaffRatio(): number
  //  getTotal():number
}


class School {
    readonly student: Student 
    private standard: string
    private section: string
    private floor: number

    constructor(student: Student, standard: string, section: string, floor : number){
            this.student = student
            this.standard = standard
            this.floor = floor
            this.section = section
    }

    getStandard = () => this.standard;
    getSection = () => this.section;
    getFloor = () => this.floor;

}

//class as interface with as constructor parameter
class Student  {
   private _students: IStudent

    constructor(boys: number, girls: number, staff : number){
        this._students = { boys, girls, staff}
    }
   
    getStudentStaffRatio(): number {
        return (this._students.boys + this._students.girls)/this._students.staff
    }


    
    getTotal(): [number, number] {
         return [this._students.boys , this._students.girls]
    }

}

let s1= new Student(17,12,2)
let c1 = new School(s1, '5th', 'IX', 3)


console.log(s1.getStudentStaffRatio())
console.log(s1.getTotal())
console.log(c1.getFloor())

 