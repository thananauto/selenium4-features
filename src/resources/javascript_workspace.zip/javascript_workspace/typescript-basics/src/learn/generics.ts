//generics

console.log('.......... <> ...........')

//function

function combine<T extends number | string> (a: T, b: T):T{

    return a as any + b as any
}

let c11 = combine('World', 'hello')
console.log(c11)

let c12 = combine(4, 9)
console.log(c12)


//classes
class Addition1<T>{
    private items: T[] =[]

    pushItem(item: T){
        this.items.push(item)

    }

    popItem():T{
        return this.items.pop() as any
    }

}
const add1 = new Addition1<string | number>()
add1.pushItem(3)
add1.pushItem(5)
add1.pushItem('dsfs')
console.log(add1.popItem())

 //@ts-ignore: 
function sumpsUp < T extends number | number[]>(a: T , b: T ){

    if(Array.isArray(a) && Array.isArray(b) ){
        return a.map((v, i)=> v + <number>b[i]) as T
    }else{
        return <number>a + <number>b
    }

}
console.log(sumpsUp(4,5))
console.log(sumpsUp([4,5], [8,9]))