//promises

console.log('------------- <> --------')
let a = 9
let b = 7

let getAge = (age: number)=> new Promise((resolve, reject)=>{
   
    setTimeout(()=>{

        if(a>b){
            resolve(`Age is ${age}`)
        }
        else{
            reject(new Error('Age is false'))
        }
    }, 1000)

})

 function checkNum(){
return new Promise((resolve, reject)=>{

    setTimeout(()=>{

        if(a<b){
            resolve(a)
        }
        else{
            reject(new Error('Both are not equal'))
        }
    }, 1000)
})
}
  checkNum().then(e => {
     return getAge(e as number)
    })
    .then(x => console.log(x))
    .catch(x=>console.error(x.message))
    .finally(()=> console.log('successfull'))

console.log('Completed')

