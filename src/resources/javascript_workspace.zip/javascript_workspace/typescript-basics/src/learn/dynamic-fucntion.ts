
let add = (a: unknown, b: unknown) =>{
    if( typeof a == 'number'&& typeof b == 'number'){
        return a+b
    }else if( typeof a == 'string'&& typeof b == 'string'){
        return a+b
    }else if( typeof a == 'object' && typeof b == 'object'){
        if(Array.isArray(a) && Array.isArray(b)){
            return [...a, ...b]
        }
        return {...a, ...b}

    }
    return null
}


console.log(add(4,'5'))
console.log(add("4","5"))
console.log(add([1,2,4],['1','5']))
console.log(add({a:1},{ b:1}))
console.log('------------')
//variable scoping Block and fucntion scope


var x =1

function getX(){
    var x=1
   
    if(x){
       
        console.log(`value of ${x}`)
       
    }else{
        console.log(`value of ${x}`)
    }
    console.log(++x)
}


getX()
console.log(++x)

console.log('------------')