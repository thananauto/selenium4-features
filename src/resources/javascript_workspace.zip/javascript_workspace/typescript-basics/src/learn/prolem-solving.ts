const reverseAndReplace =() =>{
    let msg = 'Hello welcome to India'

    return msg.split(" ")
                .map(item => item.split('').reverse().join(''))
                .join(' ')
                .replace(/ /ig, '%')
}

//find a prime number

const primeNumbers = () =>{
    let ip = [2, 3, 25, 9,4,6,34,67,89]

    return ip.filter(num =>{
        if(num <= 1){
            return false
        }else{
            for(let i=2; i<=Math.sqrt(num); i++){
                if(num%i==0){
                    return false
                }
            }
        }
        return true;
    })
}

//reverse a number

const revNumber =() =>{

    let ip = 639
    let op = 0

    while(ip>0){
        let ld=ip%10
        op =op*10 + ld

        ip = Math.floor(ip/10)
    }
    return op
}

console.log(revNumber());

//reverse a string

const revString = () =>{
    const ip ='Hellow'
    let op = ''
    for(let i of ip.split('')){
        op = i + op
    }
    return op
}
console.log(revString());

