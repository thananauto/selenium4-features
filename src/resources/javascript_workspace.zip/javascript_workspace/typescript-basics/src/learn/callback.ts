//--- callback function


interface Details {
    id: number,
    email: string,
    first_name: string,
    last_name: string,
    avatar: string,
    age?:number
}

console.log('......... <> ........')
let users = async (callback: Function) =>{

    await fetch('https://reqres.in/api/users')
            .then(async data => {
                callback(data)
                })
            .catch(error => console.log(error))
            .finally(()=> console.log('successfully completed'))

    console.log('Executing methods')
}

async function processData( data: any){
    const json = await data.json()

    //iterate all response
    json['data'].forEach((element : Details) => {
        console.log(`The full name is ${element.first_name} and ${element.last_name}`)
    });
    //filter the json
   const filtop = json['data'].filter((e:Details)=>e.id >4)
   console.log(filtop)

   //get all the names
   const names:{ name: string, email: string} = json['data'].reduceRight(getNameAndEmail, {})
   console.log(names)

   //adding all elements with age
   const op:Details[] =json['data'].map((ele:Details)=>{
    ele['age'] =20
    return ele
   })
   op.forEach((e:Details) => console.log(e))
   const op1:Details[] =json['data'] as Details[]
}

function getNameAndEmail(accumulator: any, currentValue: Details) {
    accumulator[currentValue.first_name+' '+currentValue.last_name] = currentValue.email
    return accumulator
  }

users(processData)



