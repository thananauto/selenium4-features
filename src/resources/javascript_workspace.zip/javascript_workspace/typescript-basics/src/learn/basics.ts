var name1: String ="Hello worldczxcv "
var age = 32


console.log(name1)
console.log(2)
console.log("----------")

//duck typing

type pupil = {
    name: string,
    age: number,
    address: object
}

let person: pupil ={
    name: 'Thanan 123',
    age : 40,
    address: ['habibullah', 'dasd', 'das']
}


console.log(person)


Object.entries(person).forEach((k,v)=>{
    console.log(`${k} ${v}`)
})


for(const key in person){
    console.log(`${key} --> ${person[key as keyof typeof person]}`)
}

//enum

enum Size {

    SMALL,
    MEDIUM,
    LARGE,
    XXL,
    XXXL
}

const getDetails = ( size: Size) =>{
    console.log('Get the dress size ' +Size[size])
}

getDetails(Size.MEDIUM);
//default and optional parameters

var getDateDiff = (noOfDays? : number ) =>{
    noOfDays = noOfDays == null ? 6 : noOfDays
    let  date =new Date()
    date.setDate(noOfDays)
    date.setFullYear(2002)
    return date.toLocaleDateString()
}

console.log(getDateDiff())


console.log('------------')
