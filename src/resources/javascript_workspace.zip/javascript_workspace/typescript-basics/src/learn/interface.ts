//interfaec

interface Person {
    firstName: string,
    
}
interface Person {
   
    age: number,
    mark?: number
}

interface Salary extends Person {
    month? : number
}

let p1 = (person : Salary) => console.log(`Name: ${person.firstName} and Age: ${person.age}`)

let p2 = (person : Salary) => console.log(`Name: ${person.firstName} and Age: ${person.age} and my mark ${person.mark}`)
let p3 = (person : Salary) => console.log(`Name: ${person.firstName} and Age: ${person.age} and salary ${person.month}`)

let ip: Person ={firstName: 'Thanan', age: 40}
p2(ip)
p1(ip)
console.log('----------- <> --------')

