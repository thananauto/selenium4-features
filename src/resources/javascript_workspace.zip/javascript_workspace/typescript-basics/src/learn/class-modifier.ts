// class modifier

console.log('............. <> ............')
class Car {
    protected year: number

    constructor(year: number){
        this.year = year
    }
     displayYear(){
        console.log(`Display year from CAR ${this.year}`)
    }

    getYear (){ return this.year };
}

interface Check {
    getYear(): number
    carDetails(): void
}

class Audi extends Car implements Check {

   private model: string
   private color: string
   // year: number
    constructor(model: string, color: string, year: number)
    {
        super(year)
        this.color = color
        this.model = model
    
    }
        carDetails(){
            console.log(`Color: ${this.color} and Model: ${this.model}`)
        }

        displayYear(){
            super.displayYear()
            console.log(`Display year from AUDI ${this.year +2}`)
        }

        getYear()  {
        super.getYear()
         return this.year + 1};
}

let a1 = new Audi('x6', 'blue', 2020)
console.log(a1.getYear())

a1.displayYear()
a1. carDetails()

