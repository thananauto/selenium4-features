//function
console.log(' --------- <> ----------')
var name = 'Kumar'
let pupil = {
    name: 'Thanan',
    age: 20,
    greet:function(){
        return this.name
    },
    getName : () => name

}

console.log(pupil.greet())
console.log(pupil.getName())