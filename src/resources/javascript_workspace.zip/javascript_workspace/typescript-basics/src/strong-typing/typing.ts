
import { valueOfPi } from "./constants";
 
export const twoPi = valueOfPi * 2 * 4 *10;

var name: String ="Hello worldczxcv "
var age = 32
console.log(twoPi)

console.log(name)
console.log(2)
console.log("----------")

//duck typing

