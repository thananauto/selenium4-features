console.log('--------<>----------')
//valid palindrome

const palindrome = (str: any)=>{

    //replace non alpha numberic character
    str = str.replace(/[^a-zA-Z0-9]/g,'')
    console.log(str)

    if( typeof str === 'string'){
        const arr =str.toLowerCase().split("")
        for(let i=0; i< Math.abs(arr.length/2); i++){
            if(arr[i]!= arr[arr.length-1 - i]){
                    return false;
            }
        }
    }
    return true;

}

//console.log(`Give string Malayalam `+palindrome('Malayala$%^#m'))

//check two string is valid anaghram

const anagharam = (str1: string, str2: string)=>{
    //str1 = 'hello' str2 = 'lloeh
    if(str1.length != str2.length)
        return false
   
    let op= str2.split('')
    str1.split("").forEach(e=>{
        str2 =str2.replace(e, '')
    })


    return str2.length == 0
}

console.log('Anagharm of listen and silent', anagharam('listen', 'silent'))

let x2 = [ 0, 1, 22, 3, 4 ]
console.log(Array.from({length: 5}, (_, i)=> x2[i]))

//find the missing number

const missingNumber = (arr1: number[]) =>{

    const min = Math.min(...arr1)
    const max = Math.max(...arr1)

    const fullrange = Array.from({ length: max - min+1},(_, i) => min+i)

    return fullrange.filter(num => !arr1.includes(num))
}
let op = missingNumber([32, 34, 31, 40])
console.log(op)

// find sum of two numbers

const sumoftwo = (arr:  number[], target : number)=>{

   
    for (let i = 0; i < arr.length; i++) {
        const nx  = arr[i] as number
        const complement = target - nx

        if(arr.indexOf(complement)!= -1){
            return [arr.indexOf(complement), i]
        }
    }

}
let ss = sumoftwo([7,2,4, 3,6], 10) 
console.log(ss)