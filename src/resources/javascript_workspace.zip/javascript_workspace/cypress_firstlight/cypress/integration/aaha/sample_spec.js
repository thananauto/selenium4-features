
                              /// <reference types="cypress" />

describe('Aaha First Test', () => {
    xit('Vist the Aaha application video', () => {
      cy.visit('https://www.aha.video/all')


      //bypass the banner
     // cy.get('h4.orange-button__title').eq(1).should('be.visible').click()

     cy.get("body").then($body => {
        if ($body.find("h4.orange-button__title").length > 0) {   
            $body.find("h4.orange-button__title").click()
        }
    });

      //click the sign in button
      cy.contains('Sign In').click()
      

      cy.url().should('include', '/app/login/1')

      cy.get('.mobileForm').type('9087654323')

      cy.contains('Proceed').click()
    })

    it('Navigate all menu bars', () => {
      
       cy.visit('https://www.aha.video/all')
     // cy.get('.header__logo').click()

     cy.get("body").then($body => {
      if ($body.find("h4.orange-button__title").length > 0) {   
          $body.find("h4.orange-button__title").click()
      }
  });


      cy.get('.tab-menu').find('li').contains('Movies').click({ force: true })
      //cy.get('div[id =\'toolbar\']>div>ul').find('li').
      cy.url().should('contain', '/movies')

      cy.get('.tab-menu').find('li').contains('Shows').click({ force: true })
      cy.url().should('contain', '/shows')

      cy.get('.tab-menu').find('li').contains('Kids').click({force : true})
      cy.url().should('contain', '/kids')

      cy.get('.tab-menu').find('li').contains('My aha').click({ force : true})
      cy.url().should('contain', '/app/login/1')




    });
  })