/// <reference types="cypress" />

describe('This is sauce demo test', () =>{


    it('launch the application', () => {
        cy.visit("https://www.saucedemo.com/", {timeout: 4000})
    });

    it('Should fill user details', () => {

      //    cy.url().should('be.a', 'string')
       //cy.wrap(text)
        //enter the username
        cy.get('#user-name').type('standard_user')
        cy.get('#user-name').should('have.value', 'standard_user')

        //enter the password
        cy.get('#password').type('secret_sauce')
        cy.get('#password').should('have.value', 'secret_sauce')

        //submit the login
        cy.get('input[type=\'submit\'').click()

        cy.get('.title').should('have.text', 'Products')
    });
})