##Cypress Firstlight

Start cypress application from root folder `./node_modules/.bin/cypress open`

Run the script from json file using the command `npm run cy:open`
