const { faker } = require('@faker-js/faker')

const users= () => {
    const data = { users: [] }
    // Create 1000 users
   // function userCreation(){
    for (let i = 0; i < 10; i++) {
        console.log('check')

        const employee = {
            id: i+1,
            firstName: faker.person.firstName(),
            lastName: faker.person.lastName(),
            bio: faker.person.bio(),
            sex: faker.person.gender(),
            age: faker.date.birthdate({ min: 18, max: 65, mode: 'age' }),
            job : {
                title: faker.person.jobTitle(),
                description: faker.person.jobDescriptor(),
                type: faker.person.jobType()
            },
            phone: faker.phone.number()

        }

      data.users.push(employee)
    }
    return data
}
  

const helloWorld = () =>{
console.log('Hello world...!!')
}

const secondWorld = () =>{
    console.log('Second world...!!')
}

exports = { helloWorld, secondWorld }