
const {  chromium  } = require('playwright')
const {expect} = require("@playwright/test");
// Or 'chromium' or 'webkit'.


(async () =>{
    
    const browsercontext = await chromium.launch({ headless: false})
    const browser = await browsercontext.newContext()
    
    
    const page = await browser.newPage()
    await browsercontext.startTracing(page, {path: 'trace.json'})
    
    await page.goto('https://amazon.com')
    await expect(page).toHaveURL(/amazon/)
    await  browsercontext.stopTracing()
    await browser.close()
    
})()
