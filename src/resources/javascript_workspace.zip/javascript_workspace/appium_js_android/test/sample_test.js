const wdio = require('webdriverio')
const assert = require('chai').assert

const opts = {
    path: '/',
    port: 4723,
    capabilities: {
      "platformName": "Android",
      "appium:platformVersion": "12",
      "appium:deviceName": "emulator-5554",
      "appium:app": "C:/Projects/java_workspace/firstlight/aha-app.apk",
      "appium:appPackage": "ahaflix.tv",
      "appium:appActivity": "ahaflix.tv.views.MainActivity",
      "appium:automationName": "UiAutomator2"
    }
  };

  describe('Create Aha Android session', function () {
    let client;
  
    before("before",async function () {
      client = await wdio.remote(opts);
      assert.equal(true, true)
      
    });
  
    it('should create and destroy a session', async function () {
      const res = await client.status();
      assert.isObject(res.build);
  
      const current_package = await client.getCurrentPackage();
      assert.equal(current_package, 'ahaflix.tv');
  
      
    });

    after(async function(){
      const delete_session = await client.deleteSession();
      assert.isNull(delete_session);

    });
  });


  
