const suitest = require('suitest-js-api');
const {assert, PROP} = suitest;

(async function myFirstTest() {
    await suitest.openApp();
    await assert.element('logo').matchesRepo(PROP.IMAGE);
    await suitest.closeSession();
})();

myFirstTest().catch(console.error).finally(() => suitest.closeSession());