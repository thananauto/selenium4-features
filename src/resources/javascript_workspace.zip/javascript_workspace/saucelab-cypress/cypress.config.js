const { defineConfig } = require("cypress");

const got = (...args) => import('got').then(({default: got}) => fetch(...args));
//const  got  = require("got")
require('dotenv').config()
module.exports = defineConfig({
  env : {
    'user' : 'thanan'
  },
 

  e2e: {
    chromeWebSecurity: false,
    defaultCommandTimeout: 5000,
    testIsolation: false,
    async setupNodeEvents(on, config) {
      // implement node event listeners here

     // const users = await got('https://api.restful-api.dev/objects').json()

     // const userId =  _.map(users, ele =>{
    //    return _.pick(ele, ['id'])
     // })

     // console.table(userId)
      on('task', {
       // hashMap : {},
        setData : (value) => { return (href = value) },
        getData : ()=>{ return href}
      })
      
      config.env.users = [1,2,3,4]
    
      config.env = config.env || {}

      config.env.FOO1=process.env.FOO1
      config.env.FOO2=process.env.FOO2
      return config
    },
    reporter: 'junit',
    reporterOptions: {
      mochaFile: 'results/my-test-output.xml',
      toConsole: true,
    },
    
  },
});
