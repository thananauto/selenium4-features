/// <reference types="cypress"/>
const users = require('../../fixtures/devices.json')

describe('Dynamic test from fixture', Cypress.config({ 'baseUrl' : 'https://api.restful-api.dev'}),()=>{


    users.forEach(user =>{


        it(`check the each device ${user.name}`, () =>{
                cy.request({
                    'method' : 'GET',
                    'url' : `/objects/${user.id}`
                }).then(res =>{
                    cy.wrap(res).its('status').should('eq', 200)
                    cy.wrap(res).its('body').as('body').should('have.property', 'id').should('eq', user.id)
                    cy.wrap(res).its('body').its('data').should('have.deep.nested.property', 'color')
                    //console.log(body)
                   // cy.wrap('@body').should('have.deep.nested.property', 'Price')
                })
        })
    })
   
})