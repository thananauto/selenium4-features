/// <reference types='cypress'/>
const users = require('../../fixtures/devices.json')
describe('check the wrap behaviour', ()=>{
    beforeEach(() => {
        cy.fixture('devices').as('device')
    });

    it('validate the wrap function', ()=>{

        cy.get('@device').then(res =>{
            console.log(res)
        })

        cy.wrap(users).its('length').should('be.greaterThan', 10)
    })
    
})