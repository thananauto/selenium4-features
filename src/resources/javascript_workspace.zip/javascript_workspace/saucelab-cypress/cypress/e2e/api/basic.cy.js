/// <reference types='cypress'/>

describe('check the regres api get operation',
        Cypress.config({ 
            'baseUrl': "https://api.restful-api.dev"}
        ), ()=>{

            it('reqres get operation', ()=>{

                cy.request('GET','/objects').then(res =>{
                        expect(res.status).to.eq(200)
                        expect(res.body).to.be.an('array')
                        expect(res.body[0]).to.deep.include({"id": "1",})
                        expect(res.body[0].data).to.have.property('color')
                       // cy.log(res.body)
                        //expect(res.body).to.eq(2)
                })

                cy.request('GET','/objects').as('operation')
                cy.get('@operation').its('status').should('eq',200)
                cy.get('@operation').its('body').should('be.an','array')
                cy.get('@operation').its('body[0]').should('deep.include',{ "id" : "1"})
                cy.get('@operation').its('body[0].data').should('have.a.property','color')

            })

            it('search product by query params', ()=>{
                cy.request({ method: 'GET', 
                             url: '/objects',
                             qs : {
                                id : '3'
                            }}).then(res =>{

                               expect(res.status).to.be.eq(200)
                               expect(res.body).to.have.length(1)
                               expect(res.body[0].id).to.be.eq('3')
                               expect(res.body[0].data).to.haveOwnProperty('color')

                            })

        })

        it('post a object', ()=>{

            cy.request({
                method : 'POST',
                url : '/objects',
                body: {
                    "name": "Apple MacBook Pro 16 Silicon",
                    "data": {
                       "year": 2024,
                       "price": 1849.99,
                       "CPU model": "Intel Core i9",
                       "Hard disk size": "1 TB"
                    }
                 }
            }).then(res =>{

                expect(res.status).to.be.eq(200)
                expect(res.body).to.have.a.property('id')
                expect(res.body).to.include({"name": "Apple MacBook Pro 16 Silicon"})
            })
        })
                
           

})