/// <reference types='cypress'/>

describe('Create a dynamic test based on previous test', 
Cypress.config({ 'baseUrl': "https://api.restful-api.dev"}), () =>{

const testIds = Cypress.env('users')

before(() =>{
    cy.request({ 
        'method' : 'GET',
        'url' : '/objects'
    }).then(res =>{
       // expect(res.status).to.be.eq(200)
        let json = res.body
        debugger
        for(let eachId of json){
            testIds.push(eachId.id)
        }
        console.log(testIds)
    })
})


testIds.forEach(ele =>{

    it(`check the respons of each ID: ${ele}`, ()=>{
        cy.request({ 
            'method' : 'GET',
            'url' : `/objects/${ele}`
        }).then(res =>{
            expect(res.status).to.be.eq(200)
            expect(res.body).to.have.property('id').eq(String(ele))
        })
    })

})
   


})