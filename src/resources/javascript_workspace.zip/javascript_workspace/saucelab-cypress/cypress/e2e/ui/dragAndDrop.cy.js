/// <reference types='cypress'/>



describe('Drag and Drop', Cypress.config({ 'baseUrl': 'https://the-internet.herokuapp.com/' }), () => {



    it.skip('check the title', () => {

        //handle uncaught exception

        cy.on('uncaught:exception',(error, runnable, promise)=>{
            return false
        })
        cy.visit('/')
        cy.contains('Drag and Drop').click()
        cy.get('h3').should('have.text', 'Drag and Drop')
       //trigger the drag feature
       cy.get('#column-a').then($ele => cy.wrap($ele).trigger('dragstart'))
       cy.get('#column-b').then($ele => cy.wrap($ele).trigger('dragend'))
       //cy.get(`#column-a`).then($ele =>{
       // cy.wrap($ele).trigger('mouseover')
       // .trigger('mousedown', { which: 1 })
       // .trigger('mousemove', { clientX: 10, clientY: 5 })
       // .trigger('mouseup', { force: true })

       //})
    
    })

    it.skip('load the multiple fixtures', ()=>{

        cy.fixture('colors').then(color =>{

            cy.fixture('places').then(place =>{

                for(const key of Object.keys(place)){
                    
                    expect(color).to.include.members([key])
                   // console.log(key, place[key])
                }
            })
        })
    })

    it('custom commands', ()=>{
        cy.visit('/')
        cy.contains('JQuery UI Menus').should('be.visible').click()

        //show the first flyer menu
        cy.get('ul.ui-widget-content').eq(2).within($ele =>{
            cy.show($ele).as('back')
        })

        //show the second flyer menu
        cy.get('ul.ui-widget-content').last().within($ele =>{
            cy.show($ele)
        })
        //back to menu
        cy.get('@back').contains('Back to JQuery UI').should('be.visible').click({ force: true})

    })


})