/// <reference types='cypress'/>
const { faker } = require('@faker-js/faker');

describe('play with faker', ()=>{


    it('faker name validation', ()=>{

        cy.wrap(faker.number.int()).should('be.greaterThan', 1)
        cy.wrap(faker.number.int()).then(ele =>{

            expect(ele).to.be.greaterThan(1)
        })
    })
})