/// <reference types='cypress'/>

describe('Different authentication mechanism', Cypress.config({ 'baseUrl': 'https://the-internet.herokuapp.com/' }), () => {


    it.skip('Basic authentication', () => {
        const username = 'admin'
        const password = 'admin'
        cy.visit('/')
        cy.contains('Basic Auth').then(($ele) => {
            let url = $ele.attr('href')
            cy.visit(url, { auth: { username, password } })
        })


        cy.get('h3').should('have.text', 'Basic Auth')
    })



    it('Broken images', () =>{
        cy.visit('/')

        cy.contains('Broken Images').should('be.visible').click()
        cy.get('.example').find('img').then($ele =>{

            
            $ele.get().forEach(e=>{
               let src = e.src
               cy.request({ 
                'method' : 'get',
                'url': src,
                'failOnStatusCode' : false})
                .its('status')
                .should('eq', 200)
            })
        })

    })

})