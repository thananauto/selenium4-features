/// <reference types='cypress'/>

import { includes } from "lodash"

describe('check the form', Cypress.config({ 'baseUrl': 'https://the-internet.herokuapp.com/' }), () => {



    it.skip('check the title', () => {
        cy.visit('https://the-internet.herokuapp.com/')
        //find
        cy.get('#content').find('h1').should('have.text', 'Welcome to the-internet')
        //within
        cy.get('#content').within(() => {
            cy.get('h1').should('have.text', 'Welcome to the-internet')
        })


        //using wrap to proceed
        cy.get('#content').then($ele => {
            console.log($ele)
            cy.wrap($ele).get('h1').should('have.text', 'Welcome to the-internet')
        })
        //using parent
        cy.get('.heading').parent().find('h2').should('have.text', 'Available Examples')

    })

    it('filter the link text contains DOM', () => {
        cy.visit('/')
        //jquery way
        cy.get('ul>li').then($ele => {
            const links = []
            $ele.find('a').get().forEach(e => {
                if (e.textContent.includes('DOM')) {
                    links.push(e.textContent)
                }
            })

            cy.wrap(links).then(op => {
                Cypress.env('links', op)
            })

            cy.task('setData', links )
        })

    })

    it('get links from previous test', () => {

        cy.wrap(Cypress.env('links')).then((ele) => {
            expect(ele).to.be.length(3)
        })
        //filter by text
        cy.get('ul>li').filter(':contains("DOM")').should('have.length', 3).then($ele => {

            $ele.get().forEach(e => {
                expect(['Challenging DOM', 'Large & Deep DOM', 'Shadow DOM']).to.include.members([e.innerText])
            })
        })
    })

    it('get data from cy config', ()=>{

        cy.task('getData')
    })



})