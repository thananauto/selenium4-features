///<reference types="cypress"/>
import example from '../fixtures/example.json'

import colors from '../fixtures/colors.json'
describe('check env variables', () =>{

    it('check process.env', () =>{

        expect(Cypress.env()).to.contain(
            {
                'FOO1' : 'BAR1',
                'FOO2' : 'BAR2'}
        )
    })

    it('check config.env', () =>{
        expect(Cypress.env('user')).to.equal('thanan')

        const getName = () => {
            return 'Jane Lane'
          }
          
          cy.wrap({ name: getName }).invoke('name').should('eq', 'Jane Lane')
    })

    it('load json file', ()=>{

        cy.fixture('example').then((data) =>{
               data['age'] = 20
        })
        expect(example['hello']).to.equal('world')
       
    })


    //with the list
    const rainbow = ["red", "blue", "green"]
    colors.forEach((color) =>{

        it(color, ()=>{
            cy.wrap(color).should('be.oneOf', rainbow)
            expect(color).to.oneOf(rainbow)
        })

    })

    //with key:value pair

    const person = [{name: 'Thanan', age: 30}, { name: 'surya', age: 30}]

   
    person.forEach((person ) =>{

        it(`${person.name}`, () =>{
            cy.wrap(eval(person.age)).should('be.greaterThan', 10)
        })
    })

})