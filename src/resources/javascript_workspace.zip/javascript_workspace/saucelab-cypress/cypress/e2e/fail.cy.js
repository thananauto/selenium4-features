/// <reference types="cypress"/>

describe('Handle uncaught exception', () =>{
    it('fails the Cypress test', () => {
        cy.visit('index.html')
        cy.get('button#error').click()
        // the error happens after 1000ms
        cy.wait(1500)
      })

      it('can be ignored', () =>{
        cy.on('uncaught:exception', (err, runnable) =>{
            console.log(err)
            console.log(runnable)
        })
        cy.visit('index.html')
        cy.get('button#error').click()
      })
})