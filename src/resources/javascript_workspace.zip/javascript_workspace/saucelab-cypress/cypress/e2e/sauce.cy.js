/// <reference types="cypress"/> 
/// <reference types="../support/index.d.ts"/>

describe('Sauce lab login', () =>{

    it('Login test', () =>{
        cy.visit('https://react-shopping-cart-67954.firebaseapp.com/')
        cy.url().should('contain', 'shopping')
        cy.get("input[value='S']").siblings('.checkmark').click()
       
        cy.get('.sc-124al1g-2').should('have.length', 2)
    })

    it.skip('click an item', ()=>{
        cy.get('.sc-124al1g-2').filter(':contains("10")').
         // parents('.sc-124al1g-2').
         first().contains('Add to cart').click()
         cy.get('.sc-124al1g-2').then(($ele)=>{
                const href = $ele.prop('href')
         })

      //  cy.get('.sc-124al1g-2').filter(':contains("22")').
      //  parentsUntil('.sc-124al1g-2').
     //   first().within(($ele)=>{
     //       cy.get('.sc-124al1g-0').contains('Add to cart').click()
      //  })
    })


    it('verify the item', ()=>{
        cy.dataAttr('checkbox').siblings('.checkmark').first().click()
       
    })  


})