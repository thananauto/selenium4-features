declare namespace Cypress{
    interface Chainable{
        dataAttr(value: string): Chainable<Element>
        show(value: string): Chainable<Element>
    }
}