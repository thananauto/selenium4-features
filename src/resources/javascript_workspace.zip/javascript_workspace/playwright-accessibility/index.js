

var button = document.querySelector('.btn-primary')

button.addEventListener('click', function(){
    var getRows = document.querySelector('table > tbody > tr:last-child')
    var allRpws = document.querySelectorAll('table > tbody > tr').length+1
    getRows.insertAdjacentHTML('afterend',
    `
    <tr>
            <th scope="row">${allRpws++}</th>
            <td>${Math.random().toString(36).substring(2,7)}</td>
            <td>${Math.random().toString(36).substring(2,7)}</td>
            <td>@${Math.random().toString(36).substring(2,7)}</td>
          </tr>
    `
)

})
console.log('This is a message')
console.error('This is the error code')
console.error('Division value %d', 4/0)