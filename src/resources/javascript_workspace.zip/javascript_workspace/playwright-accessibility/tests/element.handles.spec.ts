import {test, expect } from '@playwright/test'

test('Get the number of row items', async ({ page }) => {

    await page.goto('localhost:5500/index.html');
    //get the button
    let  addRow =  await page.$('.btn-primary')
    await addRow?.click()

    //get the rows
    const rows = await page.$$('table > tbody > tr')
    expect(rows).toHaveLength(4) // first assertion

    //click the same button
    await addRow?.click()

    expect(rows).toHaveLength(5) // script will fail here

    
})

test('Get the number of row items 2', async ({ page }) => {

    await page.goto('localhost:5500/index.html');

    //get the button
    let  addRow =   page.locator('.btn-primary')
    await addRow?.click()

    const rows =  page.locator('table > tbody > tr')
    expect(rows).toHaveCount(4)

    //click the same button
    await addRow?.click()
    expect(rows).toHaveCount(5)

    
})
