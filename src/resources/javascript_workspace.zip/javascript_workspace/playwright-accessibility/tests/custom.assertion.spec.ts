import {  expect as exp, test, Locator } from '@playwright/test'

const expect = exp.extend({
    async toBeBetween10AndHigher(locator:Locator, expected: number){

        const count = await locator.all()
        if(count.length > 10 && count.length <= expected){
            return {
                message: ()=>`Between 10 - ${ expected }: The number range is ${count.length}`,
                pass: true,
                };

        }
        return {
            message: ()=>`Between 10 - ${ expected } : The number range is ${count.length}`,
            pass: false,
            };
       
    }
})

test('Search a image in pixabay', async ({ page }) => {
    //test.slow()
    await page.goto('https://pixabay.com/images/search/')

    await page.getByPlaceholder('Search Pixabay').fill('mountain');
    await page.getByPlaceholder('Search Pixabay').press('Enter');
    //get the image details
    const imagesRef = page.getByRole('link', { name: 'Free'})
    //find the initial size of the image
    const images = await imagesRef.count();

    //scroll to the last image of the page
    await imagesRef.last().scrollIntoViewIfNeeded()
    
    await expect( async() =>{
        //get the latest count
    const newcount = await imagesRef.count()
     await expect( imagesRef).toBeBetween10AndHigher(100)
     expect(newcount).toBeGreaterThan(images); 

    }).toPass({ timeout: 3000})
   

    

   // await page.pause()
})
test('check the checkly website', async ({ page }) => {
    test.slow()
    await page.goto('https://www.checklyhq.com/blog/')
    const element = page.locator('a[title="Visit this post"]')

    const size = await element.count()
    console.log(size)

    await element.last().scrollIntoViewIfNeeded()

    expect(async()=>{
        console.log('running')
        const newCount = await element.count()
        console.log(newCount)
        expect(newCount).toBeGreaterThan(size)
    }).toPass({
        timeout: 5000
    })
   
})

