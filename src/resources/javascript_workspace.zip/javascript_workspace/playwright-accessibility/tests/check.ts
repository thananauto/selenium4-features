type test = {
    message: string,
    type: string
}
let files: test[] = [
    {
      message: 'Failed to load resource: the server responded with a status of 404 (Not Found)',
      type: 'error'
    },
    { message: 'This is the error code', type: 'error' },
    { message: 'Division value %d NaN', type: 'error' }
  ]

let file = [...files.map(e=> e.message+'\n')]
  console.log(file.join(''))
