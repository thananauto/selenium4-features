import { test, expect } from '@playwright/test'

test.use({
     browserName: 'chromium'
})

test('visual comparison', async ({ page }, testInfo) => {
    
    await page.goto('https://demoqa.com/')
   
    await expect(page).toHaveScreenshot('home-page.png',{
     maxDiffPixelRatio: 0.2,
     mask: [page.locator('div#adplus-anchor')],
     maskColor: '#d55348'
    })

})
