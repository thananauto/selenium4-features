import {FullConfig, FullResult, Reporter, Suite, TestCase, TestResult, TestStatus} from '@playwright/test/reporter'

class MyReporter implements Reporter{

    onBegin(config: FullConfig<{}, {}>, suite: Suite): void {
        console.log(`Total test case count: ${suite.allTests().length}`)
    }

    onEnd(result: FullResult): void  {
        console.log(`Final result is ${result.status}`)
        
    }

    onTestBegin(test: TestCase, result: TestResult): void {
        console.log(`Testcase: ${test.title} is begin`)
    }

    onTestEnd(test: TestCase, result: TestResult): void {
        console.log(`Testcase: ${test.title}: ${result.status} is completed`)
    }
}

export default MyReporter