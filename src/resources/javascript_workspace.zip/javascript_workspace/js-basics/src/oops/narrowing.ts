// type guard
function addAllItems<T>(params:T[] ): T {
    let op: any
    if(typeof params[0] === 'object'){
        
        for(let param of params){
            op+=param
        }
    }else if(typeof params[0] === 'number'){
        for(let param of params){
            op+=param
        }
    }
    return op
    
}

//The in operator

type sparrow ={ fly(): Object}
type cat = {run(): Object}

function checkAnimalBehaviour<T extends sparrow | cat>(animal:T): Object{

    if( 'run' in animal){
          return animal.run()
    }else if('fly' in animal){
         return animal.fly()
    }
     return {}
    
}