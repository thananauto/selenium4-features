import { Employee } from "./interface";

class Employement implements Employee {
  firstName: string;
  lastName: string;

  constructor(firstName: string, lastName: string) {
    (this.firstName = firstName), (this.lastName = lastName);
  }

  address: [number, string] = [1, "op"];

  get getName(): string {
    return this.firstName;
  }

  set setName(name: string) {
    this.firstName = name;
  }

  getFullName = () => {
    return `${this.firstName} ${this.lastName}`;
  };
}

let e1 = new Employement("Ruthran", "Thanan");

e1.setName = "Muthu";
console.log(e1.getName);

console.log(e1);
