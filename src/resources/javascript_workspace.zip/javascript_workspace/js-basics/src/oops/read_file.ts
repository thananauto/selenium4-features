import * as fs from 'fs'

class ReadFile{

    readonly fileName: string
    constructor(fileName: string){
        this.fileName = fileName
    }


     readFile(){
        const loadedConfig =  fs.readFileSync(this.fileName, 'utf-8');
        const config = JSON.parse(loadedConfig);
        return config;
    }
}
 

type value ={
    val : string | number | object
}






const read = new ReadFile('tests/test.json')
 let data = read.readFile()


 function traverse(data: any){

 for (let key in data) {
    if (typeof data[key] === 'object') {
        traverse(data[key])
        } else {
             console.log("Ind "+key + ": " + data[key]);
        }
    
    }
}
traverse(data)
    