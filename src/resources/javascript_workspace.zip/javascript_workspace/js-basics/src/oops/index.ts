let lock = 3
let first_name = 'THanan'
let column = true
let cample;

function readDocument(order: any){
    console.log(order)
}
console.log(lock);

let age: number = 80

if(age < 100)
    age+=20

console.log(age)    
//----------------- array

let numbers = [1, 2, 3, 4]
let join = numbers.includes(1, 1)
console.log(join)


let tple: [string, number] = ['name', 34]
//  --------------- enum

enum Size{SMALL='s', MEDIUM='m', LARGE='l'}

const option:Size = Size.MEDIUM

console.log(option)

//fucntions ----------------

function calculateTax(salary:number, year:number = 2023){


    if(year < 2000)
    return salary * 1.2

    return salary * 1.3
}

let uplifted_amount = calculateTax(200_99, 1999)


console.log(uplifted_amount)

//- objects ------------------------

type Employees = {
    readonly id: number, 
    name: string, 
    age?: number,
    retire: (date: Date) => Date}

let emp : Employees = {
        id:1, 
        name:'Mani',
        retire : (date) => date}

emp.age = 30

//union

function wghtTolbs(weight: number | string): number{

    return typeof weight == 'number' ? weight * 3 : parseInt(weight) * 3
    
}

console.log(wghtTolbs('20'))
// Interscetion

type Sizz ={

    sizz : () => void
}
type Height ={

    height : () => void
}

let person: Sizz & Height ={
    sizz: () => console.log('size'),
    height: () => console.log('height')
}

person.height()
person.sizz()

//optional chaining


type School = {
    id: number | null | undefined,
    opendate?: (date: Date | undefined) => void
}

let teacher : School ={
    id: null,
    opendate:(date) => date == null ? null : new Date()
}

teacher.opendate?.(new Date())

//------ Objects

type Toys={
    count: number,
    descp?: string,
    stock: number,
    warehouse?:string
}

type CountToys ={
    count: number,
    total: number
}

let toys: Toys ={
    count: 1,
    descp: 'This is basic toys section',
    stock: 7,
    warehouse:'Tricjy'
}

let countToys: CountToys = {count: 2, total: 2}

function createToys(toys:CountToys | Toys):{}{
   
    console.log(toys)
        return {name: 'Toysrus'}
}
type s = ReturnType<typeof createToys>
console.log(typeof toys)
createToys(countToys);

//------------array

let foods: string[] = ['rice', 'idli', 'dosa']

type country     = [number,  String]

let countries:   country = [3, 'USA']

function modifiedArray<T>(arr: T[], sep: T): T[]{
    let newArray: T[] =[]
    for(let i=0; i<arr.length; i++){

        if(i!=0)
            newArray.push(sep);
        
        newArray.push(arr[i]);

    }
    return newArray

}

let X: Array<any> = modifiedArray([3,4,5],6)
console.log(X)

//export  {modifiedArray}
var ln = ['sfs','fsdfs']
ln.length =0
ln.push('sdsda');
console.log(ln);