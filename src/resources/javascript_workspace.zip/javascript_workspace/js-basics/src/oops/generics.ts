function concatenate<T>(params:T[]): T {
    return params[0]
}

console.log(concatenate<number>([1,2,4,5,8]))
console.log(concatenate<string>(['12213', 'werer', '0ol']))

//-- get array
function getArray<T>(items:Array<T>) : Array<T>{
    
    return new Array().concat(items)

}



let numbers1 = getArray<number>([1,3,4,5,0])
numbers.push(30)

let words = getArray<string>(['q','w','e', '0'])
words.push('4')

console.log(numbers)
console.log(words)

//-- constraints
interface DisplayDetails {
    firstName: string,
    lastName: string
}

class Person implements DisplayDetails{
    constructor(
        public firstName: string,
        public lastName: string
    ){}
}

class Employee implements DisplayDetails{
    constructor(
        public firstName: string,
        public lastName: string
    ){}
}


function displayPerson<T extends DisplayDetails>(params:T): Object {
    
    console.log(`Person name: ${params.firstName}, ${params.lastName}`);
    return { firstName: params.firstName, lastName: params.lastName}
        
}

let op1 = displayPerson(new Person('Bill', 'Gates'))
let op2 = displayPerson(new Employee('Thanan', 'Jayan'))
console.log(op1, op2);
//-------------- generic interface

interface Sum<T>{
   (a:T, b:T, C:T) : void
  
}

function sumAll<T>(a:T, b:T):Object{
    return {'a': a, 'b': b}
}

let numSum: Sum<number> =sumAll
let stringSum: Sum<String> = sumAll

console.log(numSum(3,5,5));
console.log(stringSum('q','t', 'rs'));

//----------- interace generics

interface KeyValuePair<T, U>{
    (key: T, value: U): Object
   
}

function processKeyValuePair<T, U>(a:T, b:U): any[] {
    
    let x = Array<any>();
    x.push(a)
    x.push(b)
    return x
    
}

let numberPair: KeyValuePair<number, number> = processKeyValuePair
console.log(numberPair(5,6));

let stringpair: KeyValuePair<string, string> = processKeyValuePair

console.log(stringpair('Man', 'Hattan'));

type ManyNames ={
    [keys: string]: any
}

let allNames: ManyNames = {
    firstName: 'Thanan',
    lastName: 'Jayan',
    age: 30,
    onleave: false
}

type formatedString = `get${string}`

let myname: formatedString = 'get0123';
