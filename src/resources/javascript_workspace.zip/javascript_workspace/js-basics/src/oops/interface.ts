interface Dimension{
    width: number,
    height: number,
    check?: number,
    area: () => number | undefined | any,
    volume(): number,
    dim?(width: number, height: number): string
   
}

let wood : Dimension ={
    width: 200,
    height: 100,
    check: 400,
    area: () =>   wood.height * wood.width,
   // dim:(width, height) => width.toString()+height.toString()
   dim:() => wood.width.toString()+wood.height.toString(),
   volume:() => wood.width * wood.height
}

console.log(wood.area())
 let op = wood.dim?.(wood?.height, wood.width)
 console.log(wood?.check)
 
 

 //-------------- Union Types

 export interface Male {
     gender: String,
     isSeniorCitizen: boolean
 }

 interface Employee  {
     firstName: string,
     lastName: string,
     address: [number, string],
     getFullName:()=>string | Date

 }

 interface Info {
     info: string,
     isSuccess: boolean
 }

 type Person = Employee & Info

 const getPersonDetails = (person: Person)=>{

    if(person.isSuccess){
    console.log(person.firstName);
    console.log(person.lastName);
    let fullName = person.getFullName();
    console.log(fullName)
    }
    console.log(person.info)

 }


 let eachPerson: Person ={
     firstName: 'Thanan',
     lastName: 'Jayan',
     address: [0, 'kamaraj street'],
     getFullName:() => new Date(),
     info: 'the object is not properly initialted',
     isSuccess: false

 }
 getPersonDetails(eachPerson);

export {Employee};
export default {wood, eachPerson}



 //------------ classes

 interface Poto{
    cameramode: string
    savemode: string
    flashmode: boolean
 }


 class Instagram implements Poto{

     cameramode: string 
     savemode: string
     flashmode: boolean

    set save(mode: string){
        this.savemode = mode
    }

    set camera(mode: string){
        this.cameramode = mode
    }

    set flash(mode: boolean){
        this.flashmode = mode
    }

    get save():string{
       return  this.savemode 
    }

    get camera(): string{
        return this.cameramode 
    }

    get flash(): boolean{
        return this.flashmode 
    }
 }


 let insta=  new Instagram();
 insta.cameramode = 'ui'

 console.log(insta)
 
 class Person1 {
    private _age: number;
    private _firstName: string;
    private _lastName: string;

 
    public get age() {
        return this._age;
    }

    public set age(theAge: number) {
        if (theAge <= 0 || theAge >= 200) {
            throw new Error('The age is invalid');
        }
        this._age = theAge;
    }

    public getFullName(): string {
        return `${this._firstName} ${this._lastName}`;
    }
}

 