type Data = {
    [key: string]: any

}

type Data1=Record<string, any>


let num: Record<number, number>={
    1: 3,
    2 : 5
}

console.log(num);
interface Todo {
    title: string;
    description: string;
  }
   
  function updateTodo(todo: Todo, fieldsToUpdate: Partial<Todo>) {
    return { ...todo, ...fieldsToUpdate };
  }
   
  const todo1 = {
    title: "organize desk",
    description: "clear clutter",
  };
   
  const todo2 = updateTodo(todo1, {
    description: "throw out trash",
  });

  console.log(todo2);
  