abstract class Car {
  constructor(
    private tyre: number,
    public cc: number,
    public feature: string
  ) {}

  getFullDetails(): string {
    return (
      this.tyre.toString() + " - " + this.cc.toString() + " - " + this.feature
    );
  }

  abstract get vehiclecc(): number;
}

class Audi extends Car {
  constructor(tyre: number, cc: number, feature: string) {
    super(tyre, cc, feature);
  }
  get vehiclecc(): number {
    return this.cc;
  }
}
let car: Car = new Audi(1, 2, "V8");
car.cc = 34;
console.log(car.vehiclecc);
console.log(car.getFullDetails());
