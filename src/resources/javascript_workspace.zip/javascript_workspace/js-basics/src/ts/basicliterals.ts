function add1(num1:number, num2: number): any {

    if(typeof num2 === 'number'){
    return num1+num2;
    }else{
        console.log(num1+num2)
    }
    
}

let n1 = 4
let n2 = 6
const result = add(n1, n2);
console.log(result)