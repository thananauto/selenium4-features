function addNumber(input1, input2) {
    return input1 + input2;
}
function printOutput(result) {
    console.log(result);
}
function addAndHoldValue(num1, num2, callBack) {
    callBack(num1 + num2);
}
addAndHoldValue(4, 5, function (i) { console.log(i); });
printOutput(addNumber(4, 7));
console.log(printOutput(addNumber(4, 7)));
