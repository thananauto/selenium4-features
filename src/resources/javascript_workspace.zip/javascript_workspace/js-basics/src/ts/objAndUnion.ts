enum role  {ADMIN = 'admin', AUTHOR= 'author' }

let person1:{
    name: string;
    age: number,
    hobbies: any[];
    address:readonly [number, string]

} ={
    name: 'thanan',
    age: 30,
    hobbies: ['playing cricket', role.ADMIN, role.AUTHOR],
    address: [234, 'kamaraj road']

}

person1.hobbies.push("Hector")


person1.hobbies.forEach(e => console.log(e));
person1.address.forEach(e => console.log(e));
console.log(typeof person)

//------------------------

type combine = number | string
type flagDescrip = 'as-text' | 'as-number'

function combineVars(
    input1: combine,
     input2: combine,
     flag: flagDescrip
     ) {
         if(typeof input1 == 'number' && typeof input2 == 'number' || flag == "as-number"){
         
            return +input1 +  +input2;
        }else{
            return input1.toString() + input2.toString()
        }
    
}


let  onlyNumbers = combineVars(4,6, 'as-text');
console.log(onlyNumbers)

let  onlytext = combineVars('4','6', 'as-number');
console.log(onlytext)

let  textAndNumber = combineVars(4,'6', 'as-number');
console.log(textAndNumber)