function addNumber(input1:number, input2: number) {
    return input1 + input2
}

function printOutput(result:any) {
    console.log(result)
    
}

function addAndHoldValue(num1:number, num2: number, callBack:(r: number)=>number) : number {
    return callBack(num1 + num2)
    
}


//pass paramters with function
let op: number = addAndHoldValue(4, 5, (i)=>{ return i})
console.log(" called inner loop function "+op)
type funcCheck = (a: number, b:number) => number

let dummyAdd: funcCheck = addNumber

console.log('Assign function with another name and call '+dummyAdd(5,8))

printOutput(addNumber(4,7));
console.log(printOutput(addNumber(4,7)))

//-------------------------------------------------------

let firstName: unknown;
let lastname: string

firstName = 5
firstName = "seedan"

if(typeof firstName == 'string'){
    lastname = firstName
}else if(typeof firstName == 'number'){
   
}

function printErrorMsg(message:string, code: number) {
    throw{message: message, code: code}
}
