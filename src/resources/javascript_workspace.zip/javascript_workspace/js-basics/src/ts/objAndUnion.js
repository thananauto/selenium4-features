var role;
(function (role) {
    role["ADMIN"] = "admin";
    role["AUTHOR"] = "author";
})(role || (role = {}));
var person = {
    name: 'thanan',
    age: 30,
    hobbies: ['playing cricket', role.ADMIN, role.AUTHOR],
    address: [234, 'kamaraj road']
};
person.hobbies.push("Hector");
person.hobbies.forEach(function (e) { return console.log(e); });
person.address.forEach(function (e) { return console.log(e); });
console.log(typeof person);
function combineVars(input1, input2, flag) {
    if (typeof input1 == 'number' && typeof input2 == 'number' || flag == "as-number") {
        return +input1 + +input2;
    }
    else {
        return input1.toString() + input2.toString();
    }
}
var onlyNumbers = combineVars(4, 6, 'as-text');
console.log(onlyNumbers);
var onlytext = combineVars('4', '6', 'as-number');
console.log(onlytext);
var textAndNumber = combineVars(4, '6', 'as-number');
console.log(textAndNumber);
