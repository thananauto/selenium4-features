//const { chromium } = require('playwright'); 
import { chromium  } from 'playwright'; // Or 'webkit' or 'firefox'.
import { expect } from 'playwright/test';

const ReUseChrome = async () => {
//connect the existing browser using Websock=ket debugger address
//const browser = await chromium.connectOverCDP('ws://localhost:9222/devtools/browser/8c917e8b-de00-4242-adc3-0850fa795e78');
const browser = await chromium.connect('wss://31115-port-f0ad13e8516e43c3.labs.kodekloud.com/playwright/chromium/playwright-1.49.0?headless=false&enableVideo=true');
//const defaultContext =  browser.contexts()[0] //get the first opened tab
//const page = defaultContext.pages()[0];
const page = await browser.newPage();
await page.goto('https://example.com');
console.log(await page.title());

/**
 * type and test the code snippet after this line
 */
await page.goto('https://www.amazon.com')
await expect(page).toHaveURL(/amazon/)


/**
 * don't close the browser ar page instance
 */

return await page.title()
};

const op = await ReUseChrome()
console.log(op)




