//const { chromium } = require('playwright'); 
import { firefox  } from 'playwright'; // Or 'webkit' or 'firefox'.
import { expect } from 'playwright/test';

const ReUseFirefox = async () => {
//connect the existing browser using Websock=ket debugger address
//const browser = await chromium.connectOverCDP('ws://localhost:9222/devtools/browser/8c917e8b-de00-4242-adc3-0850fa795e78');
const browser = await firefox.connect('wss://30157-port-3977741e595d42fb.labs.kodekloud.com/playwright/firefox/playwright-1.49.0?headless=false&enableVideo=true');
//const defaultContext =  browser.contexts()[0] //get the first opened tab
//const page = defaultContext.pages()[0];

const page = await browser.newPage()
await page.goto('https://www.amazon.com')
await expect(page).toHaveURL(/amazon/)
page.waitForEvent('pageerror')


/**
 * don't close the browser ar page instance
 */

return await page.title()
};

const op = await ReUseFirefox()
console.log(op)




