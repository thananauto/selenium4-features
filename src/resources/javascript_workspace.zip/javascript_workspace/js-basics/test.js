import { chromium, firefox, request } from 'playwright'
import { expect  } from 'playwright'

(async() =>{
    
let browsercontext = await chromium.launch()
let browser = await browsercontext.newContext()

let page = await browser.newPage()

await page.goto('https://amazon.com')
await expect(page).toHaveURL(/amazon/)
await browser.close()

})()