import AxiosDigestAuth from "@mhoc/axios-digest-auth";

import * as axios from "axios";


const options = {

  password: 'admin',
  username: 'admin'
};
const axiosDigestAuthInst = new AxiosDigestAuth(options);


// you dont have to import this or add it to your package.json.
// just using it to outline where these types are coming from.

const ExecuteMyRequest = async () => {
  const requestOptions = {
    headers: { Accept: "application/json" },
    method: "GET",
    url: "https://the-internet.herokuapp.com/digest_auth",
  };
  const response = await axiosDigestAuthInst.request(requestOptions);
  console.log(response.status)
  console.log(response.request.headers)
};