function print(){
   return this
}

const p1 = print();
const p2 = print()

p1.a = 50
p2.a = 100
console.log(p2.a == global.a)

let instant = {
    myFunction(){
        console.log(this)
    },
    myFunction3(){
       function myFunction4(){
        console.log(this)
        }
        return myFunction4()
    }
}


 instant.myFunction()
