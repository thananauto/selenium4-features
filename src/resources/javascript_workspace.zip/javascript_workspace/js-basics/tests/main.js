console.log("Hello world...!!");    
let firstName = 'thanan';

console.log(firstName);
const lastName = "Jayan";
let isPresent = true
let age = undefined
let add = null

//objects
let employee = {
    "name" : "Thanan",
    age: 34,
    id: 9808,
    address:{
        streetname: "Perumal pettai",
        pincode: 609313
    }
}

console.log(employee.address['pincode']);
console.log(employee.name);
//array
let counter = 0;
function numsol(element, index){

    console.log(index+' ----> '+element);
    counter++;
}


let employees = [
    { name: 'John', age: 30, add: "Perambur"},
    { name: 'Mike', age: 40}
]
function printKey(element){

    console.log(element.name+"  -> "+element.age+" -> "+element.add);

}
employees.forEach(printKey)




