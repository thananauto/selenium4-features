function printOut(){

    return () =>{
        return this
    }
}

function Car(){
    this.fuel = 0
    this.reFuel = function(){
        _this = this
        setTimeout(function(){
            _this.fuel+=100
            console.log(_this.fuel)
        }, 2000)
    }
}

const car = new Car()
car.reFuel()