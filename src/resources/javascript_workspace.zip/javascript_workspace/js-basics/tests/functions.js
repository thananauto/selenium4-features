let a = 10
function outer(){
    let b= 40

    function inner(){
        let c = 50

        console.log(a, b, c)
    } inner();
}

outer()
//------------------- closure

function ext(){
    let count =0;

    function internal(){
        count++;
        console.log(count);
    }

    return internal
}

let close = ext();
close()
close()
//-------------------------- currying

function sum(a,b,c){

    return a+b+c;
}

let op = sum(5,7,9);
console.log(op);



let X = (x) =>(y) =>(z) =>sum(x, y, z);
   
console.log(X(1)(3)(9))
//------------------------- this

//Implicit binding

let person ={
    name: "Mani",
    sayName: function(){
        console.log(`My name is ${this.name}`)
    }
}

person.sayName();

//explicit binding

function sayName(){
    console.log(`My name is ${this.name}`)
}

sayName.call(person);

//new binding

function Person(name){
    this.name = name
}

const p1 = new Person('opi');
const p2 = new Person('maco');
console.log(p1.name, p2.name)

//------------------------------------------------------

function Employee(firstName, lastName){

    this.firstName = firstName;
    this.lastName = lastName;
}


const e1 = new Employee("Brue", "wayne");
const e2 = new Employee("Jack", "reacher");
Employee.prototype.getFullName = function(){ console.log(`${this.firstName} and ${this.lastName}`);}

console.log(e2.getFullName());

//----------------------------------------------------------

// class concept

class Emp{

    constructor(fname, lname){
        this.firstName = fname;
        this.lastName = lname;
    }

    sayMyName=() => `${this.firstName} - ${this.lastName}`
    
}

class SuperHero extends Emp{
    constructor(fname, lname){
        super(fname, lname);
        this.hero = false;
    }

    isMyHero = () => this.hero ? 'Its my hero' : ' not my hero'
}

const ems = new SuperHero("Bruce","william");

console.log(ems.sayMyName());
console.log(ems.isMyHero());    
