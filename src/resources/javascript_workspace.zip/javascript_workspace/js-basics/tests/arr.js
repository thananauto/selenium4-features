let numbers = ['Ha', 'kl', 'ma', 'io', 'op']

console.log(numbers.push("pp", "pp1"))
console.log(numbers)

console.log(numbers.splice(1,3, "xx", "yy", "zz", "aa"))
console.log(numbers.unshift(0))

numbers.shift();

checkEvery =(ele, index, arr)=>{
    console.log(ele);
    console.log(arr[index] == ele)
    return arr[index] == ele;
}

numbers.every(checkEvery)

console.log(numbers.entries())

let suc = numbers.entries()
for (const [index, element] of suc) {
    
    console.log(element)
    
}
//---------------------------
//map method
let employees = [
    { name: 'John', age: 30, add: "Perambur"},
    { name: 'Mike', age: 40}
]

let modEmp = (ele, index, employees)=>{

    
    return {$index:ele.name.toUpperCase()};

}
let changed = employees.map(modEmp);
console.log(changed)
//find method

let findEle = employees.find((ele, index, arr)=> ele.name == 'John');
 console.log(findEle)

 let reducenum = numbers.reduce((acc, ele, index, arr) => acc + ele);
 console.log(reducenum);
