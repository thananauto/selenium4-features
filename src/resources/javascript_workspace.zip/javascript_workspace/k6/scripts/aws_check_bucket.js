import { PutObjectCommand, CreateBucketCommand, S3Client, HeadBucketCommand } from "@aws-sdk/client-s3";
import {AWS} from "aws-sdk" 

const s3 = new AWS.s3()