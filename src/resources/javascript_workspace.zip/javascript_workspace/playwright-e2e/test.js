
const fs = require('fs');

const data = fs.readFileSync('GITHUBCONTEXT.json', 'utf-8');
const githubContext = JSON.parse(data || '{}');
let metadata = {}
if(githubContext.sha){
      metadata = {
        'revision.id': githubContext?.sha,
        'revision.author': githubContext.actor,
        'revision.email': githubContext.event?.pusher?.email,
        'revision.subject': githubContext.event?.head_commit?.message,
        'revision.timestamp': new Date(githubContext.event?.repository?.updated_at),
        'revision.link': githubContext.event?.repository?.commits_url,
        'ci.link': 'https://github.com/thananauto/playwright-tips-tricks/actions/workflows/meta-data.yml'
        
      }
}

console.log(metadata)