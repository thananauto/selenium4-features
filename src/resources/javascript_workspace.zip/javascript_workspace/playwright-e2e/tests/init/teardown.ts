import { test as teardown } from '@playwright/test'


teardown.skip('Setup the database', async ({})=>{
    console.log('closing database .......')
})