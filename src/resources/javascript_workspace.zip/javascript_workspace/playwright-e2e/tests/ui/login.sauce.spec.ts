import { test, expect } from '@playwright/test'

test.describe.configure({mode: 'parallel'})

//demoblaze tests
test.describe('Demo blaze tests', async() => {
    test.use({baseURL: 'https://demoblaze.com/index.html', storageState: 'data/.auth/user.json'})

test('Logged In User', async ({ context  }) => {
    
    const page = await context.newPage()
    await page.goto('/')
    await page.locator('#nameofuser').click()
    await page.waitForTimeout(4000)
    await expect(page).toHaveURL(/#/)
    
})

test('SignUP not present', async({ page })=>{

    await page.goto('/')
    await expect(page.getByRole('link', { name: 'Sign up'})).not.toBeVisible()
    await page.waitForTimeout(4000)

})
test.use({baseURL: 'https://demoblaze.com/index.html'})

test('Sign In freshly', async({ page, context })=>{

//await context.clearCookies()
await page.goto('/')
await page.getByRole('link', { name : 'Log in'}).click()

    await page.locator('#loginusername').fill('test')
    await page.locator('#loginpassword').fill('test')
    await page.getByRole('button', { name : 'Log in'}).click()
    await expect(page.getByRole('link', { name: 'Log out'})).toBeVisible()


})


//sauce lab tests
test.describe('Check the Login state of UI application', async() => {
    test.use({ baseURL: 'https://www.saucedemo.com', storageState: 'data/.auth/user.json'})
    test.skip('Product details page', async ({ page }) => {
        await page.goto('/')
        await page.waitForTimeout(5000)
        await page.locator('.inventory_item_name ').first().click()
        await expect( page.locator('inventory_details_img_container')).toBeVisible()
        
    })

    test.skip('Go to cart page', async ({ page }) => {
        await page.goto('/')
        await page.waitForTimeout(5000)
        await page.getByTestId('shopping-cart-link').click()
        const continueBtn = page.locator('#continue-shopping')
        const checkout = page.locator('#checkout')
        const btn =  continueBtn.and( checkout)
        await expect(btn).toBeVisible()
    })
    
    
    
})
})
