import { add, sub } from './math.js'

const addition = add(4,5)
console.log(addition)

const subtraction = sub(8,4)
console.log(subtraction)