import { mul, div } from './light'

const multiply = mul(8,9);
console.log(multiply)

const division = div(6,3)

console.log(division)