"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const light_1 = require("./light");
const multiply = (0, light_1.mul)(8, 9);
console.log(multiply);
const division = (0, light_1.div)(6, 3);
console.log(division);
