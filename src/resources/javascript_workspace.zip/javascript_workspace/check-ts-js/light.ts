function mul(a:number, b:number) :number{
    return a+b;
}

function div(a : number, b: number) : number{
    return a-b;
}

export { mul, div }