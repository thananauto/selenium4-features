"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mul = mul;
exports.div = div;
function mul(a, b) {
    return a + b;
}
function div(a, b) {
    return a - b;
}
