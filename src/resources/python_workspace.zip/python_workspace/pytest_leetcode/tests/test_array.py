

def test_array():
    lst = [1,2,4,5]
    lst2 = [1,2,4,5]
    print(type(lst))
    print(lst.index(2))
    lst.remove(4)
    print(lst[:])
    op = [*lst, *lst2]
    op.sort()
    
    op1=list(map(lambda x: x*2, op))
    print(op1)
    print(max(op1))

    dic1 = { 'name': 'Thanan', 'age' : 30}
    dic2 = { 'name': 'dxcv', 'age' : 30}
    dic3 = {**dic1, **dic2}

def test_occurance():
    ip = 'xyzzyxccbc'
    op ={}
    for cha in ip:
        if not cha in op.keys():
            op[cha] = 1
        else:
            op[cha] +=1
    print(op)
            

def test_FMTI():
    name = 'My name is Thananjayan'

    arr_name = name.split(" ")
    op =""
    for each_word in arr_name:
        for i in range(len(each_word)-1,-1,-1):
            op+=each_word[i]
        op+=" "

    print(op)
        
        
