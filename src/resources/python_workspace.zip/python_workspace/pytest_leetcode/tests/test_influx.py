import influxdb_client, os, time, datetime
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS    

token = "kcgkrS3jbcKRubeV6TiTNckfPGCU-1w4eA31u0jQQ6pbqULMKhkxyrVkUwTlGDCOyuXLop1tcFi7d6kB8FxZ3Q=="
org = "qa-test"
url = "https://8087-port-22c30a4b115c408d.labs.kodekloud.com"


def test_influx():
    write_client = influxdb_client.InfluxDBClient(url=url, token=token, org=org)
    bucket="QA"

    write_api = write_client.write_api(write_options=SYNCHRONOUS)

    for status in range(3):
        point = (Point("Summary Status")
                 .tag("Status", "Count")
                 .field("passed", status + 6)
                 .field("failed", status + 2)
                 .field("skipped", 3))
                 #.time(time=datetime.datetime.now()))
        write_api.write(bucket=bucket, org="qa-test", record=point)
        time.sleep(4) 
    
    for value in range(5):
        point = (
            Point("measurement1")
            .tag("Temperature", "Percentage")
            .field("Faherenhit", value+5)
            .field("Celcius", value+23)
        )
        write_api.write(bucket=bucket, org="qa-test", record=point)
        time.sleep(3) 