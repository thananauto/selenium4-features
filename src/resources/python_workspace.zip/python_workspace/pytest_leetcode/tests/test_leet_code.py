nums = [0,0,1,1,1,2,2,3,3,4]

def dupl():
    nums[:] = sorted(set(nums))
    print(nums)
    return len(nums)

def removeElement( nums, val):
    nums[:] = [num for num in nums if num != val]
    return len(nums)

def remove_duplicates():
   
    
    op = []
    [op.append(num) for num in nums if num not in op ]
    print(op)
    return len(op)

def minOperations( nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        nums =[2,3,3,2,2,4,2,3,4]
        operation = 0
        value = nums[0]
        for x in range(len(nums)):
            if len(nums) >0:
                 index = nums.index(value)
                 nums.pop(index)

def  dasdtest_halvesAreAlike():
        """
        :type s: str
        :rtype: bool
        """
        s = 'book'
        a = ('a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U')
        first_half = s[0:round(len(s)/2)]
        second_half = s[round(len(s)/2): len(s)]

        first_count = 0;
        second_count = 0
        for e in first_half:
             if e.lower() in a:
                  first_count+=1
        for x in second_half:
             if x.lower() in a:
                  second_count+=1  
        print(first_count, second_count)  
from functools import reduce

def sddtest_sum_triplets():
     output= []
     nums1 = [-1,0,1,2,-1,-4]

     for index1, val1 in enumerate(nums1):
          for index2, val2 in enumerate(nums1):
               for index3, val3 in enumerate(nums1):
                    ip = [ nums1[index1], nums1[index2], nums1[index3]]
                    sum = reduce(lambda a, b: a+b, ip) 
                    if  index1 <= index2 and index1<= index3 and index2 <= index3:
                        if sum == 0:
                            output.append(ip)
     print(f'output: {output}')                    


def reverse():
        """
        :type x: int
        :rtype: int
        """
        x= -123
        if((-pow(2,31))/10 > x or  (pow(2,31))/10 - 1 > x):
             return 0
        
        op = 0
        while(x!=0):
            op= op*10 + abs(x)%10
            x= abs(x)//10
        
        return op
        
    #minOperations([0,1,2,2,3,0,4,2])
    #sum_triplets()
   
def test_duplic():
     print(reverse())

