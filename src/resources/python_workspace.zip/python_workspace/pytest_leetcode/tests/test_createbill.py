from fpdf import FPDF

class PDF(FPDF):
    def header(self):
        # Airtel logo and header text
        self.image('./tests/image.png', 10, 8, 33)  # Adjust the image path and size as needed
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, 'Broadband Bill', align='C', ln=1)
        self.ln(10)

    def footer(self):
        # Page footer
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.cell(0, 10, 'Thank you for choosing Airtel - Page %s' % self.page_no(), 0, 0, 'C')

# Create PDF instance
pdf = PDF()
pdf.set_auto_page_break(auto=True, margin=15)
pdf.add_page()
pdf.set_font('Arial', '', 12)

# Billing details
pdf.cell(0, 10, 'Customer Name: Thananjayan', ln=1)
pdf.cell(0, 10, 'Billing Address: Plat No: 225, Thrangambadi, Mayiladuthurai, Postal Code 609313, India', ln=1)
pdf.cell(0, 10, 'Broadband Account Number: 1234567890', ln=1)
pdf.cell(0, 10, 'Bill Number: 987654321', ln=1)
pdf.cell(0, 10, 'Bill Period: 01-Jan-2025 to 31-Jan-2025', ln=1)
pdf.cell(0, 10, 'Bill Date: 01-Feb-2025', ln=1)
pdf.cell(0, 10, 'Due Date: 10-Feb-2025', ln=1)

pdf.ln(10)

# Bill summary
pdf.set_font('Arial', 'B', 12)
pdf.cell(0, 10, 'Bill Summary', ln=1)
pdf.set_font('Arial', '', 12)
bill_items = [
    ("Monthly Rental Charges", "799.00"),
    ("Add-ons and Services", "100.00"),
    ("Taxes (18% GST)", "161.82"),
    ("Total Payable", "1,060.82")
]
for item, amount in bill_items:
    pdf.cell(0, 10, f"{item}: INR {amount}", ln=1)

pdf.ln(10)

# Plan details
pdf.set_font('Arial', 'B', 12)
pdf.cell(0, 10, 'Plan Details', ln=1)
pdf.set_font('Arial', '', 12)
pdf.cell(0, 10, 'Plan Name: Airtel Xstream Fiber 100 Mbps', ln=1)
pdf.cell(0, 10, 'Usage Quota: Unlimited Data', ln=1)
pdf.cell(0, 10, 'Additional Benefits: Free OTT Subscriptions (Airtel Xstream, Amazon Prime Video)', ln=1)

# Save PDF
pdf_path = "Airtel_Broadband_Bill_Thananjayan.pdf"
pdf.output(pdf_path)

pdf_path
