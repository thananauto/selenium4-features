
def test_stack_rev_string():
    name = 'Kandy'
    lstName = [x for x in name]
    while(len(lstName) != 0):
        print(lstName.pop())


def test_queue_rev_string():
    name = 'kumar'
    lstName = [x for x in name]
    while(len(lstName) != 0):
        print(lstName.pop(0))