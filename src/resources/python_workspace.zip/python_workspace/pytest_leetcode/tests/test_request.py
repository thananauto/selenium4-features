from requests import Request, Session
import requests
import re

BASE_URL = 'https://reqres.in'
def test_get():
    params ={ 'page' : 1}
    headers = {'Content-Type' : 'application/json'}
    res = requests.get(BASE_URL+'/api/users', params=params, headers=headers)
    assert res.status_code == 200, "Status code is wrong"
    json = res.json()
    assert json['page'] == 1
    for data in json['data']:
        assert re.match('\d', str(data['id']))
        assert re.match('[a-z,A-z\W]+@[a-z]+.[a-n]+', data['email'])
        assert re.match('[a-z,A-Z]', data['first_name'])
        assert re.match('[a-z,A-Z]', data['last_name'])
        assert re.match('[a-z,A-Z]', data['last_name'])
        assert re.match('^https.*jpg$', data['avatar'])
    assert  'application/json' in res.headers['Content-Type']

def test_post():
    headers = {'Content-Type' : 'application/json; charset=utf-8'}
    data ={
    "name": "morpheus",
    "job": "leader"
    }
    res = requests.post(BASE_URL+'/api/users', data=data)
    op = res.json()
    
    print(op)

def test_put():
    headers = {'Content-Type' : 'application/json; charset=utf-8'}
    data ={
    "name": "morpheus",
    "job": "leader"
    }
    res = requests.put(BASE_URL+'/api/users/2', data=data)
    op = res.json()
    
    print(op)

def test_patch():
    headers = {'Content-Type' : 'application/json; charset=utf-8'}
    data ={
    "name": "morpheus2",
    
    }
    res = requests.patch(BASE_URL+'/api/users/2', data=data, auth=("username", "pas"))
    op = res.json()
    
    
    print(op)

def test_anagharam():
      string1 = 'abcd'
      string2 = 'dcxd'
      assert len(string1) == len(string2), 'Both string length should be equal'
      
      for c1 in string1:
          if c1 in string2:
              string2 = string2.replace(c1, '');
      
      assert len(string2) == 0

def test_max():
    numbers = [1, 7, 8, 7, 7, 7]
    dict ={}
    for num in numbers:
        if num in dict:
            dict[num] = dict[num] +1
        else:
            dict[num] = 1
    temp = 0
    for key, value in dict.items():
        if temp < value:
            temp = value
            print(key)

def rev_string(ele):
    
    if(len(ele) > 4):
        return ele[::-1]
    else:
        return ele


def test_spin_words():
    # Your code goes here
   sentence = "Welcome to Home Buddys"
   y = [word for word in sentence.split(" ")]
   z=  " ".join([x if len(x)<5 else x[::-1]  for x in y] )
   print(z)


def test_square_digits():
    num = 9119 
    op = []
    while(num!=0):
        q = num % 10
        op.append(q**2)
        num = num //10
    op.reverse()
    o = int("".join([str(x) for x in op]))
    print(o)

def test_isogram():
    string= "aba";
    return len([x  for x in string.lower() if string.count(x)==1]) == len(string)


def test_create_phone_number():
    #your code here
    n=list(map(lambda x: str(x),[1, 2, 3, 4, 5, 6, 7, 8, 9, 0]))
    print('('+"".join(n[0:3])+') '+"".join(n[3:6])+'-'+"".join(n[6:len(n)]))


def lstx(x):
    return x[1:]+x[0]+'ay' if x.isalnum() else  x

def test_oy():
    
    #your code here
    
    text = 'Pig latin is cool'
    text.isalnum()
    op = list(map(lstx, text.split(" ")))
    
    return " `".join([ x[1:]+x[0]+'ay' if x.isalnum() else  x for x in text.split(" ")])

def test_unique():
    sequence = [1, 2, 2, 3, 3]
    if len(sequence):
        print([])
    op=[sequence[0]]
    for index in sequence[1:]:
        if(op[-1] != index):
            op.append(index)
    print(op)

def test_red_digit():
    n = 646
    op=0
    while(n>9):
        op = sum( [int(x) for x in str(n)])
        n = op
    print(op)
       