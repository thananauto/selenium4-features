from requests import PreparedRequest
from requests.auth import AuthBase

class Token(AuthBase):

    def __init__(self, token):
        self.token = token;

    def __call__(self, r: PreparedRequest) :
        r.headers['Authorisation'] = f'Beared: {self.token}'
        return r