import module
import sys

sys.path.append("own_modules")


import maths
print(maths.add(8, 9))
print(maths.sub(8,9))


class Dog:
    def __init__(self, name):
         self.name = name

dog = Dog('Lotta')
print(hasattr(dog, 'age'))
dog.age = 5
print(dog.__dict__)
print(dog.__getattribute__('name'))
print(hasattr(dog, 'age'))
          