class E(Exception):
    def __init__(self, message):
        self.message = message

    def __str__(self):
        return 'custom exception'

try:
    print('test exception')
    raise
except BaseException as e:
    print('error', e, e.message)
else:
    print('Done')