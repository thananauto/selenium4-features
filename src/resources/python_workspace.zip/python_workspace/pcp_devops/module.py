counter: int  = 0
print(__name__)

if __name__ == "__main__":
    print("I can execute by own")
    counter = 9
    print(counter)