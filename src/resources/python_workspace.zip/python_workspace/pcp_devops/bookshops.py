from traceback import print_tb


class Book:
    def __init__(self, title):
        self.title = title
        self.author = None

    def add_author(self, name):
        # add author property
        self.author = name

    def add_chapter(self, number, title):
        # add properties chapter_number and chapter_title
        self.chapter_number = number
        self.chapter_title = title



class BookInfo(Book):
    def __init__(self, title, price, info=False):
        Book.__init__(self, title)
        # add properties price and info
        self.price = price
        self.info = info
        self.stars = 0

    def rating(self, stars):
        try:
            # check if existing stars are less than new stars
            # and if new stars are greater than 4
            # adjust new price by a 20% increase
            if self.stars < stars:
                if stars  > 4:
                    self.price += self.price * 0.2
            else:
                self.stars = stars
           
        except Exception as e:
            print(e, "Please try again")


# Create a book object titled 'Two Scoops of Django'
book = Book()
# Add the author 'Greenfeld'
book.add_author('Greenfeld')
# Add a chapter 3, with title 'Async Views'
book.add_chapter(3, 'Async Views')

# Create a book_info object titled 'Two Scoops of Django'
# with a price of 10, and info set to True
book_info = BookInfo(title='Two Scoops of Django', price= 10, info=True)
# Give the book_info a rating of 5 stars
book_info.rating(5)

print("Book info: ", end=" ")
# Print book_info's title, stars and price
print(
   str(book_info.stars) + " stars",
    sep=", "
)
# Print all properties of book and book_info objects
print("Book properties: ", ...)
print("BookInfo properties: ", ...)
