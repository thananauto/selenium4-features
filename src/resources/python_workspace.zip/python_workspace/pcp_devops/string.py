msg : str = "Hello World !"
msg_list = list(msg)
#print(msg_list)

def getLowestAsciValue(lst: list):

    val = min(lst)
    print(f" val is {val} ")
    lst.remove(val)
    return (val, lst)

chars = "0234"
char = ""
for char in reversed(chars):
    char += char

print(char)

output = ""
while len(msg_list)== 0:
       fun = getLowestAsciValue(msg_list)
       print(fun)
       output=output + fun[0]
       msg_list = fun[1]
       print('OP')
         

print(output)        
    