msg = input("Enter your message to encrypt: ")


def encrypt(msg):
    result = ""

    # iterate through the input msg
    for i in range(len(msg)):
        char = msg[i]
        # Check if character is alphanumeric
        if char.isalpha():
            if char == 'Z':
                result+='A'
            elif char == 'z':
                result+= 'z'
            else:
                result+=chr((ord(char)+1))        
            # Check char is either Z or z and append A, a respectively


        else:
            result+=char

            # Else shift to the next letter


        # If char not alphanumeric just continue

    return result


print("Message to encrypt : ", msg)
print("Cipher: ", encrypt(msg))

