from os import strerror
from traceback import print_tb


def lipogram(letter):
    letter.lower()
    try:
        txt = open("oulipo.txt", "r")

        os = [char for line in txt for char in line ]
        print(os)
        
    except IOError as e:
        print("I/O error: ", strerror(e.errno))
        txt = None
    except Exception as e:
        print(e)
    else:
        oz = map(lambda x: 1 if letter in x else 0, os)
        count = sum(oz)
        print(letter, "appears", count, "times")
    finally:
        if txt:
            txt.close()


lipogram("i")