import requests, pytest, os, json
from dotenv import  dotenv_values

def conf():
    #get the env variable
    env = os.getenv('ENV','qa')
    #loaded secret
    props = {
        **dotenv_values('.env.secret'),  # load sensitive variables
        **dotenv_values(f'.env.{env}') # Load environment variables
    }

    return props


@pytest.fixture(scope= 'module')
def  load_test_data(request):
    with open(f'data/test_data1.json', 'r') as test_data:
        data = json.load(test_data)
    return data

def  load():
    with open(f'data/test_data1.json', 'r') as test_data:
        data = json.load(test_data)
    return data

class Conf:
    base_url = conf().get('BASE_URL')
    user_name = conf().get('USERNAME')
    password = conf().get('PASSWORD')
   

#@pytest.fixture(scope='session', params= iter(load())), request.param
@pytest.fixture(scope='session')
def env_config(request):
    conf = Conf()
    return conf


def _collection_modifyitems_old(items):
    """Modifies test items in place to ensure test modules run in a given order."""
    MODULE_ORDER = ["Test_B","Test_A"]
    module_mapping = {item: item.module.__name__ for item in items}

    sorted_items = items.copy()
    # Iteratively move tests of each module to the end of the test queue
    for module in MODULE_ORDER:
        sorted_items = [it for it in sorted_items if module_mapping[it] != module] + [
            it for it in sorted_items if module_mapping[it] == module
        ]
    items[:] = sorted_items

def _collection_modifyitems(items):
    """Modifies test items in place to ensure test classes run in a given order."""
    CLASS_ORDER = ["Test_B","Test_C","Test_A", "Test_D"]
    sorted_items = items.copy()
    class_mapping = {item: item.cls.__name__ for item in items}

    
    # Iteratively move tests of each class to the end of the test queue
    for class_ in CLASS_ORDER:
        sorted_items = [it for it in sorted_items if class_mapping[it] != class_] + [
            it for it in sorted_items if class_mapping[it] == class_
        ]
        print(sorted_items)
   
    items[:] = sorted_items
    

