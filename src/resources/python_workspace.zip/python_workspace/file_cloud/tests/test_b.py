class Test_B:
    def test_A2(self):
        print('Executing File: B -> A2 Method')

    def test_B2(self):
        print('Executing File B -> B2 Method')

    def test_C2(self):
        print('Executing File B -> C2 Method')