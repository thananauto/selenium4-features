class Test_C:
    def test_A3(self):
        print('Executing File: C -> A3 Method')

    def test_B3(self):
        print('Executing File C -> B3 Method')

    def test_C3(self):
        print('Executing File C -> C3 Method')