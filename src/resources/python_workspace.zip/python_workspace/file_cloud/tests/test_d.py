class Test_D:
    def test_A4(self):
        print('Executing File: D -> A4 Method')

    def test_B4(self):
        print('Executing File D -> B4 Method')
    def test_C4(self):
        
        print('Executing File D -> C4 Method')