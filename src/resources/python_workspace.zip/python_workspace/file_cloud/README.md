# FileCloud Test Automation by pytest

* Prerequistes
1. Install the python stable version depending on the OS
2. Create the virtual envrironment `python -m venv venv`
3. Activate the virtual environment `./venv/Scripts/Activate.ps1` in the powershell



## Run options
1. pytest -k <keyword> -v
2. py.test <folder_name>

Generate default pytest-html report  
`pytest tests/ --html=report.html`
`pytest tests/ --html-report=./report --title='PYTEST REPORT'` pytest-html-reporter
`pytest tests/ -v -s -m delete` s-> stands for std.in, m -> marker, v -> more verbose
`pytest --collect-only` only show the collection method