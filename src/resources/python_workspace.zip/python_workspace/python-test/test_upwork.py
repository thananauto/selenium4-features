from playwright.sync_api import sync_playwright
import random
import os

# Global list of proxies
PROXIES = [
    None,
]


def test_scrape_page():
    with sync_playwright() as p:
        # Launches the browser
        browser = p.chromium.launch(headless=False)



        # Creates a new page with realistic headers
      #  context = browser.new_context(
       #     user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        #    viewport={"width": 720, "height": 1280},
        #)
        context = browser.new_context()
        # Opens a new page
        page = context.new_page()

        # Navigates to the given URL and waits until the page is fully loaded
        #page.goto(url, wait_until="load")

        # Scroll to the bottom of the page
        #page.evaluate("window.scrollTo(0, document.body.scrollHeight)")

        # Wait for 2 seconds to simulate user reading time
        #page.wait_for_timeout(2000)

        # Scroll back to the top of the page
        #page.evaluate("window.scrollTo(0, 0)")

        # Wait for 2 seconds before interacting with the button
       # page.wait_for_timeout(2000)

        # Check if .dk-modal__title appears and click on the last .domain-suggest__domain if it does
         # modal_title = page.query_selector(".dk-modal__title")
        #  if modal_title:
        #      domain_suggestions = page.query_selector_all(".domain-suggest__domain")
        #      if domain_suggestions:
          #        domain_suggestions[-1].click()

        # Click the first button with the specified CSS class
        # Click on the Download Table
        first_button = page.query_selector(".css-ocsfr4")
        if first_button:
            first_button.click()

            page.wait_for_timeout(2000)


            ############BUTTON DOES NOT WORK ################
            ############FIX THIS ################

            # Click on Download Button #####
            page.frame_locator()
            
            second_button = page.query_selector(".css-tvzbil")
            if second_button:
                print("Clicking on the download button")
                second_button.click()

                page.wait_for_timeout(10000)

            ############STUCK HERE ################

        browser.close()


proxy = random.choice(PROXIES)
url="https://www.digikey.com/en/products/filter/rf-transceiver-ics/879?s=N4IgrCBcoA5QjAGhDOl4AYMF9tA"
#scrape_page(
#    "https://www.digikey.com/en/products/filter/rf-transceiver-ics/879?s=N4IgrCBcoA5QjAGhDOl4AYMF9tA"
#)

test_scrape_page()