
import pytest
from playwright.sync_api import Page, expect, sync_playwright


def test_login():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        # Creates a new page with realistic headers
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            viewport={"width": 720, "height": 1280},
        )

        # Opens a new page
        page = context.new_page()
        #launch browserstack demo
        page.goto("https://bstackdemo.com/")
        #click on sign button
        page.click('#signin')
        #select Username
        page.get_by_text("Select Username").click()
        page.locator("#react-select-2-option-0-0").click()
        #select Password
        page.get_by_text("Select Password").click()
        page.locator("#react-select-3-option-0-0").click()
        #click login
        page.get_by_role("button", name="Log In").click()
        #verify user have logged in
        assert page.get_by_text("demouser").is_visible()