import re, pytest
from playwright.sync_api import Page, expect

from read_csv import get_file_data

@pytest.mark.parametrize("site", get_file_data())
def test_subscribe(page: Page, site):
    page.goto(f'https://{site[0]}')

    email_button = page.get_by_role('textbox', name=re.compile("email", re.IGNORECASE))
    email_button.scroll_into_view_if_needed()
    
    # set the email text field 
    email_button.evaluate("(node) => {node.value='test@email.com'}", 5)
    subsctibe = page.get_by_role('button', name=re.compile(r"(subscribe)", re.IGNORECASE))

    #click the subscribe or submit button
    subsctibe.evaluate("(node) => {node.click()}", 5)
    assert subsctibe.is_visible() == True