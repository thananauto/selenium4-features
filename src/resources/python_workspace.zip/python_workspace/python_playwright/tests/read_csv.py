
import csv

def get_file_data():
    output =[]
    with open('files/data.csv', mode ='r')as file:
        csvFile = csv.reader(file)
        for row in csvFile:
            output.append(row)
    return output

