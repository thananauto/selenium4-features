# Subscribe News Letter

Install python based on the OS [link](https://www.python.org/downloads/)

Activate the virtual environment `venv\Scripts\Activate.ps1` by running the command in windows

Install all dependcies `pip3 install -r requirements.txt`

Add the website address in the file `files\data.csv`

Install the browser dependencies `playwright install-deps chromium`

Execute this command in cmd in headless mode `pytest -v -s --browser-channel chromium` and if browser needs to launch `pytest -v -s --browser-channel chromium --headed `