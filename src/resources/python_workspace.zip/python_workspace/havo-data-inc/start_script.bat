@echo off
REM Automatically determine folder path relative to the batch file
set folderPath=%~dp0

REM Navigate to the Scripts directory
cd /d "%folderPath%\venv\Scripts"

REM Activate the virtual environment
call activate

REM Print confirmation message
echo Virtual environment activated.

REM Navigating back to root folder
cd /d "%folderPath%"

REM install the dependencies
pip3 install -r requirements.txt

REM execute the python file
python "%folderPath%\test.py"

REM Optional: Print a success message
echo  Type 'deactivate' to exit.
pause
