my_list = [1,3,5,6,8,9]


from itertools import count

infinite_iterator = count(3)

for i in range(5):
    print(next(infinite_iterator))