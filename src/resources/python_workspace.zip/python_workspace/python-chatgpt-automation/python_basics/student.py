


class Student:
    def __init__(self, name: str, age: int):
        self.name = name    
        self.age = age

    def display_info(self):
        print(f'Name: {self.name}, Age: {self.age}')

class XII(Student):
    _floor_name: str

    __num_of_students : int

    def __init__(self, name: str, age: int, roleNumber: int):
        super().__init__(name, age)   
        self.__roleNumber = roleNumber

    def get_full_info(self):
        print(f'{super().display_info()} and role number: {self.__roleNumber}')    

    def set__num_of_students (self, total:int):
        self.__num_of_students = total 

    def get_role_number(self):
            return self.__roleNumber
    
if __name__ == '__main__':
    stu_class = XII('Thanan', 30, 12)
    stu_class.get_full_info() 
    num = stu_class.get_role_number()
    print(num)
    stu_class.__roleNumber = 300
    num = stu_class.get_role_number()
    print(num)
    print(stu_class.__dict__)
    print(stu_class._XII__roleNumber)
    