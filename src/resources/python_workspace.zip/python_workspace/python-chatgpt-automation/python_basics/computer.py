class Computer:

    def __init__(self, price: int):
        self.__maxprice = price

    def sell(self):
        print("Selling Price: {}".format(self.__maxprice))

    def setMaxPrice(self, price):
        self.__maxprice = price

c = Computer(100)
c.sell()
print(c.__dict__)
# change the price
c.__maxprice = 1000
c.sell()
print(c.__dict__)
# using setter function
c.setMaxPrice(1000)
c.sell()
print(c.__dict__)