def checkerror(func):
    def inner(a, b):
        if( b==0):
            print(f" can't divide {a} by {b}")
            return
        return func(a,b)
    return inner

@checkerror
def divide(a, b):
    print(a/b)

divide(2,0)   
divide(2,4) 