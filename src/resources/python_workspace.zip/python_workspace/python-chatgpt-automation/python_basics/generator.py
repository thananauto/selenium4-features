
def square_number(n:int):
    value =0
   
    while(value<n):
        yield value
        value = value+1

def fibonacci_series(num: int):
    x, y = 0,1
    for __ in range(num):
        x, y = y, x+y
        yield x

def square_nunbers(nums: int):
    for num in nums:
         yield num * 2
for i in square_number(0):
    print(i)    

for i in square_nunbers(fibonacci_series(5)):
    print(i)    