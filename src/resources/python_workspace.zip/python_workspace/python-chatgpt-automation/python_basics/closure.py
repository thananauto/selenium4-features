
def add(num: int):
    def withAdd(x: int):
        return x+num
    
    return withAdd


def calculate(num: int):
    def operation(x: int):
        for i in range(num):
            yield i+x
    return operation        

add2 = add(2)
add3 = add(3)

print(add2(5))
print(add3(5))

cal10 = calculate(10)
cal5 = calculate(5)

for i in cal5(5):
    print(i)