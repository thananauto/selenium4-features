
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
from bs4 import BeautifulSoup
import pandas as pf


class GetVideosInfo:

    
    def __init__(self):
        self.__driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
        self.__driver.maximize_window()
        self.__driver.get('https://www.youtube.com/@vikatanwebtv/videos')
        
    def scroll_down_page(self,no_of_down:int):
        for _ in range(no_of_down):
            self.__driver.find_element(By.CSS_SELECTOR, 'body').send_keys(Keys.END)
            time.sleep(2)        

    
    # using BS to extract the required data
    def init_BS(self):
        self.master_list =[]
        soup = BeautifulSoup(self.__driver.page_source, 'html.parser')

        videos = soup.find_all('div',{ 'id' : 'dismissible'})

        for video in videos:
            data_dict = {}
            data_dict['title']  = video.find(id="video-title").text
            data_dict['url']    = 'https://www.youtube.com'+video.find(id="video-title-link")['href']
            meta = video.find('div', {'id':'metadata-line'}).find_all('span', {'class' : 'inline-metadata-item'})
            data_dict['views'] = meta[0].text
            data_dict['video_age'] = meta[1].text
            self.master_list.append(data_dict)

    # convert the 'K' and 'M' views in to realnmbers
    def _convert_views(self, df):
        if 'K' in df['views']:
            return float(df['views'].split('K')[0])*1000
        elif 'M' in df['views']:
            return  float(df['views'].split('K')[0])*1000000

    # export the output to csv files
    def export_to_csv(self):
        youtube_df = pf.DataFrame(self.master_list)
        youtube_df['CLEAN_VIEWS'] = youtube_df.apply(self._convert_views, axis=1)
        youtube_df.to_csv('youtube.csv', index=False)

    
if __name__ == '__main__':
    down_video= GetVideosInfo()
    down_video.scroll_down_page(no_of_down=2)
    down_video.init_BS()
    down_video.export_to_csv()
   




