import requests
from bs4 import BeautifulSoup
import pandas as pd

def get_welcome_text(clinic_id):
    url = f"https://{clinic_id}.portal.athenahealth.com/"
    response = requests.get(url)
    
    html = response.text
    soup = BeautifulSoup(html, 'html.parser')
    h1 = soup.find_all('h1')[-1].text.strip()
    return h1



start = 12693
end = 12710
master_list =[]
for each in range(start, end):
    each_type ={}
    each_type['clinical_id'] = each
    each_type['clinic_name'] = get_welcome_text(each)
    if  not ('Payment' in each_type['clinic_name'] or 'Sorry' in each_type['clinic_name'] or len(each_type['clinic_name'])==0):
        master_list.append(each_type)

df = pd.DataFrame(master_list)
df.to_csv('master_op.csv',index=False)
 