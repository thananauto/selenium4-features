import requests as req
from bs4 import BeautifulSoup as BS


sitemap_lsts =[]
# get all the urls from pngmart
def get_all_urls():
    url= 'https://www.pngmart.com/sitemap.xml'
    res = req.get(url=url)

    sitemap_urls = BS(res.text, 'xml')
    for url in sitemap_urls.find_all('loc'):
        if('posts' in url.text):
            sitemap_lsts.append(url.text)


master_list =[]
# get the first url from sitemap
def get_each_img_lst_urls():
    
    res = req.get(sitemap_lsts[0])
    img_url = BS(res.text, 'xml')
    for img in img_url.find_all('image:loc'):
        master_list.append(img.text)



def download_images():
    for item in master_list[1:5]:
        img_name = 'images/'+item.split('/')[-1]
        img_res = req.get(item)
        img_res.status_code
        content = img_res.content
        with open(img_name, 'wb') as file:
            file.write(content)
    
get_all_urls()
get_each_img_lst_urls()
download_images()