# write program about elapsed time
from datetime import datetime

start_time = '08:30:25'
end_time = '09:30:25'

t1 = datetime.strptime(start_time,"%H:%M:%S")
t2 = datetime.strptime(end_time,"%H:%M:%S")

t3 = (t2 - t1)
op = t3.total_seconds()
print(f'Total hrs: {op/3600} and total minutes: {op/60}')

# write enum

from enum import Enum

class Day(Enum):
    MONDAY = 'A'
    TUESDAY = 'B'
    WEDNESDAY = 'C'

print(Day)
Day.WEDNESDAY.value

# program to write counter

import time
def timer(number: int):
    
    while number:
        min, sec = divmod(number, 60)
        timeformat = '{:02d}:{:02d}'.format(min, sec)
        print(timeformat, end='\r')
        time.sleep(1)
        number-=1

timer(5)

# convert bytes to string
print(b'Easy \xE2\x9C\x85'.decode("utf-8"))