package com.qa.testng.tests;

import org.testng.ITestContext;
import org.testng.annotations.Test;
import static org.assertj.core.api.Assertions.*;
import static org.assertj.core.api.Assertions.*;
public class State2 extends Hooks {

    @Test(dependsOnGroups = "first", groups = "second")
    public void checkState2(ITestContext context){
        String op = (String) context.getAttribute("Hello");
        assertThat(op).isEqualTo("world");
    }
}
