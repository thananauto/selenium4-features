package com.qa.testng.tests;

import org.testng.ITestContext;
import org.testng.annotations.Test;

public class State1 extends Hooks {

    @Test(groups = "first")
    public void checkState1(ITestContext context){
        context.setAttribute("Hello", "World");
    }
}
