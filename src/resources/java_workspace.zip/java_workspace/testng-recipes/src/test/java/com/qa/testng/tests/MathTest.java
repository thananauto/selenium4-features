package com.qa.testng.tests;

import com.qa.testng.listeners.TransformListener;
import com.qa.testng.utility.MathsPojo;
import com.qa.testng.utility.MultiTest;
import lombok.SneakyThrows;
import org.assertj.core.api.Condition;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import static org.assertj.core.api.Assertions.*;



public class MathTest extends Hooks{

    @SneakyThrows
    @MultiTest
    @Test
    public void add(MathsPojo mathsPojo){
        Thread.sleep(1000);
        assertThat(mathsPojo.getInput1() + mathsPojo.getInput2())
                .as("Adding two numbers")
                .isGreaterThanOrEqualTo(mathsPojo.getInput1());
    }

    @SneakyThrows
    @MultiTest
    @Test
    public void sub(MathsPojo mathsPojo){
        Thread.sleep(1000);
        assertThat(mathsPojo.getInput1() - mathsPojo.getInput2())
                .as("Subtracting two numbers")
                .isLessThan(mathsPojo.getInput1());
    }

    @SneakyThrows
    @MultiTest
    @Test
    public void mul(MathsPojo mathsPojo){
        Thread.sleep(1000);
        assertThat(mathsPojo.getInput1() * mathsPojo.getInput2())
                .as("Multiply two numbers")
                .isGreaterThanOrEqualTo(mathsPojo.getInput1() + mathsPojo.getInput2());
    }

    @SneakyThrows
    @MultiTest
    @Test
    public void div(MathsPojo mathsPojo){
        Thread.sleep(1000);
        assertThat(mathsPojo.getInput1() / mathsPojo.getInput2())
                .as("Division two numbers")
                .isNotEqualTo(0);

    }
}
