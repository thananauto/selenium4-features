package com.qa.testng.tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class Hierachy {


    @BeforeSuite()
    public void suite(){

    }
    @BeforeClass()
    public void cls(){

    }

    @Test(invocationCount = 2)
    public void test(){
        System.out.println("Count");
    }
    @BeforeMethod()
    public void thd(){

    }
}
