package com.qa.testng.tests;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;

public class Hooks {

    @AfterMethod
    public void tearDown(ITestResult result){
        String className = result.getClass().getName();
        String MethodName = result.getMethod().getMethodName();
        long id = Thread.currentThread().getId();
        System.out.println("In Class: "+className+", Method: "+MethodName+" => Thread: "+id);

    }
}
