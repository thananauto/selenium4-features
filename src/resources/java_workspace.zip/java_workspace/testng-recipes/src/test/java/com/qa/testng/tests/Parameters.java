package com.qa.testng.tests;

import org.testng.annotations.Optional;
import org.testng.annotations.Test;
import static org.assertj.core.api.Assertions.*;
public class Parameters extends Hooks{

    @org.testng.annotations.Parameters("name")
    @Test
    public void checkParamsValue(@Optional String name){

        assertThat(name).isEqualTo("Thanan");

    }
}
