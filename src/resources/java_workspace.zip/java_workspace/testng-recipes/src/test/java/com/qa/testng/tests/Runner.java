package com.qa.testng.tests;

import com.qa.testng.listeners.TransformListener;
import org.testng.ITestNGListener;
import org.testng.TestNG;

import java.util.Arrays;

public class Runner {

    public static void main(String[] args) {
        TestNG testNg = new TestNG();
       // testNg.addListener(new TransformListener());
        //testNg.setTestClasses(new Class[]{MathTest.class});
        testNg.setXmlSuites(Arrays.asList());
        testNg.run();
    }
}
