#!/usr/bin/env bash
# Set to name or ID of the container to be watched.
CONTAINER=$(docker-compose ps | grep $1 | cut -f1 -d' ')
# Set timeout to the number of seconds you are willing to wait.
timeout=500
# Leave this alone
counter=0

# This first echo is important for keeping the output clean and not overwriting the previous line of output.
echo "Waiting for $CONTAINER to be ready (${counter}/${timeout})"

#This says that until docker inspect reports the container is in a running state, keep looping.
until [[ $(docker inspect --format '{{json .State.Running}}' $CONTAINER) == true ]]; do

  # If we've reached the timeout period, report that and exit to prevent running an infinite loop.
  if [[ $timeout -lt $counter ]]; then
    echo "ERROR: Timed out waiting for $CONTAINER to come up."
    exit 1
  fi

  # Every 5 seconds update the status
  if (( $counter % 5 == 0 )); then
    echo -e "\e[1A\e[KWaiting for $CONTAINER to be finish (${counter}/${timeout})"
  fi

  # Wait a two second and increment the counter
  sleep 2s
  counter=`expr $counter + 2`

  echo "counter value ${counter}"
done