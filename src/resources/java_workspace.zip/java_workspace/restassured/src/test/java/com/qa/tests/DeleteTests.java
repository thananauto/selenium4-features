package com.qa.tests;

import com.qa.annotation.FrameworkAnnotation;
import com.qa.reports.ExtentLogger;
import com.qa.setup.Base;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static io.restassured.RestAssured.given;
import static java.util.stream.Collectors.joining;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class DeleteTests extends Base {

    @Test
    @FrameworkAnnotation(code = "204", category = "DELETE", suite = "Smoke")
    public void deleteUser(){
        String id = "3776023";
        RequestSpecification specification = given()
                .spec(reqSpec())
                .pathParam("id", id);
        ExtentLogger.logRequest(specification);
        Response response = specification.delete("/public/v2/users/{id}");
        ExtentLogger.logResponse(response.asPrettyString());
        response.then()
                .log()
                .all()
                .spec(resSpec(HttpStatus.SC_NO_CONTENT));

    }


    @Test
    public void testnum(){
        String[] arr = {"apple3", "banana", "8", "7"};


        ArrayDeque<String> s = new ArrayDeque<>();
        s.push("h");
        s.push("u");
        s.push("i");

        System.out.println(s.peek());
        System.out.println(s.pop());




}

    @Test
    public void testArer(){
        int[] arr = {0,4, 8, 2,3};


        System.out.println(arr.length);
        System.out.println(factorial(9));
        //squareMatrix();
    }

    public BigInteger factorial(int n){
        if(n==1)
            return BigInteger.valueOf(1l);
        else
            return  factorial(n-1).multiply(BigInteger.valueOf(n));

    }

    @Test
    public void test(){
        // 78 + 87 = 165
        // 165 + 561 = 726
        // 726 + 627 = 1353
        //1353 + 3531 = 4884
       // System.out.println(createPhoneNumber(new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 0}));
        //System.out.println(naricis(1634));
        System.out.println(duplicateCount("abcdeaBReturnsTwo"));
    }
    public static int duplicateCount(String text) {
        // Write your code here
    int count = 0;
    String check ="";
        char[] charcter = text.toCharArray();
        for(int i =0; i<charcter.length; i++){
              if(!(text.indexOf(charcter[i]) == text.lastIndexOf(charcter[i]))){
                if(!check.contains(String.valueOf(charcter[i]))) {
                    check += charcter[i];
                    count++;
                }
            }
        }

        return count;

    }

    public static boolean naricis(int number){
        int result = 0;
        int input = number;
        while(number >0){
            int op = number % 10;

            result+=Math.pow(op, String.valueOf(input).length());

            number = number / 10;
        }
        return input == result ? true : false;
    }
    public int pal_length(long n){
        String op ="";
        char[] s = (n+"").toCharArray();
        for(int i = s.length-1; i>= 0; i--){
            op+= s[i];
        }
        int counter =0;
        while(!op.equals(n+"")){
            ++counter;
            long x = n + Long.parseLong(op);
            counter+= pal_length(x);
        }

        return counter;
    }
    public static String createPhoneNumber(int[] numbers) {
        // Your code here!
        String op = Arrays.stream(numbers)
                .boxed()
                .map(Object::toString)
                .collect(Collectors.joining(""));

       // String op =Arrays.stream(numbers).mapToObj(x- > String.valueOf(x));      // String op = Arrays.toString(numbers).replaceAll(",","").replace("[","").replace("]","");

        return "("+op.substring(0,3)+") "+op.substring(3,6)+"-"+op.substring(6, op.length()-1);

    }


    }




