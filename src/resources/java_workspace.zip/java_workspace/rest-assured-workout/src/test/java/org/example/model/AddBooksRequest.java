package org.example.model;

import lombok.AllArgsConstructor;

import java.util.List;

@AllArgsConstructor
public class AddBooksRequest {

    private String userId;
    public List<ISBN> collectionOfIsbns;

}
