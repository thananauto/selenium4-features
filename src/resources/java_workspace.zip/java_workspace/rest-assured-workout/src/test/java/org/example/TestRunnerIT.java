package org.example;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.example.model.Book;
import org.example.model.Credentials;
import org.example.model.Token;
import org.example.model.UpdateBook;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class TestRunnerIT {


    private RestAssured restAssured;
    private String base_url = "https://bookstore.toolsqa.com";
    private String token_value;
    @Test(priority = 0)
    public void I_m_authorised_user(){
        RestAssured.baseURI = "https://bookstore.toolsqa.com";
        String username = "TOOLSQA-Test";
        String password = "Test@@123";

        Credentials credentials = new Credentials();
        credentials.setPassword(password);
        credentials.setUserName(username);

        RequestSpecification request = RestAssured.given();
        Response response = request
                .contentType(ContentType.JSON)
                .body(credentials)
                .post("/Account/v1/GenerateToken");

        Assert.assertEquals(response.getStatusCode(), 200);
        Token token = response.getBody().as(Token.class);
        token_value = token.getToken();

    }

    @Test(priority = 1)
    public void list_of_books() throws IOException {
        RestAssured.baseURI = base_url;
        RequestSpecification request = RestAssured.given();
        Response response = request.get("/BookStore/v1/Books");


       JsonPath jsonPath =     response.jsonPath();


    }

    @Test(enabled = false)
    public void authoriseUser() throws IOException {
        RestAssured.baseURI = "https://bookstore.toolsqa.com";
        String username = "TOOLSQA-Test";
        String password = "Test@@123";

      ;

        Credentials credentials = new Credentials();
        credentials.setPassword(password);
        credentials.setUserName(username);

        RequestSpecification request = RestAssured.given();
         Response response = request
                 .contentType(ContentType.JSON)
                        .body(credentials)
                        .post("/Account/v1/GenerateToken");

        Assert.assertEquals(response.getStatusCode(), 200);
        Token token = response.getBody().as(Token.class);
        System.out.println(token.getToken());
    }
    @Test(enabled = false)
    public void queryParameter(){
        restAssured.baseURI = "https://demoqa.com/BookStore/v1";
        RequestSpecification httpRequest = restAssured.given();


        Response response = httpRequest.queryParam("ISBN","9781449325862").get("/Book");

        ResponseBody responseBody = response.getBody();

        JsonPath jsonPath = new JsonPath(responseBody.asString());
        System.out.println(jsonPath.getString("title").toString());


    }

    @Test(enabled = false)
    public void test(){
        //set the base url
        restAssured.baseURI = "https://demoqa.com/BookStore/v1/Books";

        //set the request specification
        RequestSpecification requestHTTP = restAssured.given();

        Response response =requestHTTP.get();

        System.out.println( response.getStatusLine());
        System.out.println(response.prettyPrint());


    }
}
