package org.example.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Token {
    private String result;
    private String status;
    private String expires;
    private String token;
}
