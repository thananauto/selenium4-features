package org.example.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class Credentials {

   public String userName;
   public String password;


}
