package org.example.model;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class ISBN {
    private String isbn;
}
