package org.example.model;

public interface Tester {

final int num = 2;
    void tete();
}
