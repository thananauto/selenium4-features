package org.example.model;

import io.restassured.mapper.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;

public class RemoveJson {

    @Test
    public void testJson() throws Exception {
        ClassLoader classloader = Thread.currentThread().getContextClassLoader();
        InputStream is = classloader.getResourceAsStream("remove.json");


        String input = new String(is.readAllBytes());

        JSONObject json = new JSONObject(input);

       /* json.getJSONObject("data")
                        .getJSONObject("attributes")
                                .getJSONArray("borrowerInfo")
                .getJSONObject(0).remove("age");*/
        //json.remove("data");
        JSONObject op = streamRemoveKey(json, "age");

        System.out.println(op.toString(1));

    }

    public static JSONObject streamRemoveKey(JSONObject obj, String keyMain){

         obj.toMap().entrySet().stream()
                 .forEach(e -> {
                     String key = e.getKey();
                     if ((key.equals(keyMain)) || ((obj.optJSONArray(key)==null) && (obj.optJSONObject(key)==null))) {
                         // if ((key.equals(keyMain))) {
                         obj.remove(key);
                         // }
                     }else

                     // if it's jsonobject
                     if (obj.optJSONObject(key) != null) {
                         streamRemoveKey(obj.getJSONObject(key), keyMain);
                     }else

                     // if it's jsonarray
                     if (obj.optJSONArray(key) != null) {
                         JSONArray jArray = obj.getJSONArray(key);

                         for (int i=0;i<jArray.length();i++) {

                             streamRemoveKey(jArray.getJSONObject(i), keyMain);
                         }
                     }
                 });

        return obj;
    }
    public static JSONObject removeKey(JSONObject obj, String keyMain) throws Exception {
        // We need to know keys of Jsonobject
       // JSONObject json = new JSONObject();
        Iterator iterator = obj.keys();
        String key = null;
        while (iterator.hasNext()) {
            key = (String) iterator.next();
            // if object is just string we change value in key
            if ((key.equals(keyMain)) || ((obj.optJSONArray(key)==null) && (obj.optJSONObject(key)==null))) {
               // if ((key.equals(keyMain))) {
                    obj.remove(key);
                    return obj;
               // }
            }

            // if it's jsonobject
            if (obj.optJSONObject(key) != null) {
                removeKey(obj.getJSONObject(key), keyMain);
            }

            // if it's jsonarray
            if (obj.optJSONArray(key) != null) {
                JSONArray jArray = obj.getJSONArray(key);

                for (int i=0;i<jArray.length();i++) {

                    removeKey(jArray.getJSONObject(i), keyMain);
                }
            }
        }
        return obj;
    }

}
