package org.example.model;

import lombok.Getter;
import lombok.Setter;
import org.testng.annotations.Test;

@Getter
@Setter
public class Book implements Tester{
    private String isbn;
    private String title;
    private String subTitle;
    private String author;
    private String publish_date;
    private String publisher;
    private String description;

    @Override
    public void tete() {

    }
}
