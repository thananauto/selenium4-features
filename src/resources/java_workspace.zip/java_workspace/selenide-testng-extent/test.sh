 docker build -t thananauto/solar-system:latest .
  docker images
  docker run --name solar-system -d \
  -e MONGO_URI=mongodb+srv://supercluster.d83jj.mongodb.net/superData \
  -e MONGO_USERNAME=superuser \
  -e MONGO_PASSWORD=*** \
  thananauto/solar-system:latest

  ip_addr=$(docker inspect -f '{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' solar-system)

  if ! [ $(curl -s -o /dev/null -w '%{http_code}' http://$ip_addr:3000) == 200 ]; then \
     exit 1 \
  fi


if ! [ $(curl -s -o /dev/null -w '%{http_code}' http://$ip_addr:3000) == 201 ]; then
        exit 1
fi