package com.qa.listners;

import com.qa.utility.InfluxDBManager;
import org.influxdb.dto.Point;
import org.testng.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class InfluxDBSuiteListner implements ISuiteListener {
     public void onStart(ISuite suite) {

    }
    static Map<String, Integer> testCasestatus = new HashMap<>();
    public void onFinish_new(ISuite suite) {

        Map<String, ISuiteResult> resultMap = suite.getResults();
        ISuiteResult result = resultMap.entrySet().iterator().next().getValue();
        ITestContext testContext = result.getTestContext();
        String suiteName =  testContext.getCurrentXmlTest().getSuite().getName();
        IResultMap failedTests = testContext.getFailedTests();
        IResultMap passedTests = testContext.getPassedTests();
        IResultMap skippedTests = testContext.getSkippedTests();

        Map<String, Integer> testCasestatus = new HashMap<>();

        failedTests.getAllResults().forEach(e->{
            String testCaseName = e.getTestName().split("_")[1];
            int status = e.getStatus();
            testCasestatus.put(testCaseName, status);
        });

        passedTests.getAllResults().forEach(e->{
            String testCaseName = e.getTestName();
            int status = e.getStatus();
            testCasestatus.put(testCaseName, status);
        });

        skippedTests.getAllResults().forEach(e->{
            String testCaseName = e.getTestName();
            int status = e.getStatus();
            testCasestatus.put(testCaseName, status);
        });


        //Iterate the result map
        testCasestatus.entrySet().forEach(e->{

            String testName = e.getKey();
            int status = e.getValue();
            //update
        });
    }

     public void onFinish(ISuite suite) {

         Map<String, ISuiteResult> resultMap = suite.getResults();
         ISuiteResult result = resultMap.entrySet().iterator().next().getValue();
         ITestContext testContext = result.getTestContext();
          String suiteName =  testContext.getCurrentXmlTest().getSuite().getName();
         IResultMap failedTests = testContext.getFailedTests();

         IResultMap passedTests = testContext.getPassedTests();
         IResultMap skippedTests = testContext.getSkippedTests();
         Set<ITestResult> rsly = testContext.getFailedTests().getAllResults();

         //postOverallResult(suiteName, passedTests.size(), failedTests.size(), skippedTests.size());
         //post test results in grafana
         postContextResults(suiteName, testContext);
         Map<String, Integer> exception = new HashMap<>();
         for(ITestResult testResult :failedTests.getAllResults()){
                String expName = testResult.getThrowable().getClass().getSimpleName();
             if(exception.containsKey(expName)){
                 exception.put(expName, exception.get(expName)+1);
             }else{
                 exception.put(expName, 0);
             }
         }
        //post the exception details in Graffana
         exception.entrySet().stream().forEach(e-> {
             postExceptionResult_new(e.getKey(),e.getValue());
         });
     }
     private void postExceptionResult(Map<String, Integer> map){
         Point point = Point.measurement("Exception").time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                 .tag(map
                         .entrySet()
                         .stream()
                         .map(e->e)
                         .collect(Collectors.toMap(Map.Entry::getKey, e->String.valueOf(e.getValue()))))
                 .addField("Total", String.valueOf((map.size()))).build();

         InfluxDBManager.post(point);
     }
    private void postOverallResult(String suiteName, int pass, int fail, int skip) {
        Point point = Point.measurement(suiteName).time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                .tag("pass", String.valueOf(pass))
                .tag("fail", String.valueOf(fail))
                .tag("skip", String.valueOf(skip))
                .addField("Total", String.valueOf((pass+fail+skip))).build();
                //.addField("duration", (iTestResult.getEndMillis() - iTestResult.getStartMillis())).build();
        InfluxDBManager.post(point);
    }

    private void postExceptionResult_new(String tagName, int count){
        Point point = Point.measurement("Exception_new").time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                        .tag("ExceptionName", tagName)
                        .addField("Total", count).build();
        InfluxDBManager.post(point);
    }



    private void postOverallResult_new(String suiteName, String tagName, int count) {
        Point point = Point.measurement(suiteName).time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                .tag("Status", tagName)
                .addField("Total", count).build();
        InfluxDBManager.post(point);
    }
    private void postContextResults(String suiteName,ITestContext testContext){
         Map<String, Integer> mapResults = new HashMap<>();
         mapResults.put("pass", testContext.getPassedTests().size());
        mapResults.put("fail", testContext.getFailedTests().size());
        mapResults.put("skip", testContext.getSkippedTests().size());

        mapResults.entrySet().stream().forEach(e->{
            postOverallResult_new(suiteName,e.getKey(), e.getValue());
        });
    }
    }

