package com.qa.listners;

import com.qa.utility.InfluxDBManager;
import org.influxdb.dto.Point;
import org.testng.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class InfluxDBListener implements ITestListener, ISuiteListener {

    public void onTestSuccess(ITestResult iTestResult) {
        this.postTestMethodStatus(iTestResult, "PASS");
    }

    public void onTestFailure(ITestResult iTestResult) {
        this.postTestMethodStatus(iTestResult, "FAIL");
    }

    public void onTestSkipped(ITestResult iTestResult) {
        this.postTestMethodStatus(iTestResult, "SKIPPED");
    }

    public void onFinish(ITestContext iTestContext) {
        this.postTestClassStatus(iTestContext);
    }

    private void postTestMethodStatus(ITestResult iTestResult, String status) {
        Point point = Point.measurement("testmethod").time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                .tag("testclass", iTestResult.getTestClass().getName())
                .tag("name", iTestResult.getName())
                .tag("description", iTestResult.getMethod().getDescription())
                .tag("result", status)
                .addField("duration", (iTestResult.getEndMillis() - iTestResult.getStartMillis())).build();
        InfluxDBManager.post(point);
    }

    private void postTestClassStatus(ITestContext iTestContext) {
        Point point = Point.measurement("testclass").time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                .tag("name", iTestContext.getAllTestMethods()[0].getTestClass().getName())
                .addField("duration", (iTestContext.getEndDate().getTime() - iTestContext.getStartDate().getTime()))
                .build();
        InfluxDBManager.post(point);
    }

    public void onStart(ISuite suite) {
    }

    public void onFinish(ISuite suite) {
        Map<String, ISuiteResult> resultMap = suite.getResults();
        ISuiteResult result = resultMap.entrySet().iterator().next().getValue();
        ITestContext testContext = result.getTestContext();
        String suiteName =  testContext.getCurrentXmlTest().getSuite().getName();
        IResultMap failedTests = testContext.getFailedTests();
        IResultMap passedTests = testContext.getPassedTests();
        IResultMap skippedTests = testContext.getSkippedTests();
        Set<ITestResult> rsly = testContext.getFailedTests().getAllResults();

        //postOverallResult(suiteName, passedTests.size(), failedTests.size(), skippedTests.size());
        //post test results in grafana
        postContextResults(suiteName, testContext);
        Map<String, Integer> exception = new HashMap<>();
        for(ITestResult testResult :failedTests.getAllResults()){
            String expName = testResult.getThrowable().getClass().getSimpleName();
            if(exception.containsKey(expName)){
                exception.put(expName, exception.get(expName)+1);
            }else{
                exception.put(expName, 0);
            }
        }
        //post the exception details in Graffana
        exception.entrySet().forEach(e-> {
            postExceptionResult(e.getKey(),e.getValue());
        });
    }



    private void postExceptionResult(String tagName, int count){
        Point point = Point.measurement("Exception").time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                .tag("ExceptionName", tagName)
                .addField("Total", count).build();
        InfluxDBManager.post(point);
    }



    private void postOverallResult(String suiteName, String tagName, int count) {
        Point point = Point.measurement(suiteName).time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                .tag("Status", tagName)
                .addField("Total", count).build();
        InfluxDBManager.post(point);
    }
    private void postContextResults(String suiteName,ITestContext testContext){
        Map<String, Integer> mapResults = new HashMap<>();
        mapResults.put("pass", testContext.getPassedTests().size());
        mapResults.put("fail", testContext.getFailedTests().size());
        mapResults.put("skip", testContext.getSkippedTests().size());

        mapResults.entrySet().stream().forEach(e->{
            postOverallResult(suiteName,e.getKey(), e.getValue());
        });
    }


}
