package nl.superp.testautomation.core;


import nl.superp.testautomation.parameters.TestData;
import nl.superp.testautomation.parameters.FrameworkParameters;
import nl.superp.testautomation.reports.Report;
import nl.superp.testautomation.utilities.Settings;
import nl.superp.testautomation.utilities.UserActions;
import org.openqa.selenium.WebDriver;

import java.util.Properties;


/**
 * Abstract base class for reusable libraries created by the user
 * @author rthanan
 * @version 1.0
 * @since June 2019
 */
public abstract class ReusableLibrary
{
	/**
	 * The {@link TestData} object (passed from the test script)
	 */
	protected TestData testData;
	/**
	 * The {@link Report} object (passed from the test script)
	 */
	protected Report report;
	/**
	 * The {@link WebDriver} object
	 */
	protected WebDriver driver;
	/**
	 * The {@link ScriptHelper} object (required for calling one reusable library from another)
	 */
	protected ScriptHelper scriptHelper;
	
	/**
	 * The {@link Properties} object with settings loaded from the framework properties file
	 */
	protected Properties properties = Settings.getInstance();
	/**
	 * The {@link FrameworkParameters} object
	 */
	protected FrameworkParameters frameworkParameters = FrameworkParameters.getInstance();

	/**
	 * The {@link UserActions} object
	 */
	protected UserActions userActions;
	
	
	/**
	 * Constructor to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it
	 * @param scriptHelper The {@link ScriptHelper} object
	 * @param: driver The {@link WebDriver} object
	 */
	public ReusableLibrary(ScriptHelper scriptHelper)
	{
		this.scriptHelper = scriptHelper;
		this.testData = scriptHelper.getTestData();
		this.report = scriptHelper.getReport();
		this.driver = scriptHelper.getDriver();
		this.userActions = new UserActions(driver, report, testData);
	}
}