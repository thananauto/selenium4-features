package nl.superp.testautomation.parameters;

public enum IterationOptions
{
  RunAllIterations, 

  RunOneIterationOnly, 

  RunRangeOfIterations;
}