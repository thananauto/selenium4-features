package nl.superp.testautomation.parameters;

public class CommonData {
	
	public String strProductName;
	public int strQuantity;
	public String strUserName;
	public String strProductCount;
	
	
	
}
