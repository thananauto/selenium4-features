package nl.superp.testautomation.core;


import nl.superp.testautomation.parameters.TestData;
import nl.superp.testautomation.reports.Report;
import org.openqa.selenium.WebDriver;


/**
 * Wrapper class for common framework objects, to be used across the entire test case and dependent libraries
 * @author rthanan
 * @version 1.0
 * @since June 2019
 */
public class ScriptHelper
{
	private final TestData testData;
	private final Report report;
	private final WebDriver driver;

	
	/**
	 * Constructor to initialize all the objects wrapped by the {@link ScriptHelper} class
	 * @param testData The {@link TestData} object
	 * @param report The {@link Report} object
	 * @param driver The {@link WebDriver} object
	 */
	public ScriptHelper(TestData testData, Report report, WebDriver driver)
	{
		this.testData = testData;
		this.report = report;
		this.driver = driver;

	}
	
	/**
	 * Function to get the {@link TestData} object of the {@link ScriptHelper} class
	 * @return The {@link TestData} object
	 */
	public TestData getTestData()
	{
		return testData;
	}
	
	/**
	 * Function to get the {@link Report} object of the {@link ScriptHelper} class
	 * @return The {@link Report} object
	 */
	public Report getReport()
	{
		return report;
	}
	
	/**
	 * Function to get the {@link WebDriver} object of the {@link ScriptHelper} class
	 * @return The {@link WebDriver} object
	 */
	public WebDriver getDriver()
	{
		return driver;
	}


}