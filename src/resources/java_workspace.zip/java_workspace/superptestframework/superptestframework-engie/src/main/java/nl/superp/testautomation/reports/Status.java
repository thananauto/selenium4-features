package nl.superp.testautomation.reports;

public enum Status
{
  FAIL, 

  WARNING, 

  PASS, 

  SCREENSHOT, 

  DONE, 

  DEBUG;
}