package nl.superp.testautomation.exception;

public enum OnError
{
  NextIteration, 

  NextTestCase, 

  Stop;
}