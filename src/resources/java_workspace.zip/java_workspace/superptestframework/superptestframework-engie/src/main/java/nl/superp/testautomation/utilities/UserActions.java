package nl.superp.testautomation.utilities;

import nl.superp.testautomation.parameters.TestData;
import nl.superp.testautomation.reports.Report;
import nl.superp.testautomation.reports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

/**
 * This class contains, commonly used actions on web page
 */
public class UserActions {

	private WebDriver driver;
	private Report report;
	private TestData testData;

	public UserActions(WebDriver driver, Report report, TestData testData) {
		this.driver = driver;
		this.report = report;
		this.testData = testData;
	}



	public void openUrl(String url){
		try{
			driver.get(url);
			report.updateTestLog("Launch the application url", "URL:<b>"+url+"</b> is launched", Status.PASS);
		}catch (Exception e){
			report.updateTestLog("Launch the application url", "URL:<b>"+url+"</b> is not successfully launched", Status.FAIL);
		}
	}

	/**
	 * Method to validate element is present
	 * @param element
	 * @return
	 */
	public boolean isElementPresent(WebElement element) {

		boolean toReturn;
		try {
			return element.isDisplayed();
		} catch (Exception e) {
			toReturn = false;
		}
		return toReturn;
	}

	/**
	 * Method to validate element is present
	 * @param element
	 * @return
	 */
	public boolean isElementPresentIDE(WebElement element, String description) {

		boolean toReturn;
		try {
			toReturn = element.isDisplayed();
			report.updateTestLog(description, "The element is present", Status.PASS);
			return toReturn;
		} catch (Exception e) {
			report.updateTestLog(description, "The element is not present", Status.FAIL);
			toReturn = false;
		}
		return toReturn;
	}

	/**
	 * Method to validate element is present
	 * @param element
	 * @return
	 */
	public boolean isElementNotPresentIDE(WebElement element, String description) {

		boolean toReturn;
		try {
			toReturn = element.isDisplayed();
			report.updateTestLog(description, "The element is present", Status.FAIL);
			return false;
		} catch (Exception e) {
			report.updateTestLog(description, "The element is not present", Status.PASS);
			toReturn = true;
		}
		return toReturn;
	}


	public void waitForElementToPresent(By by, int timeSecs, String description){

		try {
			WebDriverWait wait = new WebDriverWait(driver, timeSecs);
			wait.until(ExpectedConditions.presenceOfElementLocated(by));
			report.updateTestLog(description, "The element is present", Status.PASS);
		}catch(Exception e){
			report.updateTestLog(description, "The element is not present", Status.FAIL);

		}
	}


	public void switchToFrameByElement(WebElement frame,  String description){

		try {
			driver.switchTo().frame(frame);
			report.updateTestLog(description, "switched successfully to frame ", Status.PASS);
		}catch(Exception e){
			report.updateTestLog(description, "switched is not successfull to frame ", Status.FAIL);
		}

	}

	public void switchToDefaultContent(){


		try {
			driver.switchTo().defaultContent();
			report.updateTestLog("Frame switched to default content", "", Status.PASS);
		}catch(Exception e){
			report.updateTestLog("Frame switched to default content is failed", "", Status.FAIL);
		}

	}

	/**
	 * Method to validate the element is not present
	 * @param element
	 * @return
	 */
	public boolean isElementNotPresent(WebElement element) {
		boolean toReturn = false;

		try {
			return !element.isDisplayed();
		} catch (Exception e) {
			toReturn = true;
		}
		return toReturn;

	}

	/**
	 * method to clear the text box
	 * @param elements
	 */
	public void clear(WebElement... elements) {
		boolean isDisplayedEdtBox = false;
		for (WebElement eachElement : elements) {
				eachElement.clear();

		}

	}

	/**
	 * Method to make the element visible
	 * @param element
	 */

	public void makeBlock(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].style.display = 'block'", element);
	}

	/**
	 * Method to return the visible element
	 * @param lstEle
	 * @return
	 */
	public WebElement returnVisibleElement(List<WebElement> lstEle) {
		for (WebElement element : lstEle) {
			try {
				if (element.isDisplayed())
					return element;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;

	}

	/**
	 * Method to click on web page
	 * @param buttonElementName
	 * @param btnName
	 * @param strPageName
	 */
	public void clickButton(WebElement buttonElementName, String btnName, String strPageName){
		boolean blnFlag = false;
		
		try {
			   buttonElementName.click();
				blnFlag=true;

		} catch (WebDriverException wdexc) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", buttonElementName);
			blnFlag=true;
		} catch (Exception exc){
			blnFlag=false;
		}
		
		if(blnFlag)
			report.updateTestLog("Click the <b>"+btnName+"</b> button from <b>"+strPageName+"</b>", "<b>"+btnName+"</b> button is clicked successfully", Status.PASS);
		else
			report.updateTestLog("Click the <b>"+btnName+"</b> button from <b>"+strPageName+"</b>", "<b>"+btnName+"</b> button is not clicked successfully", Status.FAIL);
	}

	/**
	 * Method to click on web page
	 * @param description
	 */
	public void clickButtonIDE(WebElement buttonElementName, String description){
		boolean blnFlag = false;

		try {
			buttonElementName.click();
			blnFlag=true;

		} catch (WebDriverException wdexc) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", buttonElementName);
			blnFlag=true;
		} catch (Exception exc){
			report.updateTestLog(description, "Button is not successfully clicked", Status.FAIL);
			return;
		}

		if(blnFlag)
			report.updateTestLog(description, "User action successfully completed", Status.PASS);
		else
			report.updateTestLog(description, "Button is not successfully clicked", Status.FAIL);
	}
	/**
	 * Method to click the link on web page
	 * @param linkElementName
	 * @param lnkName
	 * @param strPageName
	 */
	public void clickLink(WebElement linkElementName, String lnkName, String strPageName){
		boolean blnFlag = false;
		
		try {
			linkElementName.click();
			blnFlag=true;
		} catch (WebDriverException wdexc) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", linkElementName);
			blnFlag=true;
		} catch (Exception exc){
			blnFlag=false;
		}
		
		if(blnFlag)
			report.updateTestLog("Click the <b>"+lnkName+"</b> link from "+strPageName, "<b>"+lnkName+"</b> link is clicked successfully", Status.PASS);
		else
			report.updateTestLog("Click the <b>"+lnkName+"</b> link from "+strPageName, "<b>"+lnkName+"</b> link is not clicked successfully", Status.FAIL);
	}

	/**
	 * Method to enter in to text box
	 * @param editBox
	 * @param strFieldValue
	 * @param strFieldName
	 * @param strPageName
	 */
	public void typeInEditBox(WebElement editBox, String strFieldValue,String strFieldName, String strPageName){
		boolean blnFlag = false;
		
		if(isElementPresent(editBox)){
			editBox.clear();
			editBox.sendKeys(strFieldValue);
			blnFlag=true;
		}
		
		if(blnFlag)
			report.updateTestLog("Enter the text <b>"+strFieldValue+"</b> for the field <b>"+strFieldName+"</b> in "+strPageName+" page", "Text successfully entered", Status.PASS);
		else
			report.updateTestLog("Enter the text <b>"+strFieldValue+"</b> for the field <b>"+strFieldName+"</b> in "+strPageName+" page", "Unable to enter the text in <b>"+strFieldName+"</b>", Status.FAIL);
		
	}
	/**
	 * Method to enter in to text box
	 * @param editBox
	 * @param strFieldValue
	 * @param description
	*/
	public void typeInEditBoxIDE(WebElement editBox, String strFieldValue, String description){
		boolean blnFlag = false;

		if(isElementPresent(editBox)){
			editBox.clear();
			editBox.sendKeys(strFieldValue);
			blnFlag=true;
		}

		if(blnFlag)
			report.updateTestLog(description, "Text successfully entered", Status.PASS);
		else
			report.updateTestLog(description, "Unable to enter the text", Status.FAIL);

	}

	/**
	 * Method to verify text contains in the element
	 * @param objIdentifier
	 * @param expectedValue
	 * @param pageName
	 */
	public void verifyElementTextContains(WebElement objIdentifier, String expectedValue, String pageName){
		
		if(isElementPresent(objIdentifier)){
			String actualValue=objIdentifier.getText().trim();
			
			if(actualValue!=null && actualValue.contains(expectedValue))
				report.updateTestLog("Verify <b>"+expectedValue+"</b> text present in page <b>"+pageName+"</b>", "Text present in page <b>"+pageName+"</b>", Status.PASS);
			else
				report.updateTestLog("Verify <b>"+expectedValue+"</b> text present in page <b>"+pageName+"</b>", "Actual text: <b>"+actualValue+"</b> and Expected text: <b>"+expectedValue+"</b>", Status.FAIL);
		
		}
	}


	/**
	 * Method to verify text contains in the element
	 * @param objIdentifier
	 * @param expectedValue
	 */
	public void verifyElementTextContainsIDE(WebElement objIdentifier, String expectedValue, String description){

		if(isElementPresent(objIdentifier)){
			String actualValue=objIdentifier.getText().trim();

			if(actualValue!=null && actualValue.contains(expectedValue))
				report.updateTestLog(description, expectedValue+ " text present in the element", Status.PASS);
			else
				report.updateTestLog(description, expectedValue+" text not present on the element", Status.FAIL);

		}
	}

	public void selectByText(WebElement selectIdentifier, String textName, String pageName){

		try {
			Select select = new Select(selectIdentifier);
			select.selectByVisibleText(textName);
			report.updateTestLog("Select the <b>"+textName+"</b> in the dropdown", "Value successfully selected", Status.PASS);
		} catch (Exception e) {
			report.updateTestLog("Select the <b>"+textName+"</b> in the dropdown", "Unable to select the value from dropdown "+e.getMessage(), Status.FAIL);
		}


	}

	public void selectByTextIDE(WebElement selectIdentifier, String textName, String description){

		try {
			Select select = new Select(selectIdentifier);
			select.selectByVisibleText(textName);
			report.updateTestLog(description, "Value successfully selected", Status.PASS);
		} catch (Exception e) {
			report.updateTestLog(description, "Unable to select the value from dropdown "+e.getMessage(), Status.FAIL);
		}


	}
	public void selectByValueIDE(WebElement selectIdentifier, String textName, String description){

		try {
			Select select = new Select(selectIdentifier);
			select.selectByValue(textName);
			report.updateTestLog(description, "Value successfully selected", Status.PASS);
		} catch (Exception e) {
			report.updateTestLog(description, "Unable to select the value from dropdown "+e.getMessage(), Status.FAIL);
		}


	}
	public void selectByIndexIDE(WebElement selectIdentifier, String index, String description){

		try {
			Select select = new Select(selectIdentifier);
			select.selectByIndex(Integer.parseInt(index));
			report.updateTestLog(description, "Value successfully selected", Status.PASS);
		} catch (Exception e) {
			report.updateTestLog(description, "Unable to select the value from dropdown "+e.getMessage(), Status.FAIL);
		}


	}
	public boolean waitForJStoLoad(int timeout) {

		WebDriverWait wait = new WebDriverWait(driver, timeout);

		// wait for jQuery to load
		ExpectedCondition<Boolean> jQueryLoad = new ExpectedCondition<Boolean>() {

			@Override
			public Boolean apply(WebDriver driver) {
				try {
					JavascriptExecutor js = ((JavascriptExecutor)driver);
					return ((Long)(js.executeScript("return jQuery.active")) == 0);
				}
				catch (Exception e) {
					return true;
				}
			}
		};

		// wait for Javascript to load
		ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				JavascriptExecutor js = ((JavascriptExecutor)driver);
				return js.executeScript("return document.readyState")
						.toString().equals("complete");
			}
		};

		return wait.until(jQueryLoad) && wait.until(jsLoad);
	}



     }