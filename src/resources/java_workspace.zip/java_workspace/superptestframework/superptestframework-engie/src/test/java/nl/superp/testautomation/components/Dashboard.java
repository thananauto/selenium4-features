package nl.superp.testautomation.components;

import nl.superp.testautomation.core.ReusableLibrary;
import nl.superp.testautomation.core.ScriptHelper;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Dashboard extends ReusableLibrary {
    /**
     * Constructor to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it
     *
     * @param scriptHelper The {@link ScriptHelper} object
     * @param: driver The {@link: WebDriver} object
     */
    public Dashboard(ScriptHelper scriptHelper) {
        super(scriptHelper);
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//a[contains(.,'Nieuws')]/span")
    private WebElement objLinkNews;

    @FindBy(xpath = "//button[contains(.,'Voeg nieuw bericht toe')]/span")
    private WebElement objButtonAddaMsg;



    public void addMessage(){
        userActions.clickLink(objLinkNews, "News", "Dashboard");
        userActions.clickButton(objButtonAddaMsg, "Voeg nieuw bericht toe", "Dashboard");
    }


}
