package nl.superp.testautomation.components;

import nl.superp.testautomation.parameters.CommonData;
import nl.superp.testautomation.core.ReusableLibrary;
import nl.superp.testautomation.core.ScriptHelper;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Home extends ReusableLibrary {
    /**
     * Constructor to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it
     *
     * @param scriptHelper The {@link ScriptHelper} object
     * @param: driver The {@link: WebDriver} object
     */
    public Home(ScriptHelper scriptHelper) {
        super(scriptHelper);
        PageFactory.initElements(driver, this);
    }
    private CommonData commonData;

    /**
     * Add all the element properties
     */

    @FindBy(css = "#usernameInput")
    private WebElement objTxtUserName;
    @FindBy(css = "#passwordInput")
    private WebElement objTxtPassword;
    @FindBy(css = "#loginButton")
    private WebElement objSignIn;

    @FindBy(css = ".glyphicon-menu-hamburger")
    private WebElement objMenuBar;

    @FindBy(partialLinkText = "LogUit")
    private WebElement objLogOut;




    public void openApplication(){
        userActions.openUrl(properties.getProperty("url"));
    }

    public void login(){
        String userName = testData.getData("UserName");
        String password = testData.getData("Password");
        userActions.typeInEditBox(objTxtUserName, userName, "UserName", "Home");
        userActions.typeInEditBox(objTxtPassword, password, "Password", "Home");
        userActions.clickButton(objSignIn, "Sign In", "Home");
    }

    public void logOut(){
        userActions.clickButton(objMenuBar, "menu", "Home");
        userActions.clickButton(objLogOut, "logout", "Home");

    }

}
