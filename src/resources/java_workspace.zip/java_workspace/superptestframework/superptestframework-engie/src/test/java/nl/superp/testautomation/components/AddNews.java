package nl.superp.testautomation.components;

import nl.superp.testautomation.core.ReusableLibrary;
import nl.superp.testautomation.core.ScriptHelper;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddNews extends ReusableLibrary {
    /**
     * Constructor to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it
     *
     * @param scriptHelper The {@link ScriptHelper} object
     * @param: driver The {@link: WebDriver} object
     */
    public AddNews(ScriptHelper scriptHelper) {
        super(scriptHelper);
        PageFactory.initElements(driver, this);
    }

    @FindBy(css = "input[value='Mededeling']")
    private WebElement objMededeling;

    @FindBy(xpath = "//button[contains(.,'Ga verder')]")
    private WebElement objGaVerder;

    @FindBy(css = "input[value='AlleStudenten_HU']")
    private WebElement objAllStudentHU;

    @FindBy(xpath = "//label[contains(.,'myHU')]")
    private WebElement objMyHU;

    @FindBy(css = "#mxui_widget_EnumSelect_0")
    private WebElement objSelectLanguage;



    public void selectCommunication(){
        userActions.clickButton(objMededeling, "Mededeling", "AddNews");
        userActions.clickButton(objGaVerder, "GaVerder", "AddNews");
       }

    public void selectTargetAudience(){
        userActions.clickButton(objAllStudentHU, "All students with HU", "Target Audience");
        userActions.clickButton(objGaVerder, "GaVerder", "Target Audience");

    }

    public void selectChannel(){
        userActions.clickLink(objMyHU, "myHU checkbox","Channels");
        userActions.clickButton(objGaVerder, "GaVerder", "Target Audience");
    }


    public void selectLanguage(){
        userActions.selectByText(objSelectLanguage, "Engels", "Add News");
    }


}
