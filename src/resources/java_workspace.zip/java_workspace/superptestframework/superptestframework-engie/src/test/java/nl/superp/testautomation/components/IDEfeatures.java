package nl.superp.testautomation.components;

import nl.superp.testautomation.core.ReusableLibrary;
import nl.superp.testautomation.core.ScriptHelper;
import nl.superp.testautomation.core.SeleniumIDE;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;

public class IDEfeatures extends ReusableLibrary {
    /**
     * Constructor to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it
     *
     * @param scriptHelper The {@link ScriptHelper} object
     * @param: driver The {@link: WebDriver} object
     */
    public IDEfeatures(ScriptHelper scriptHelper) {
        super(scriptHelper);
    }

    private SeleniumIDE seleniumIDE;

    /**
     * Method to click the element on webpage
     */
    public void click(){
        if(seleniumIDE.getTarget().contains("objSelectFltr_Crted_On")){
            WebElement element = objElement(seleniumIDE.getTarget());
        }
        WebElement element = objElement(seleniumIDE.getTarget());
        userActions.clickButtonIDE(element, seleniumIDE.getDescription());
    }


    /**
     * Method to open the application
     */
    public void open(){

        if(seleniumIDE.getValue().startsWith("#")){
            String parameter = testData.getData(seleniumIDE.getValue().substring(1,seleniumIDE.getValue().length()));
            seleniumIDE.setValue(parameter);
        }
        userActions.openUrl(seleniumIDE.getValue());

        }

    /**
     * Method to enter the text in text box
      */
    public void type(){

        if(seleniumIDE.getValue().startsWith("#")){
            String parameter = testData.getData(seleniumIDE.getValue().substring(1,seleniumIDE.getValue().length()));
            seleniumIDE.setValue(parameter);
        }
        WebElement element = objElement(seleniumIDE.getTarget());
        userActions.typeInEditBoxIDE(element,seleniumIDE.getValue(), seleniumIDE.getDescription()+": "+seleniumIDE.getValue());

        }

    /**
     * Method to select the value from dropdown using text
     */
    public void selectByText(){
        if(seleniumIDE.getValue().startsWith("#")){
            String parameter = testData.getData(seleniumIDE.getValue().substring(1,seleniumIDE.getValue().length()));
            seleniumIDE.setValue(parameter);
        }
        WebElement element = objElement(seleniumIDE.getTarget());
        userActions.selectByTextIDE(element,seleniumIDE.getValue(), seleniumIDE.getDescription()+": "+seleniumIDE.getValue());
    }

    /**
     * Method to select the value from dropdown using value
     */
    public void selectByValue(){
        if(seleniumIDE.getValue().startsWith("#")){
            String parameter = testData.getData(seleniumIDE.getValue().substring(1,seleniumIDE.getValue().length()));
            seleniumIDE.setValue(parameter);
        }
        WebElement element = objElement(seleniumIDE.getTarget());
        userActions.selectByTextIDE(element,seleniumIDE.getValue(), seleniumIDE.getDescription()+": "+seleniumIDE.getValue());
    }

    /**
     * Method to select the value from dropdown using index
     */
    public void selectByIndex(){
        if(seleniumIDE.getValue().startsWith("#")){
            String parameter = testData.getData(seleniumIDE.getValue().substring(1,seleniumIDE.getValue().length()));
            seleniumIDE.setValue(parameter);
        }
        WebElement element = objElement(seleniumIDE.getTarget());
        userActions.selectByTextIDE(element,seleniumIDE.getValue(), seleniumIDE.getDescription()+": "+seleniumIDE.getValue());
    }

    /**
     * Method to validate whether element should be present
     */
    public void verifyElementPresent(){
        if(seleniumIDE.getValue().startsWith("#")){
            String parameter = testData.getData(seleniumIDE.getValue().substring(1,seleniumIDE.getValue().length()));
            seleniumIDE.setValue(parameter);
        }
        WebElement element = objElement(seleniumIDE.getTarget());
        userActions.isElementPresentIDE(element, seleniumIDE.getDescription());

    }

    public void verifyElementTextContains(){
        if(seleniumIDE.getValue().startsWith("#")){
            String parameter = testData.getData(seleniumIDE.getValue().substring(1,seleniumIDE.getValue().length()));
            seleniumIDE.setValue(parameter);
        }

        WebElement element = objElement(seleniumIDE.getTarget());
        userActions.verifyElementTextContainsIDE(element,  seleniumIDE.getValue(),  seleniumIDE.getDescription());


    }

    /**
     * Method to validate whether element should be present
     */
    public void verifyElementNotPresent(){
        if(seleniumIDE.getValue().startsWith("#")){
            String parameter = testData.getData(seleniumIDE.getValue().substring(1,seleniumIDE.getValue().length()));
            seleniumIDE.setValue(parameter);
        }
        WebElement element = objElement(seleniumIDE.getTarget());
        userActions.isElementNotPresentIDE(element, seleniumIDE.getDescription());

    }

    public void waitForElementToPresent(){
        if(seleniumIDE.getValue().startsWith("#")){
            String parameter = testData.getData(seleniumIDE.getValue().substring(1,seleniumIDE.getValue().length()));
            seleniumIDE.setValue(parameter);
        }

        userActions.waitForElementToPresent(By(seleniumIDE.getTarget()), Integer.parseInt(seleniumIDE.getValue()), seleniumIDE.getDescription());

    }


    public void setWindowSize(){

        if(seleniumIDE.getValue().startsWith("#")){
            String parameter = testData.getData(seleniumIDE.getValue().substring(1,seleniumIDE.getValue().length()));
            seleniumIDE.setValue(parameter);
        }
        int width = Integer.parseInt(seleniumIDE.getValue().split(",")[0]);
        int height = Integer.parseInt(seleniumIDE.getValue().split(",")[1]);


        Dimension d = new Dimension(width,height);
        //Resize current window to the set dimension
        driver.manage().window().setSize(d);
    }

    public void navigateBack(){
        driver.navigate().back();
    }


    public void switchToFrameByElement(){
        if(seleniumIDE.getValue().startsWith("#")){
            String parameter = testData.getData(seleniumIDE.getValue().substring(1,seleniumIDE.getValue().length()));
            seleniumIDE.setValue(parameter);
        }
        WebElement element = objElement(seleniumIDE.getTarget());
        userActions.switchToFrameByElement(element, seleniumIDE.getDescription());
    }

    public void switchToDefaultContent(){
        userActions.switchToDefaultContent();
    }



    private WebElement objElement(String properties){

        if (properties.toLowerCase().startsWith("obj")) {
           properties = testData.getObjRepoData(properties);
        }

        String selectorStrategy = properties.split("=")[0];

        String selectorValue = properties.substring(selectorStrategy.length()+1, properties.length());

                if(selectorStrategy.equalsIgnoreCase("xpath"))
                    return driver.findElement(By.xpath(selectorValue));
                else if(selectorStrategy.equalsIgnoreCase("name"))
                    return driver.findElement(By.name(selectorValue));
                else  if(selectorStrategy.equalsIgnoreCase("className"))
                    return driver.findElement(By.className(selectorValue));
                else  if(selectorStrategy.equalsIgnoreCase("cssSelector") || selectorStrategy.equalsIgnoreCase("css"))
                    return driver.findElement(By.cssSelector(selectorValue));
                else  if(selectorStrategy.equalsIgnoreCase("linkText"))
                    return driver.findElement(By.linkText(selectorValue));
                else  if(selectorStrategy.equalsIgnoreCase("partialLinkText"))
                    return driver.findElement(By.partialLinkText(selectorValue));
                else  if(selectorStrategy.equalsIgnoreCase("id"))
                    return driver.findElement(By.id(selectorValue));
                else  if(selectorStrategy.equalsIgnoreCase("tagName"))
                    return driver.findElement(By.tagName(selectorValue));
                else
                    return null;


    }

    private By By(String properties){

        if (properties.toLowerCase().startsWith("obj")) {
            properties = testData.getObjRepoData(properties);
        }

        String selectorStrategy = properties.split("=")[0];

        String selectorValue = properties.substring(selectorStrategy.length()+1, properties.length());

        if(selectorStrategy.equalsIgnoreCase("xpath"))
            return By.xpath(selectorValue);
        else if(selectorStrategy.equalsIgnoreCase("name"))
            return By.name(selectorValue);
        else  if(selectorStrategy.equalsIgnoreCase("className"))
            return By.className(selectorValue);
        else  if(selectorStrategy.equalsIgnoreCase("cssSelector") || selectorStrategy.equalsIgnoreCase("css"))
            return By.cssSelector(selectorValue);
        else  if(selectorStrategy.equalsIgnoreCase("linkText"))
            return By.linkText(selectorValue);
        else  if(selectorStrategy.equalsIgnoreCase("partialLinkText"))
            return By.partialLinkText(selectorValue);
        else  if(selectorStrategy.equalsIgnoreCase("id"))
            return By.id(selectorValue);
        else  if(selectorStrategy.equalsIgnoreCase("tagName"))
            return By.tagName(selectorValue);
        else
            return null;


    }

    public void waitForPageLoad(){
        if(seleniumIDE.getValue().startsWith("#")){
            String parameter = testData.getData(seleniumIDE.getValue().substring(1,seleniumIDE.getValue().length()));
            seleniumIDE.setValue(parameter);
        }
        userActions.waitForJStoLoad(Integer.parseInt(seleniumIDE.getValue()));
    }

    public void implicitWait() throws InterruptedException {
        if(seleniumIDE.getValue().startsWith("#")){
            String parameter = testData.getData(seleniumIDE.getValue().substring(1,seleniumIDE.getValue().length()));
            seleniumIDE.setValue(parameter);
        }

        Thread.sleep(Integer.parseInt(seleniumIDE.getValue())*1000);
    }
}
