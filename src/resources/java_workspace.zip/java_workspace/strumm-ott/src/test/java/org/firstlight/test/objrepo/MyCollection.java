package org.firstlight.test.objrepo;

import org.openqa.selenium.By;

public class MyCollection {

    public By objMyCollection = By.xpath("//android.widget.TextView[@text='My Collection']");
    public By objContinueWatching = By.xpath("//android.widget.TextView[@text='Continue Watching']");
    public By objExpiringSoon = By.xpath("//android.widget.TextView[@text='Expiring Soon']");
    public By objRedeemedMovies = By.xpath("//android.widget.TextView[@text='Redeemed Movies']");

    public By objContinueWatchParent = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text='Continue Watching']/following-sibling::android.widget.HorizontalScrollView");
    public By objExpiringSoonParent = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text='Expiring Soon']/following-sibling::android.widget.HorizontalScrollView");
    public By objRedeemedMoviesParent = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text='Redeemed Movies']/following-sibling::android.widget.HorizontalScrollView");

    public By objHorCards = By.xpath("//android.view.ViewGroup[@content-desc='Card View']//android.widget.TextView");
    public By objAnyMovieMyCollection = By.xpath("(//android.view.ViewGroup[@content-desc='Card View'])[3]//android.widget.ImageView");
    public By objAnyMySubsMovie = By.xpath("//android.view.ViewGroup[@content-desc='Card View']/android.view.ViewGroup[2]/android.view.ViewGroup/android.view.ViewGroup[2]/android.widget.ImageView");



}