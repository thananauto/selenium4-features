package org.firstlight.test.pages;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import org.firstlight.test.core.ReusableLibrary;
import org.firstlight.test.core.ScriptHelper;
import org.firstlight.test.objrepo.ObjectRepository;
import org.openqa.selenium.By;

import java.util.Properties;

public class Generic extends ReusableLibrary {
    /**
     * Constructor to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it
     *
     * @param scriptHelper The {@link ScriptHelper} object
     * @param: driver The {@link MobileDriver} object
     */

    private ObjectRepository oR;

    public Generic(ScriptHelper scriptHelper) {
        super(scriptHelper);
        oR = ObjectRepository.getInstance();
    }

    public void launchApp(){
        userActions.openApp();

        userActions.verifyVisibilityOfElement(oR.getBrowseObjects().objJustAdded, 20, "Home Page");
    }

    public void launchAppLogin() throws Exception{
        userActions.adb_uninstall_app();
        //driver.resetApp();
        driver.installApp(System.getProperty("user.dir")+"\\struum-app.apk");
        userActions.openApp();
        userActions.verifyVisibilityOfElement(oR.getHomeObjects().objLogin, 30, "Login");
    }

    public void navigateMovies(){
        userActions.adb_shell_command(21, "left_key_pad");
        userActions.waitForSecs(2);
       // userActions.navigateAllMenus("Movies");
        //TODO: click on the left menu is not working

        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.waitForSecs(3);
        userActions.adb_shell_command(66, "key_enter");
        userActions.waitForSecs(3);
        //add validation
        userActions.verifyVisibilityOfElement(oR.getMoviesObjects().objStruumSelects, 15, "Movies page");

    }

    public void navigateTv(){
        //TODO: click on the left menu is not working
        userActions.waitForSecs(3);
        userActions.adb_shell_command(21, "left_key_pad");
        userActions.waitForSecs(3);
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.waitForSecs(3);
        userActions.adb_shell_command(66, "key_enter");
        userActions.waitForSecs(3);
        //add validation
        userActions.verifyVisibilityOfElement(oR.getMoviesObjects().objStruumSelects, 15, "Tv page");

    }




    public void navigateShorts(){
        //TODO: click on the left menu is not working
        userActions.waitForSecs(3);
        userActions.adb_shell_command(21, "left_key_pad");
        userActions.waitForSecs(3);
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.waitForSecs(3);
        userActions.adb_shell_command(66, "key_enter");
        userActions.waitForSecs(3);
        //add validation
        userActions.verifyVisibilityOfElement(oR.getShortsObjects().objIndieDiscoveries, 15, "Shorts page");

    }

    public void navigateSettings(){
        //TODO: click on the left menu is not working
        userActions.waitForSecs(3);
        userActions.adb_shell_command(21, "left_key_pad");
        userActions.waitForSecs(2);
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.waitForSecs(2);
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.waitForSecs(2);
        userActions.adb_shell_command(66, "key_enter");
        userActions.waitForSecs(3);
        //add validation
        userActions.verifyVisibilityOfElement(oR.getSettingsObjects().objStruumSubscription, 15, "Settings page");

    }



    public void navigateToAddCredits(){
        userActions.waitForSecs(3);
        userActions.adb_shell_command(21, "left_key_pad");
        userActions.waitForSecs(3);
        userActions.adb_shell_command(19, "Up_key_pad");
        userActions.waitForSecs(3);
        userActions.adb_shell_command(19, "up_key_pad");

        userActions.click(oR.getCreditsObjects().objAddCredits, "Add to credits");
    }

    public void topToBottomScroll(){
        String bottomText  = testData.getData("Bottom Text");
        userActions.scrollToBottom(bottomText);

    }

    public void bottomToTopScroll(){
        String topText = testData.getData("Top Text");
        userActions.scrollToUp(topText);
    }
    public void navigateToMySubs(){

        //TODO: click on the left menu is not working
        userActions.waitForSecs(3);
        userActions.adb_shell_command(21, "left_key_pad");
        userActions.waitForSecs(2);
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.waitForSecs(2);
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.waitForSecs(2);
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.waitForSecs(2);
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.waitForSecs(2);
        userActions.adb_shell_command(66, "key_enter");
        userActions.waitForSecs(3);

        userActions.verifyVisibilityOfElement(oR.getMyCollectionObjects().objContinueWatching, 15, "My Subscription page");


    }
}
