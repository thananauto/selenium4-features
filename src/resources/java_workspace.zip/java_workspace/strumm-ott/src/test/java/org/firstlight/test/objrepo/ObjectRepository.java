package org.firstlight.test.objrepo;

import java.util.Objects;

public class ObjectRepository {

    private ObjectRepository(){
        //disable the constrcutor
    }

    public static ObjectRepository objectRepository;

    public static ObjectRepository getInstance(){
        if(Objects.isNull(objectRepository)){
            return new ObjectRepository();
        }
        return objectRepository;
    }

    private  HomeObjects homeObjects;

    public HomeObjects getHomeObjects() {
        if(Objects.isNull(homeObjects)){
            return new HomeObjects();
        }
        return homeObjects;
    }

    private ShortsObjects shortsObjects;

    public ShortsObjects getShortsObjects() {
        if(Objects.isNull(shortsObjects)){
            return new ShortsObjects();
        }
        return shortsObjects;
    }

    private BrowseObjects browseObjects;

    public BrowseObjects getBrowseObjects() {
        if(Objects.isNull(browseObjects)){
            return new BrowseObjects();
        }
        return browseObjects;
    }


    private CreditsObjects creditsObjects;

    public CreditsObjects getCreditsObjects() {
        if(Objects.isNull(creditsObjects)){
            return new CreditsObjects();
        }
        return creditsObjects;
    }
    private MoviesObjects moviesObjects;

    public MoviesObjects getMoviesObjects() {
        if(Objects.isNull(moviesObjects)){
            return new MoviesObjects();
        }
        return moviesObjects;
    }


    private TVObjects TVObjects;

    public TVObjects getTVObjects() {
        if(Objects.isNull(TVObjects)){
            return new TVObjects();
        }
        return TVObjects;
    }


    private SearchObjects searchObjects;

    public SearchObjects getSearchObjects() {
        if(Objects.isNull(searchObjects)){
            return new SearchObjects();
        }
        return searchObjects;
    }
    private SettingsObjects settingsObjects;

    public SettingsObjects getSettingsObjects() {
        if (Objects.isNull(settingsObjects)) {
            return new SettingsObjects();
        }
        return settingsObjects;
    }

    private MyCollection myCollection;

    public MyCollection getMyCollectionObjects(){
        if(Objects.isNull(myCollection)){
            return new MyCollection();
        }
        return myCollection;
    }

}
