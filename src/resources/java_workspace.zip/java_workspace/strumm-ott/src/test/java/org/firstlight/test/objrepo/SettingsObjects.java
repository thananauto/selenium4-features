package org.firstlight.test.objrepo;

import org.openqa.selenium.By;

public class SettingsObjects {
    public By objSettings = By.xpath("//android.widget.TextView[@text='Settings']");
    public By objStruumSubscription = By.xpath("//android.widget.TextView[@text='Struum Subscription']");
    public By objSubscriberSince = By.xpath("//android.widget.TextView[contains(@text,'Subscriber since')]");
    public By objBirthday = By.xpath("//android.widget.TextView[contains(@text,'Birthday')]");
    public By objName = By.xpath("//android.widget.TextView[contains(@text,'Name')]");


    public By objH1Legal = By.xpath("//android.view.ViewGroup/following-sibling::android.widget.TextView[@text='Legal']");
    public By objH1Help = By.xpath("//android.view.ViewGroup/following-sibling::android.widget.TextView[@text='Help']");
    public By objH1CreditsWalkThrough = By.xpath("//android.view.ViewGroup/following-sibling::android.widget.TextView[@text='Credits Walkthrough']");
    public By objSignedInto = By.xpath("//android.view.ViewGroup/following-sibling::android.widget.TextView[contains(@text,'Signed into')]");

    public By objAccount = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text='Account']/..");
    public By objProfile = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text='Profile']/..");
    public By objLegal = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text='Legal']/..");
    public By objHelp = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text='Help']/..");
    public By objCreditsWalkthrough = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text='Credits Walkthrough']/..");
    public By objSignOut = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text='Sign Out']/..");

    public By objLinkSignOut = By.xpath("(//android.widget.TextView[@text='Sign Out'])[2]");

    public By objYesImSure = By.xpath("//android.widget.TextView[@text='Yes, I’m sure']");
    public By objNoKeepWatching = By.xpath("//android.widget.TextView[@text='No, keep watching']");


}
