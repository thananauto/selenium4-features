package org.firstlight.test.objrepo;

import org.openqa.selenium.By;

public class CreditsObjects {



    public By objCreditsList = By.xpath("//android.widget.HorizontalScrollView//android.view.ViewGroup[count(./android.widget.TextView) = 3]/android.widget.TextView[1]");

    public By objAddCredits  = By.xpath("//android.widget.TextView[@text='Add Credits']");
    public By obj20Credits  = By.xpath("//android.widget.TextView[@text='20 Credits']");
    public By obj40Credits  = By.xpath("//android.widget.TextView[@text='40 Credits']");
    public By obj60Credits  = By.xpath("//android.widget.TextView[@text='60 Credits']");

    public By obj099Credits  = By.xpath("//android.widget.TextView[@text='$0.99']");
    public By obj199Credits  = By.xpath("//android.widget.TextView[@text='$1.99']");
    public By obj299Credits  = By.xpath("//android.widget.TextView[@text='$2.99']");


    public By obj20CreditMsg = By.xpath("//android.widget.TextView[@text='Your card will be charged $0.99 and 20 credits will immediately be added to your account.']");
    public By obj40CreditMsg = By.xpath("//android.widget.TextView[@text='Your card will be charged $1.99 and 40 credits will immediately be added to your account.']");
    public By obj60CreditMsg = By.xpath("//android.widget.TextView[@text='Your card will be charged $2.99 and 60 credits will immediately be added to your account.']");


    public By objCreditsConfirm = By.xpath("//android.widget.TextView[@text='Confirm']");


}
