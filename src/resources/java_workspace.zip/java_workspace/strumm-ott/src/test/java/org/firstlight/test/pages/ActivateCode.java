package org.firstlight.test.pages;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class ActivateCode {

    public static WebDriver driver;


    private static void init(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
    }

    private static void login(String userName, String password){
        WebDriverWait wait = new WebDriverWait(driver, 30);
        driver.get("https://struum.com/Login");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        //click the proceed button

        //enter the email
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector("input[type='email']")));
        driver.findElement(By.cssSelector("input[type='email']")).sendKeys(userName);
        //enter the password
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector("input[type='password']")));
        driver.findElement(By.cssSelector("input[type='password']")).sendKeys(password);
        //click the submit
        driver.findElement(By.cssSelector("button[type='submit']")).click();
    }


    public static boolean linkAnAccount(String code, String userName, String password) {

        try{
            init();

            login(userName, password);

            Thread.sleep(3000);
            //get the activate Url
            driver.get("https://struum.com/activate");


            WebDriverWait wait = new WebDriverWait(driver, 20);
            wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector("input[formcontrolname='activate']")));
            //enter the OTP

            driver.findElement(By.cssSelector("input[formcontrolname='activate']")).sendKeys(code.trim());

            //link a device
            driver.findElement(By.cssSelector("button[type='submit']")).click();


            wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//span[contains(.,'Success')]")));
            Thread.sleep(3000);

        }catch (Exception e){
                quit();
                return false;
        }

        quit();
        return true;
    }

    public static void deleteDevices(String username, String password){

        try{
            init();
            login(username, password);
            driver.get("https://www.aha.video/account/devices");

            List<WebElement> lstDeleteIcons = driver.findElement(By.cssSelector(".delete-icon"));

            for(WebElement eachIcon: lstDeleteIcons){
                eachIcon.click();
                driver.findElement(By.cssSelector("input[type='password']")).sendKeys("Password@1234");
                driver.findElement(By.cssSelector(".btn-primary")).click();
            }
        }catch (Exception e){
            quit();
        }
        quit();
    }

    public static void quit(){
        if(driver!=null)
            driver.quit();
    }


}
