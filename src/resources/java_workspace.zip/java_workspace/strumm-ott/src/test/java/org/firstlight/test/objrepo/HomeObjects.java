package org.firstlight.test.objrepo;

import io.appium.java_client.MobileBy.*;
import org.openqa.selenium.By;
import org.openqa.selenium.By.*;

import java.util.Objects;

public class HomeObjects{

    public By objYourName = By.xpath("//android.widget.EditText");
    public By objContinue = By.xpath("//android.widget.TextView[@text='Continue']");

    public By objMonth = By.xpath("(//android.widget.EditText)[1]");
    public By objDay = By.xpath("(//android.widget.EditText)[2]");

    public By objHomeLoaded = By.id("android:id/content");

    public By objLogin = By.xpath("//android.widget.TextView[@text='Log In']");
    public By objSignUp = By.xpath("//android.widget.TextView[@text='Sign up']");
    public By objCode = By.xpath("//android.widget.TextView");


}
