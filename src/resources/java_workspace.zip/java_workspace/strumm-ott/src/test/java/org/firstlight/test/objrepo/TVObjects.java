package org.firstlight.test.objrepo;

import org.openqa.selenium.By;

public class TVObjects {

    public  By objTV = By.xpath("//android.widget.TextView[@text='TV']");
    public By objStruumSelects = By.xpath("//android.widget.TextView[@text='Struum Selects']");

}
