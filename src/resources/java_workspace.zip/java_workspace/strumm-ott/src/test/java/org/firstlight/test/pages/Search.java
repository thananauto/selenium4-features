package org.firstlight.test.pages;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import org.firstlight.test.core.ReusableLibrary;
import org.firstlight.test.core.ScriptHelper;
import org.firstlight.test.objrepo.ObjectRepository;
import org.firstlight.test.reports.Status;

import java.util.List;

public class Search extends ReusableLibrary {
    private ObjectRepository oR = ObjectRepository.getInstance();
    /**
     * Constructor to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it
     *
     * @param scriptHelper The {@link ScriptHelper} object
     * @param: driver The {@link org.openqa.selenium.WebDriver} object
     */

    public Search(ScriptHelper scriptHelper) {
        super(scriptHelper);

    }

    public void goToSearch(){
        userActions.adb_shell_command(21, "left_key_pad");
        userActions.waitForSecs(2);
        userActions.adb_shell_command(19, "key_pad_up");
        userActions.adb_shell_command(66, "key_enter");
    }

    public void searchFilm(){
        String searchText= testData.getData("Film Name");
        userActions.waitForSecs(4);
        userActions.typeByButtons(searchText);

    }

    public void chooseRelatedMovie(){
        //this method is the continuation of method search film
        String filmName = testData.getData("Film Name");
        List<MobileElement> lstMovies = ((AndroidDriver) driver).findElements(oR.getSearchObjects().objSearchResultList);

        if(lstMovies.size()>0){
            for(MobileElement element: lstMovies){
                //click the first movie
                String movieName = element.getText();
                if(movieName.toLowerCase().contains(filmName.toLowerCase())){
                    element.click();
                    report.updateTestLog("Click the movie: "+filmName, "", Status.PASS);
                    break;
                }
            }

        }else {
            report.updateTestLog("No result returned for given text: "+filmName, "", Status.FAIL);
        }
    }

    public void noSearchResultFound(){
        String filmName = testData.getData("Film Name");
        userActions.getText(oR.getSearchObjects().objNotFindAnyResult,"Could not find any results matching in \""+filmName+"\".");

    }


    public void searchMenus(){
        userActions.verifyVisibilityOfElement(oR.getSearchObjects().objMostPopular, 15, "Most Popular");

        userActions.click(oR.getSearchObjects().objJustAdded, "Just Added");
        userActions.verifyVisibilityOfElement(oR.getSearchObjects().objNavResults, 15, "Just Added lists");

        userActions.click(oR.getSearchObjects().objChannels,  "Channels");
        userActions.verifyVisibilityOfElement(oR.getSearchObjects().objNavResults, 15, "channel lists");

        userActions.click(oR.getSearchObjects().objMovies, "Movies");
        userActions.verifyVisibilityOfElement(oR.getSearchObjects().objNavResults, 15, "Movies lists");

        userActions.click(oR.getSearchObjects().objTvShows, "TV Shows");
        userActions.verifyVisibilityOfElement(oR.getSearchObjects().objNavResults, 15, "TV Shows");

    }


}
