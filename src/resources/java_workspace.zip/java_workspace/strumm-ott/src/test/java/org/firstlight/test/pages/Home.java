package org.firstlight.test.pages;

import io.appium.java_client.MobileElement;
import org.firstlight.test.core.ReusableLibrary;
import org.firstlight.test.core.ScriptHelper;
import org.firstlight.test.objrepo.ObjectRepository;
import org.firstlight.test.reports.Status;

import java.util.List;

public class Home extends ReusableLibrary {

    private ObjectRepository oR;
    /**
     * Constructor to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it
     *
     * @param scriptHelper The {@link ScriptHelper} object
     * @param: driver The {@link org.openqa.selenium.WebDriver} object
     */
    public Home(ScriptHelper scriptHelper) {
        super(scriptHelper);
        oR = ObjectRepository.getInstance();
    }

    public void login(){


        String userName = testData.getData("Username");
        String passWord = testData.getData("Password");

        userActions.verifyVisibilityOfElement(oR.getHomeObjects().objLogin, 15, "Login");
        userActions.adb_shell_command(20, "dpad_down");
        userActions.adb_shell_command(66, "dpad_enter");
        //call the test scripts for login

        userActions.waitForSecs(8);
        List<MobileElement> lstCode = driver.findElements(oR.getHomeObjects().objCode);

        MobileElement ele = lstCode.stream()
                .filter(mobileElement -> mobileElement.getText().trim().length() == 6 )
                .findFirst()
                .orElse(null);
        String code = ele.getText();
        //TODO: Make sure the chrome browser should be installed in client machine
        boolean appStatus = ActivateCode.linkAnAccount(code, userName, passWord);

        if(appStatus)
            report.updateTestLog("User successfully linked the account", "", Status.PASS);
        else
            report.updateTestLog("User is not successfully linked the account", "", Status.FAIL);
    }

}
