package org.firstlight.test.pages;

import org.firstlight.test.core.ReusableLibrary;
import org.firstlight.test.core.ScriptHelper;
import org.firstlight.test.objrepo.ObjectRepository;

public class Settings extends ReusableLibrary {
    /**
     * Constructor to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it
     *
     * @param scriptHelper The {@link ScriptHelper} object
     * @param: driver The {@link org.openqa.selenium.WebDriver} object
     */
    public Settings(ScriptHelper scriptHelper) {
        super(scriptHelper);
    }

    private ObjectRepository oR = ObjectRepository.getInstance();;

    public void goToSettings(){
        userActions.adb_shell_command(21, "left_key_pad");
        userActions.waitForSecs(2);
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.waitForSecs(2);
        userActions.adb_shell_command(66, "key_enter");

    }

    public void verifyAccount(){
        userActions.verifyVisibilityOfElement(oR.getSettingsObjects().objStruumSubscription, 15, "Settings page");
        userActions.verifyFocusedElement(oR.getSettingsObjects().objAccount, "focused", "profile");

    }

    public void verifyProfile(){
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.verifyVisibilityOfElement(oR.getSettingsObjects().objSubscriberSince, 15, "Subscription since");
        userActions.verifyFocusedElement(oR.getSettingsObjects().objProfile, "focused", "profile");
        userActions.verifyVisibilityOfElement(oR.getSettingsObjects().objName, 15, "Name");
        userActions.verifyVisibilityOfElement(oR.getSettingsObjects().objBirthday, 15, "Birthday");

    }


    public void verifyLegal(){
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.verifyVisibilityOfElement(oR.getSettingsObjects().objH1Legal, 15, "Legal header");
        userActions.verifyFocusedElement(oR.getSettingsObjects().objLegal, "focused", "legal");

    }

    public void verifyHelp(){
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.verifyVisibilityOfElement(oR.getSettingsObjects().objH1Help, 15, "Help header");
        userActions.verifyFocusedElement(oR.getSettingsObjects().objHelp, "focused", "help");

    }

    public void verifyCreditsWalkthrough(){
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.verifyVisibilityOfElement(oR.getSettingsObjects().objH1CreditsWalkThrough, 15, "Credits Walkthrough header");
        userActions.verifyFocusedElement(oR.getSettingsObjects().objCreditsWalkthrough, "focused", "Credits walkthrough");

    }

    public void verifySignOut(){
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.verifyVisibilityOfElement(oR.getSettingsObjects().objSignedInto, 15, "Signed Into header");
        userActions.verifyFocusedElement(oR.getSettingsObjects().objSignOut, "focused", "SignOut");
        //TODO rest of signout flows

    }

    public void signOut(){
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.adb_shell_command(22, "Right_key_pad");

        userActions.verifyVisibilityOfElement(oR.getSettingsObjects().objLinkSignOut, 12, "SignOut");

        userActions.adb_shell_command(66, "Enter");

    }


    public void exitStruum(){
        userActions.verifyVisibilityOfElement(oR.getSettingsObjects().objYesImSure, 30, "Yes I'm sure");
        userActions.verifyVisibilityOfElement(oR.getSettingsObjects().objNoKeepWatching, 5, "No, keep watching");

    }


}
