package org.firstlight.test.pages;

import org.firstlight.test.core.ReusableLibrary;
import org.firstlight.test.core.ScriptHelper;
import org.firstlight.test.objrepo.ObjectRepository;

public class Credits extends ReusableLibrary {
    private ObjectRepository oR;
    /**
     * Constructor to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it
     *
     * @param scriptHelper The {@link ScriptHelper} object
     * @param: driver The {@link org.openqa.selenium.WebDriver} object
     */
    public Credits(ScriptHelper scriptHelper) {
        super(scriptHelper);
        oR = ObjectRepository.getInstance();
    }


    public void verifyAddCreditsPage(){
        userActions.verifyVisibilityOfElement(oR.getCreditsObjects().objAddCredits, 30, "Add Credits");
        userActions.isElementDisplayed(oR.getCreditsObjects().obj20Credits, "20 Credits");
        userActions.isElementDisplayed(oR.getCreditsObjects().obj099Credits, "$0.99");
        userActions.isElementDisplayed(oR.getCreditsObjects().obj20CreditMsg, "//android.widget.TextView[@text='Your card will be charged $0.99 and 20 credits will immediately be added to your account.']");

        userActions.click(oR.getCreditsObjects().obj40Credits, "40 Credits");
        userActions.isElementDisplayed(oR.getCreditsObjects().obj40Credits, "40 Credits");
        userActions.isElementDisplayed(oR.getCreditsObjects().obj199Credits, "$1.99");
        userActions.isElementDisplayed(oR.getCreditsObjects().obj40CreditMsg, "//android.widget.TextView[@text='Your card will be charged $1.99 and 40 credits will immediately be added to your account.']");

        userActions.click(oR.getCreditsObjects().obj60Credits, "60 Credits");
        userActions.isElementDisplayed(oR.getCreditsObjects().obj60Credits, "20 Credits");
        userActions.isElementDisplayed(oR.getCreditsObjects().obj299Credits, "$1.99");
        userActions.isElementDisplayed(oR.getCreditsObjects().obj60CreditMsg, "//android.widget.TextView[@text='Your card will be charged $2.99 and 60 credits will immediately be added to your account.']");



    }

    public void selectCredits(){
        String credits_amount = testData.getData("Credits Amount");

        if(credits_amount.equalsIgnoreCase("20")){
            userActions.click(oR.getCreditsObjects().obj20Credits, "20 Credits");
        }else  if(credits_amount.equalsIgnoreCase("40")){
            userActions.click(oR.getCreditsObjects().obj40Credits, "40 Credits");
        }else  if(credits_amount.equalsIgnoreCase("60")){
            userActions.click(oR.getCreditsObjects().obj60Credits, "60 Credits");
        }
    //click the confirm button
        userActions.waitForSecs(2);
        userActions.adb_shell_command(20, "Down_key_pad");

        userActions.isElementDisplayed(oR.getCreditsObjects().objCreditsConfirm, "Confirm");
        userActions.adb_shell_command(66, "key_enter");
    }
}
