package org.firstlight.test.pages;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.firstlight.test.core.ReusableLibrary;
import org.firstlight.test.core.ScriptHelper;
import org.firstlight.test.objrepo.ObjectRepository;
import org.firstlight.test.reports.Status;
import org.openqa.selenium.By;

import java.util.List;

public class Movies extends ReusableLibrary {
    private ObjectRepository oR = ObjectRepository.getInstance();
    /**
     * Constructor to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it
     *
     * @param scriptHelper The {@link ScriptHelper} object
     * @param: driver The {@link org.openqa.selenium.WebDriver} object
     */
    public Movies(ScriptHelper scriptHelper) {
        super(scriptHelper);
    }


    public void verifyMovieDetails(){
        String filmName = testData.getData("Film Name");
        userActions.compareTextContains(oR.getMoviesObjects().objMoviesDetailsHeader, filmName, "Film name");
        userActions.click(oR.getMoviesObjects().objAddCredits, "Redeem credits");
    }
    public void playMovie(){
        boolean status = userActions.isElementPresent(oR.getMoviesObjects().objResumeMovie,20);
        if(status){
            userActions.click(oR.getMoviesObjects().objResumeMovie,"Click the Resume Button");
            userActions.waitForSecs(5);
            //userActions.adb_shell_command(25,"Click the DPAD Down");
            userActions.adb_shell_command(66,"Click the DPAD Enter button");

        }else
        {
            userActions.click(oR.getMoviesObjects().objPlayButton,"Click Play Button");

        }
    }
    public void defaultPlayerControls() {
        userActions.waitForSecs(5);
        userActions.adb_shell_command(20,"Click the d-pad Down");
        userActions.waitForSecs(5);
        userActions.adb_shell_command(85, "pause the movie");
        userActions.waitForSecs(5);
        userActions.adb_shell_command(85, "play the movie");
        userActions.waitForSecs(5);
        //userActions.adb_shell_command(91, "mute the movie");
        //userActions.waitForSecs(5);
        userActions.adb_shell_command(24, "Up the volume");
        userActions.waitForSecs(5);
        userActions.adb_shell_command(25, "Down the volume");
        userActions.waitForSecs(5);
        //TODO: Validation of sub title

        userActions.adb_shell_command(19,"Click the DPAD Up");
        userActions.adb_shell_command(19,"Click the DPAD Up");
        userActions.adb_shell_command(23,"Click the DPAD Center");
        userActions.verifyVisibilityOfElement(oR.getMoviesObjects().objAudio,20,"Audio button is Displayed");
        userActions.verifyVisibilityOfElement(oR.getMoviesObjects().objSubtitle,20,"Subtitle Button");
        userActions.click(oR.getMoviesObjects().objSubtitle,"Click Subtitle Option");
    }

    public void addMoviePlayerControl() throws InterruptedException {
        Thread.sleep(8000);
        userActions.adb_shell_command(85, "pause the movie");
        //Thread.sleep(5000);
        //String getStartTimetxt = userActions.getText(By.xpath("//android.view.ViewGroup[@content-desc=\"PlayerControls\"]/android.view.ViewGroup[3]/android.view.ViewGroup[1]/android.widget.TextView[1]"), "Start Time");
        //String getEndTimetxt = userActions.getText(By.xpath("//android.view.ViewGroup[@content-desc=\"PlayerControls\"]/android.view.ViewGroup[3]/android.view.ViewGroup[1]/android.widget.TextView[2]"), "End Time");
        String getStartTimetxt = userActions.getText(By.xpath("//android.view.ViewGroup[@content-desc=\"PlayerControls\"]/android.view.ViewGroup[3]/android.view.ViewGroup[2]/android.widget.TextView[1]"), "Start Time");
        String getEndTimetxt = userActions.getText(By.xpath("//android.view.ViewGroup[@content-desc=\"PlayerControls\"]/android.view.ViewGroup[3]/android.view.ViewGroup[2]/android.widget.TextView[2]"), "End Time");

        userActions.adb_shell_command(85, "play the movie");
        Thread.sleep(5000);
        userActions.adb_shell_command(85, "pause the movie");
        userActions.adb_shell_command(85, "pause the movie");
        String getnewStartTimetxt = userActions.getText(By.xpath("//android.view.ViewGroup[@content-desc=\"PlayerControls\"]/android.view.ViewGroup[3]/android.view.ViewGroup[2]/android.widget.TextView[1]"), "Start Time");
        String getnewEndTimetxt = userActions.getText(By.xpath("//android.view.ViewGroup[@content-desc=\"PlayerControls\"]/android.view.ViewGroup[3]/android.view.ViewGroup[2]/android.widget.TextView[2]"), "End Time");
        if (getStartTimetxt.equalsIgnoreCase(getnewStartTimetxt)) {
            report.updateTestLog("Movie is not Playing", "", Status.FAIL);
        } else {
            report.updateTestLog("Movie is Playing", "", Status.PASS);
        }

        //Clicking the Subtitle

        userActions.verifyVisibilityOfElement(oR.getMoviesObjects().objSubtitle,30,"Subtitle is Displayed");
        userActions.click(oR.getMoviesObjects().objSubtitle,"Click Subtitle");
        userActions.verifyVisibilityOfElement(oR.getMoviesObjects().objSubtitleEng,30,"English subtitle is displayed");
        userActions.verifyVisibilityOfElement(oR.getMoviesObjects().objSubtitleoff,30,"Off Subtitle is displayed");

        //Verify View Options is displayed
        userActions.click(oR.getMoviesObjects().objSubtitleEng,"English subtitle is clicked");
        userActions.verifyVisibilityOfElement(oR.getMoviesObjects().objViewOptions,30,"View Options is displayed");

        //Clicking on View Options
        userActions.click(oR.getMoviesObjects().objViewOptions,"Click on View Options");
        userActions.verifyVisibilityOfElement(oR.getMoviesObjects().objSize,30, "Font Size");
        userActions.navigateBack();
        userActions.navigateBack();
        // clickfastforward();

    }

    public void verifyRecomSection(){
        userActions.verifyVisibilityOfElement(oR.getMoviesObjects().objRecommendedMovies, 15, "Recommendation Movies");
       // userActions.adb_shell_command(20, "dpad_down");

        List<MobileElement> lstMovies = ((AndroidDriver)driver).findElements(oR.getMoviesObjects().objRecomMoviesList);

        if(lstMovies.size()>0){
            for(int i=0; i<lstMovies.size()/1.5; i++){
                userActions.adb_shell_command(22, "dpad_right");
                report.updateTestLog("Move the dpad_right button for navigation", "", Status.PASS);
            }
        }
    }
}
