package org.firstlight.test.objrepo;

import org.openqa.selenium.By;

public class BrowseObjects {

    public  By objBrowse = By.xpath("//android.widget.TextView[@text='Browse']");
    public  By objJustAdded = By.xpath("//android.widget.TextView[@text='Just Added']");
}
