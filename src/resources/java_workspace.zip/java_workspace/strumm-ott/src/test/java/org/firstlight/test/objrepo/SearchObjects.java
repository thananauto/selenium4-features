package org.firstlight.test.objrepo;

import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;

public class SearchObjects {


    public By objSearchResultList = By.xpath("//android.widget.ScrollView//android.view.ViewGroup[count(./android.widget.TextView) = 3]/android.widget.TextView[1]");


    public By objNotFindAnyResult = By.xpath("//android.widget.TextView[contains(@text,'Could not find any results')]");

    public By objMostPopular = By.xpath("//android.widget.HorizontalScrollView//android.widget.TextView[@text='Most Popular']");
    public By objJustAdded = By.xpath("//android.widget.HorizontalScrollView//android.widget.TextView[@text='Just Added']");
    public By objChannels = By.xpath("//android.widget.HorizontalScrollView//android.widget.TextView[@text='Channels']");
    public By objMovies = By.xpath("//android.widget.HorizontalScrollView//android.widget.TextView[@text='Movies']");
    public By objTvShows = By.xpath("//android.widget.HorizontalScrollView//android.widget.TextView[@text='TV Shows']");


    public By objNavResults = By.xpath("//android.widget.ScrollView//android.view.ViewGroup[count(./android.widget.TextView) = 3]");


}
