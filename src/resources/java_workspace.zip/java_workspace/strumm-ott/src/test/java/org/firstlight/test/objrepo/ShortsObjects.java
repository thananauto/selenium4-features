package org.firstlight.test.objrepo;

import org.openqa.selenium.By;

public class ShortsObjects {


    public By objShorts = By.xpath("//android.widget.TextView[@text='Shorts']");
    public By objIndieDiscoveries = By.xpath("//android.widget.TextView[@text='Indie Discoveries']");
    public By objRedeemContent = By.xpath("//android.widget.TextView[@text='Go to Browse to redeem content using your credits.']");


}
