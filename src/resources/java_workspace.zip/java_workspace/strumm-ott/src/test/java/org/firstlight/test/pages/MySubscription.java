package org.firstlight.test.pages;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;
import org.firstlight.test.core.ReusableLibrary;
import org.firstlight.test.core.ScriptHelper;
import org.firstlight.test.objrepo.ObjectRepository;
import org.firstlight.test.reports.Status;

import java.util.List;

public class MySubscription extends ReusableLibrary {

    private ObjectRepository oR;

    /**
     * Constructor to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it
     *
     * @param scriptHelper The {@link ScriptHelper} object
     * @param: driver The {@link org.openqa.selenium.WebDriver} object
     */
    public MySubscription(ScriptHelper scriptHelper) {
        super(scriptHelper);
        oR = ObjectRepository.getInstance();
    }

    public void continueWatching(){
        userActions.verifyVisibilityOfElement(oR.getMyCollectionObjects().objContinueWatching, 15, "Continue Watching");
        AndroidElement parentContinueWatching = (AndroidElement) driver.findElement(oR.getMyCollectionObjects().objContinueWatchParent);
        List<MobileElement> lstFilms =  parentContinueWatching.findElements(oR.getMyCollectionObjects().objHorCards);
        boolean blnValue = true;
        for(MobileElement eachCards: lstFilms){
            String eachText = eachCards.getText();
            if(!eachText.toLowerCase().contains("days left")){
                blnValue = false;
                break;
            }
        }

        if(blnValue)
            report.updateTestLog("Verify continue watching Horizontal movie list have text days left", "", Status.PASS);
        else
            report.updateTestLog("Verify continue watching Horizontal movie list cards not have text days left", "", Status.FAIL);
    }

    public void expiringSoon(){
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.waitForSecs(2);
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.verifyVisibilityOfElement(oR.getMyCollectionObjects().objExpiringSoon, 15, "Expiring Soon");
        AndroidElement parentExpiringSoon = (AndroidElement) driver.findElement(oR.getMyCollectionObjects().objExpiringSoonParent);
        List<MobileElement> lstFilms =  parentExpiringSoon.findElements(oR.getMyCollectionObjects().objHorCards);
        boolean blnValue = false;
        for(MobileElement eachCards: lstFilms){
            String eachText = eachCards.getText();
            if(!eachText.toLowerCase().contains("days left")){
                blnValue = true;
                break;
            }
        }

        if(blnValue)
            report.updateTestLog("Verify expiring soon Horizontal movie list have text days left", "", Status.PASS);
        else
            report.updateTestLog("Verify expiring soon Horizontal movie list cards not have text days left", "", Status.FAIL);
    }

    public void redeemedMovies(){
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.waitForSecs(2);
        userActions.adb_shell_command(20, "Down_key_pad");
        userActions.verifyVisibilityOfElement(oR.getMyCollectionObjects().objRedeemedMovies, 15, "Expiring Soon");
        AndroidElement parentRedeemedMovies = (AndroidElement) driver.findElement(oR.getMyCollectionObjects().objRedeemedMoviesParent);
        List<MobileElement> lstFilms =  parentRedeemedMovies.findElements(oR.getMyCollectionObjects().objHorCards);
        boolean blnValue = true;
        for(MobileElement eachCards: lstFilms){
            String eachText = eachCards.getText();
            if(!eachText.toLowerCase().contains("days left")){
                blnValue = false;
                break;
            }
        }

        if(blnValue)
            report.updateTestLog("Verify redeemed movies Horizontal movie list have text days left", "", Status.PASS);
        else
            report.updateTestLog("Verify redeemed movies Horizontal movie list cards not have text days left", "", Status.FAIL);
    }

    public void verifyResumeAndDaysLeft(){
        //verify the play button present, days left present,
        userActions.verifyVisibilityOfElement(oR.getMoviesObjects().objMoviesDetailsHeader, 30, "Movies Header");
        userActions.isElementDisplayed(oR.getMoviesObjects().objResumeMovie,"Resume button");
        userActions.isElementDisplayed(oR.getMoviesObjects().objDaysLeftInMoviesDetails, "Days left for that movie");
        userActions.isElementNotDisplayed(oR.getMoviesObjects().objWatchFor4Credits, "Watch for 4 credits");
        userActions.isElementNotDisplayed(oR.getMoviesObjects().objPreview, "Preview button");
        //TODO: add for trailer
    }


    public void previewAndWatchForCredits(){
        //verify watch for credits and preview
        userActions.verifyVisibilityOfElement(oR.getMoviesObjects().objMoviesDetailsHeader, 30, "Movies Header");
        userActions.isElementNotDisplayed(oR.getMoviesObjects().objResumeMovie,"Resume button");
        userActions.isElementNotDisplayed(oR.getMoviesObjects().objDaysLeftInMoviesDetails, "Days left for that movie");
        userActions.isElementDisplayed(oR.getMoviesObjects().objWatchFor4Credits, "Watch for 4 credits");
        userActions.isElementDisplayed(oR.getMoviesObjects().objPreview, "Preview button");
        //TODO: add for trailer
    }
    public void verifyTrailer(){
        //verify Trailer for a Movie
        userActions.verifyVisibilityOfElement(oR.getMoviesObjects().objMoviesDetailsHeader, 30, "Movies Header");
        userActions.isElementDisplayed(oR.getMoviesObjects().objResumeMovie,"Resume button");
        userActions.isElementDisplayed(oR.getMoviesObjects().objTrailer,"Trailer Button");
        userActions.isElementDisplayed(oR.getMoviesObjects().objDaysLeftInMoviesDetails,"Days left for that movie");
        userActions.isElementNotDisplayed(oR.getMoviesObjects().objPreview, "Preview button");
    }


}