package org.firstlight.test.objrepo;

import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;

public class MoviesObjects {

    public By objMovies = By.xpath("//android.widget.TextView[@text='Movies']");
    public By objStruumSelects = By.xpath("//android.widget.TextView[@text='Struum Selects']");
    public By objAddCredits = new MobileBy.ByAccessibilityId("redeemButton");
    public By objMoviesDetailsHeader = By.xpath("//android.widget.ScrollView[@content-desc='Details Screen']/android.view.ViewGroup/android.widget.TextView[1]");
    public By objMoviesDetailsSubTitle = By.xpath("//android.widget.ScrollView[@content-desc='Details Screen']/android.view.ViewGroup/android.widget.TextView[2]");
    public By objMoviesDescription = By.xpath("//android.widget.ScrollView[@content-desc='Details Screen']/android.view.ViewGroup/android.widget.TextView[3]");


    public By objSubtitle = By.xpath("//android.widget.TextView[@text='Subtitles']");

    public By objSubtitleEng = By.xpath("//android.widget.TextView[@text='English']");

    public By objSubtitleoff = By.xpath("//android.widget.TextView[@text='Off']");

    public By objViewOptions = By.xpath("//android.widget.TextView[@text='View Options']");

    public By objSize = By.xpath("//android.widget.TextView[@text='Size']");


    public By objRecommendedMovies = By.xpath("//android.widget.TextView[@text='Recommended Movies']");

    public By objRecomMoviesList = By.xpath("//android.widget.TextView[@text='Recommended Movies']/following-sibling::android.widget.HorizontalScrollView//android.widget.ImageView");

    public By objResumeMovie= By.xpath("//android.widget.TextView[@text='Resume']");
    public By objAudio = By.xpath("//android.widget.TextView[@text='Audio']");
    //public By objAudioEnglish =By.xpath("");
    public By objPlayButton =By.xpath("//android.widget.ScrollView[@content-desc='Details Screen']/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup");
    public By objPlayInMovieDetails = By.xpath("//android.widget.ScrollView[@content-desc='Details Screen']/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup");
    public By objDaysLeftInMoviesDetails = By.xpath("//android.widget.TextView[contains(@text,'days left')]");
    public By objWatchFor4Credits = By.xpath("//android.widget.TextView[contains(@text,'Watch for 4 credits')]");
    public By objPreview = By.xpath("//android.widget.TextView[@text='Preview']");
    public By objTrailer = By.xpath("//android.widget.TextView[@text='Trailer']");

}
