package org.firstlight.test.parameters;

import java.util.HashMap;
import java.util.Map;

/**
 *
 */
public class CommonData {
	
	private Map<String, String> commonData = new HashMap<>();

	/**
	 * This method take two parameters
	 * @param key keys as String value
	 * @param value value as String
	 */
	public  void setRunTimeData(String key, String value) {
		commonData.put(key, value);
	}

	/**
	 *  This method is used to retrieve the key from scenariosContext
	 * @param key  as String value
	 * @return String which matches the key
	 */
	public  String getRunTimeData(String key){
		return String.valueOf(commonData.get(key));
	}

	/**This method performs a check on the complete Map that if it contains the key or not.
	 * @param key as String value
	 * @return boolean value if it matches the key
	 */
	public  Boolean isContains(String key){
		return commonData.containsKey(key.toString());
	}


	
}
