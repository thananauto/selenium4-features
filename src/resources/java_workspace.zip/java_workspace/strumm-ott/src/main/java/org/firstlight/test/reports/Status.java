package org.firstlight.test.reports;

public enum Status
{
  FAIL, 

  WARNING, 

  PASS, 

  SCREENSHOT, 

  DONE, 

  DEBUG;
}