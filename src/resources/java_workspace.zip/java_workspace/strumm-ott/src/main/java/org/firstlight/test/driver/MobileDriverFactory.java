package org.firstlight.test.driver;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.firstlight.test.parameters.TestParameters;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class MobileDriverFactory {


    /**
     *
     * @param testparameters
     * @param properties
     * @return
     * @throws MalformedURLException
     */
    public static MobileDriver getDriver(TestParameters testparameters, Properties properties) throws MalformedURLException {
        MobileDriver mobileDriver = null;

        Platform platformName  = testparameters.getPlatform();
        File file = new File(properties.getProperty("FileName"));
        DesiredCapabilities capabilities = new DesiredCapabilities();

        if(platformName.name().equalsIgnoreCase("Android")){

            capabilities.setCapability("deviceName", properties.getProperty("OttDeviceName"));
            capabilities.setCapability("platformName", "Android");
            capabilities.setCapability("app", file.getAbsolutePath());
            capabilities.setCapability("appPackage", properties.getProperty("AppPackage"));
            capabilities.setCapability("appActivity", properties.getProperty("AppActivity"));
            //TODO: Have to update the logic based on the test scenarios condition
            capabilities.setCapability("fullReset", false);
            capabilities.setCapability("noReset", true);
            capabilities.setCapability("automationName", "UiAutomator2");
            capabilities.setCapability("newCommandTimeout", 60);


            mobileDriver = new AndroidDriver(new URL(properties.getProperty("AppiumServerUrl")), capabilities);

        }else if(platformName.name().equalsIgnoreCase("Mac")){
            capabilities.setCapability("deviceName", properties.getProperty("OttDeviceName"));
            capabilities.setCapability("platformName", "IOS");
            capabilities.setCapability("app", file.getAbsolutePath());
            capabilities.setCapability("appPackage", properties.getProperty("AppPackage"));
            capabilities.setCapability("appActivity", properties.getProperty("AppActivity"));
            //TODO: Have to update the logic based on the test scenarios condition
            capabilities.setCapability("fullReset", false);
            capabilities.setCapability("noReset", true);
            capabilities.setCapability("newCommandTimeout", 60);

            mobileDriver = new IOSDriver(new URL(properties.getProperty("AppiumServerUrl")), capabilities);

        }
        //TODO: Add other drivers like Samsung Tizen, LG WebOS


        return mobileDriver;
    }
}
