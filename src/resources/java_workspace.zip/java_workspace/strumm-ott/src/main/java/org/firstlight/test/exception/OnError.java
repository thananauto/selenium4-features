package org.firstlight.test.exception;

public enum OnError
{
  NextIteration, 

  NextTestCase, 

  Stop;
}