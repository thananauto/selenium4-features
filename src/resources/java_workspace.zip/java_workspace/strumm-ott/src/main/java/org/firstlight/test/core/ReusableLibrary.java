package org.firstlight.test.core;



import io.appium.java_client.MobileDriver;
import org.firstlight.test.parameters.FrameworkParameters;
import org.firstlight.test.parameters.TestData;
import org.firstlight.test.reports.Report;
import org.firstlight.test.utilities.Settings;
import org.firstlight.test.utilities.UserActions;
import org.openqa.selenium.WebDriver;

import java.util.Properties;


/**
 * Abstract base class for reusable libraries created by the user
 * @author thananjayan.rajasekaran
 * @version 1.0
 * @since Dec 2021
 */
public abstract class ReusableLibrary
{
	/**
	 * The {@link TestData} object (passed from the test script)
	 */
	protected TestData testData;
	/**
	 * The {@link Report} object (passed from the test script)
	 */
	protected Report report;
	/**
	 * The {@link MobileDriver} object
	 */
	protected MobileDriver driver;
	/**
	 * The {@link ScriptHelper} object (required for calling one reusable library from another)
	 */
	protected ScriptHelper scriptHelper;
	
	/**
	 * The {@link Properties} object with settings loaded from the framework properties file
	 */
	protected Properties properties = Settings.getInstance();
	/**
	 * The {@link FrameworkParameters} object
	 */
	protected FrameworkParameters frameworkParameters = FrameworkParameters.getInstance();

	/**
	 * The {@link UserActions} object
	 */
	public UserActions userActions;


	
	/**
	 * Constructor to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it
	 * @param scriptHelper The {@link ScriptHelper} object
	 * @param: driver The {@link WebDriver} object
	 */
	public ReusableLibrary(ScriptHelper scriptHelper)
	{
		this.scriptHelper = scriptHelper;
		this.testData = scriptHelper.getTestData();
		this.report = scriptHelper.getReport();
		this.driver = scriptHelper.getDriver();
		this.userActions = new UserActions(driver, report, testData);
	}
}