package org.firstlight.test.utilities;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.appmanagement.ApplicationState;
import org.apache.hc.client5.http.impl.cookie.RFC6265LaxSpec;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.firstlight.test.parameters.TestData;
import org.firstlight.test.reports.Report;
import org.firstlight.test.reports.Status;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

/**
 * This class contains, commonly used actions on web page
 */
public class UserActions {

	private MobileDriver driver;
	private Report report;
	private TestData testData;
	private Properties properties = Settings.getInstance();

	public UserActions(MobileDriver driver, Report report, TestData testData) {
		this.driver = driver;
		this.report = report;
		this.testData = testData;
	}

	/**
	 * Method to launch the app
	 */
	public void openApp() {
		try {
			//check app is already running
			ApplicationState state = ((AndroidDriver) driver).queryAppState(properties.getProperty("AppPackage"));
			if (!state.toString().equalsIgnoreCase("RUNNING_IN_FOREGROUND"))
				((AndroidDriver) driver).launchApp();

			report.updateTestLog("Launch the app", "App is successfully launched", Status.PASS);
		} catch (Exception e) {
			report.updateTestLog("Launch the app failed " + e.getMessage(), "App is not successfully launched", Status.FAIL);
		}
	}

	public boolean verifyVisibilityOfElement(By by, int seconds, String description) {
		WebDriverWait wait = new WebDriverWait(driver, seconds);
		AndroidElement loaded = (AndroidElement) wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		if (loaded.isDisplayed()) {
			report.updateTestLog("Element: " + description + " is displayed", "Element: " + description + " is  displayed", Status.PASS);
			return true;
		} else {
			report.updateTestLog("Element: " + description + " is displayed", "Element: " + description + " is not displayed", Status.FAIL);
			return false;
		}

	}
	public boolean isElementPresent(By by, int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, seconds);
		AndroidElement loaded = (AndroidElement) wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		if (loaded.isDisplayed()) {
			return true;
		} else {
			return false;
		}

	}



	public void compareTextContains(By by, String compareText, String description) {
		String runningText = ((AndroidDriver) driver).findElement(by).getText();

		if (runningText.toLowerCase().contains(compareText.toLowerCase())) {
			report.updateTestLog(description + ": " + runningText + " is present in application", "", Status.PASS);
		} else {
			report.updateTestLog(description + ": " + runningText + " is present in application", "", Status.FAIL);

		}


	}

	public void click(By by, String elementName) {
		if (isElementDisplayed(by, elementName)) {
			driver.findElement(by).click();
			report.updateTestLog("The element " + elementName + " is successfully clicked", "", Status.PASS);
		} else {
			report.updateTestLog("The element " + elementName + " is not successfully clicked", "", Status.FAIL);

		}
	}
	public void adb_uninstall_app() throws Exception{
		Runtime.getRuntime().exec("adb uninstall " + Settings.getInstance().getProperty("AppPackage"));
	}

	public void adb_shell_command(int key_code, String description) {
		try {
			Thread.sleep(1000);
		/**	Map<String, Object> leftSideMenu = new HashMap<>();
			leftSideMenu.put("command", "input keyevent " + key_code);
			leftSideMenu.put("includeStderr", true);
			((AndroidDriver) driver).executeScript("mobile: shell", leftSideMenu);
			Thread.sleep(3000);
		 **/
			if(key_code == 21)
				((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.DPAD_LEFT));
			else if(key_code==85)
				((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.MEDIA_PLAY_PAUSE));
			else if(key_code==91)
				((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.MUTE));
			else if(key_code==24)
				((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.VOLUME_UP));
			else if(key_code==25)
				((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.VOLUME_DOWN));
			else if(key_code==90)
				((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.MEDIA_FAST_FORWARD));
			else if(key_code==20)
				((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.DPAD_DOWN));
			else if(key_code==66)
				((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.ENTER));
			else if(key_code == 19)
				((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.DPAD_UP));
			else if(key_code == 22)
				((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.DPAD_RIGHT));


			report.updateTestLog("Execute the adb shell command for " + description, "", Status.PASS);
		} catch (Exception e) {

		}
	}




	public void navigateBack() {
		try {
			((AndroidDriver) driver).navigate().back();
			report.updateTestLog("Navigate back", "", Status.PASS);
		} catch (Exception e) {
			report.updateTestLog("Navigate back is not successfull: " + e.getMessage(), "", Status.FAIL);
		}
	}

	public void typeByButtons(String filmName) {
		char[] charFilm = filmName.toLowerCase().toCharArray();
		try {
			for (int i = 0; i < charFilm.length; i++) {

				if(String.valueOf(charFilm[i]).equals(" "))
					((AndroidDriver) driver).findElementByXPath("//android.view.ViewGroup/android.widget.TextView[@text='a']/../preceding-sibling::android.view.ViewGroup[2]/android.widget.TextView").click();
				else
					((AndroidDriver) driver).findElementByXPath("//android.widget.TextView[@text='" + charFilm[i] + "']").click();

				Thread.sleep(2000);
				report.updateTestLog("Enter the character: " + charFilm[i], "character successfully entered", Status.PASS);
			}
		} catch (Exception e) {
			report.updateTestLog("Film name not successfully entered: " + filmName + " " + e.getMessage(), "character successfully entered", Status.FAIL);

		}

	}
	public void scrollToBottomOld(String downText) {
		try {
			((AndroidDriver) driver).findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"" + downText + "\"))");
			report.updateTestLog("Scroll to bottom of text: " + downText, "", Status.PASS);
		} catch (Exception e) {
			report.updateTestLog("Scroll to bottom and find the text: " + downText, "", Status.FAIL);
		}
	}

	public boolean isElementPresent(By by) {
		((AndroidDriver) driver).manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		boolean result;
		try {
			AndroidElement element = (AndroidElement) driver.findElement(by);

			if (element.isDisplayed())
				result = true;
			else
				result = false;
		} catch (Exception e) {
			result = false;
		}
		((AndroidDriver) driver).manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		return result;
	}

	public String getText(By by, String elementName) {
		try {
			AndroidElement element = (AndroidElement) driver.findElement(by);
			return element.getText();
			//report.updateTestLog("The element " + elementName + " Text is retrived", "", Status.PASS);
		} catch (Exception e) {
			report.updateTestLog("The element " + elementName + " " + e.getMessage(), "", Status.FAIL);

		}

		return elementName;
	}

    public void enterText(By by, String text) {
		try {
			((AndroidDriver) driver).findElement(by).sendKeys(text);

			report.updateTestLog("Enter the text: "+text, "", Status.PASS);
		} catch (Exception e) {
			report.updateTestLog("Enter the text: "+text, "", Status.PASS);

		}

    }

	public void waitForSecs(int seconds) {

		try{
			Thread.sleep(1000 * seconds);
		}catch (Exception e){

		}
	}

	public void javaScriptClick(By by, String browse) {

		try{
			AndroidElement ele = (AndroidElement) driver.findElement(by);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();",ele);
			report.updateTestLog("Click on "+browse, "", Status.PASS);
		}catch (Exception e){
			report.updateTestLog("Click on "+browse, "", Status.FAIL);
		}
	}

	public void verifyFocusedElement(By by, String focused, String sectionName) {
		String focussedValue = ((AndroidDriver) driver).findElement(by).getAttribute(focused);

		if (focussedValue.toLowerCase().contains("true")) {
			report.updateTestLog(sectionName + ": is focussed in application", "", Status.PASS);
		} else {
			report.updateTestLog(sectionName + ": is not focussed  in application", "", Status.FAIL);

		}

	}

	public void navigateAllMenus( String linkName){

		//let's first enable the left navigation menu
		By by = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text='"+linkName+"']/..");
		//adb_shell_command(21, "left_key_pad");


		//let's move the focus to top most element
		for(int i=0; i<=6; i++){
			((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.DPAD_UP));
		}
		boolean clickElement = false;
		while(true){

			String focussedValue = ((AndroidDriver) driver).findElement(by).getAttribute("focused");
			if(focussedValue.equals("true")){
				clickElement = true;
				break;
			}
			((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.DPAD_DOWN));

		}

		//once find the correct focus element send the enter keys
		if(clickElement){
			((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.ENTER));
			report.updateTestLog("Click the link: "+linkName, "", Status.PASS);
		}else {
			report.updateTestLog("Failed to click the: "+linkName, "", Status.FAIL);

		}

	}


	public void scrollToUp(String upText) {

		waitForSecs(3);
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);

		WebDriverWait wait = new WebDriverWait(driver, 15);
		boolean scrollable = wait.until(new ExpectedCondition<Boolean>() {
			@Override
			public @Nullable Boolean apply(@Nullable WebDriver webDriver) {

				try{
					((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.DPAD_UP));
					boolean val = ((AndroidDriver)driver).findElement(By.xpath("//android.widget.TextView[@text='"+upText+"']")).isDisplayed();
					//this below line to make it focus in view for user
					((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.DPAD_UP));
					return val;
				}catch (Exception e){
					return false;
				}
			}
		});

		//back to normal implicit wait timeout duration
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		if(scrollable)
			report.updateTestLog("Scroll to top of text: " + upText, "", Status.PASS);
		else
			report.updateTestLog("Scroll to top and find the text: " + upText, "", Status.FAIL);

	}

	public void scrollToBottom(String downText) {
		waitForSecs(3);
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);

		WebDriverWait wait = new WebDriverWait(driver, 50);
		boolean scrollable = wait.until(new ExpectedCondition<Boolean>() {
			@Override
			public @Nullable Boolean apply(@Nullable WebDriver webDriver) {

				try{
					((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.DPAD_DOWN));
					boolean val = ((AndroidDriver)driver).findElement(By.xpath("//android.widget.TextView[@text='"+downText+"']")).isDisplayed();
					//this below line to make it focus in view for user
					((AndroidDriver)driver).pressKey(new KeyEvent().withKey(AndroidKey.DPAD_DOWN));
					return val;
				}catch (Exception e){
					return false;
				}
			}
		});

		//back to normal implicit wait timeout duration
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		if(scrollable)
			report.updateTestLog("Scroll to bottom of text: " + downText+" recommendation", "", Status.PASS);
		else
			report.updateTestLog("Scroll to bottom and find the text: " + downText+" in recommendation section", "", Status.FAIL);

	}
	public boolean isElementDisplayed(By by, String elementName) {
		try {
			AndroidElement element = (AndroidElement) driver.findElement(by);

			if (element.isDisplayed()) {
				report.updateTestLog("The element " + elementName + " is displayed", "", Status.PASS);
				return true;
			}else {
				report.updateTestLog("The element " + elementName + " is not displayed", "", Status.FAIL);
				return false;
			}
		} catch (Exception e) {
			report.updateTestLog("The element " + elementName + " is not displayed", "", Status.FAIL);
			return false;
		}
	}

	public boolean isElementNotDisplayed(By by, String elementName) {
		try {
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
			AndroidElement element = (AndroidElement) driver.findElement(by);
			report.updateTestLog("The element " + elementName + " is  displayed", "", Status.FAIL);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			return false;
		} catch (Exception e) {
			report.updateTestLog("The element " + elementName + " is not displayed", "", Status.PASS);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			return true;
		}
	}


}
//report.updateTestLog("Film name not successfully entered: "+filmName+" "+e.getMessage(), "character successfully entered", Status.FAIL);