package org.firstlight.test.parameters;

public enum IterationOptions
{
  RunAllIterations, 

  RunOneIterationOnly, 

  RunRangeOfIterations;
}