package org.firstlight.test.core;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import io.appium.java_client.MobileDriver;
import org.firstlight.test.driver.MobileDriverFactory;
import org.firstlight.test.exception.OnError;
import org.firstlight.test.exception.UnExpectedException;
import org.firstlight.test.parameters.*;
import org.firstlight.test.reports.Report;
import org.firstlight.test.reports.Status;
import org.firstlight.test.utilities.Settings;
import org.firstlight.test.utilities.TimeStamp;
import org.firstlight.test.utilities.Util;
import org.junit.Assert;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.*;
import java.util.concurrent.TimeUnit;
public class ControlManager {
	private ArrayList<String> businessFlowData;
	public  int currentIteration, currentSubIteration;
	private Date startTime, endTime;
	private String timeStamp;
	private TestData testData;
	private Report report;
	private MobileDriver driver;
	private ScriptHelper scriptHelper;
	private final Properties properties;
	private FrameworkParameters frameworkParameters = FrameworkParameters
			.getInstance();
	private CommonData commonData = null;
	private ExtentReports extent;
	private ExtentTest extentTest, node;

	/**
	 * The {@link TestParameters} object
	 */
	public TestParameters testParameters = new TestParameters();
	/**
	 * Constructor to initialize the ControlManager
	 */
	public ControlManager() {
		setRelativePath();
		properties = Settings.getInstance();
		setDefaultTestParameters();
	}
	private void setRelativePath() {
		String relativePath = new File(System.getProperty("user.dir"))
				.getAbsolutePath();
		frameworkParameters.setRelativePath(relativePath);
	}
	private void setDefaultTestParameters() {
		testParameters.setCurrentScenario(this.getClass().getSimpleName());
		testParameters.setIterationMode(IterationOptions.RunAllIterations);
		//testParameters.setBrowser(properties.getProperty("DefaultBrowser")
		//  .toLowerCase());
		//testParameters.setBrowserVersion(properties
		//  .getProperty("DefaultBrowserVersion"));
		//testParameters.setPlatform(properties
		//  .getProperty("DefaultPlatform"));
	}
	/**
	 * Function to execute the given test case
	 */
	public void driveTestExecution() throws Exception{
		launchMobileDriver();
		loadBusinessFlow();
		loadTestIteration();
		loadTestReport();
		beforeHook();
		executeTestFlow();
		afterHook();
		wrapUp();
	}
	private void launchMobileDriver() throws Exception {
		startTime = Util.getCurrentTime();
		if(Objects.nonNull(properties.getProperty("AppiumServerUrl"))){
			driver = MobileDriverFactory.getDriver(testParameters, properties);
		}else {
			//driver = DriverFactory.getDriver(testParameters);
		}
	}
	private void loadBusinessFlow() {
		String datatablePath = getClass().getClassLoader().getResource("businessflows").getPath();
		testData = new TestData(datatablePath,
				testParameters.getCurrentScenario());
		report = new Report();
		scriptHelper = new ScriptHelper(testData, report, driver);
		businessFlowData = getBusinessFlow();
		//if (!properties.getProperty("Experimental").equals("On"))
		frameworkParameters.setRunConfiguration(properties
				.getProperty("RunConfiguration"));

		timeStamp = TimeStamp.getInstance();
		commonData = new CommonData();
	}

	private synchronized void loadTestIteration() {
		switch (testParameters.getIterationMode()) {
			case RunAllIterations:
				String datatablePath =  getClass().getClassLoader().getResource("businessflows").getPath();
				XcelAccess testDataAccess = new XcelAccess(datatablePath,
						testParameters.getCurrentScenario());
				if(properties
						.getProperty("DataSheet").equals(""))
					testDataAccess.setDatasheetName("Test_Data");
				else
					testDataAccess.setDatasheetName(properties
							.getProperty("DataSheet"));
				int startRowNum = testDataAccess.getRowNum(
						testParameters.getCurrentTestcase(), 0);
				int nTestcaseRows = testDataAccess.getRowCount(
						testParameters.getCurrentTestcase(), 0, startRowNum);
				int nSubIterations = testDataAccess
						.getRowCount("1", 1, startRowNum); // Assumption: Every test
				// case will have at
				// least one iteration
				//int nIterations = nTestcaseRows / nSubIterations;
				testParameters.setEndIteration(1);
				currentIteration = 1;
				currentSubIteration=1;
				break;
			case RunOneIterationOnly:
				currentIteration = 1;
				break;
			case RunRangeOfIterations:
				if (testParameters.getStartIteration() > testParameters
						.getEndIteration()) {
					throw new UnExpectedException("Error",
							"StartIteration cannot be greater than EndIteration!");
				}
				currentIteration = testParameters.getStartIteration();
				break;
		}
	}
	private void loadTestReport() {
		String reportPath = frameworkParameters.getRelativePath()
				+ frameworkParameters.fileSeparator + "target"+frameworkParameters.fileSeparator+"results"
				+ frameworkParameters.fileSeparator + timeStamp;
		report.setReportPath(reportPath);
		report.setDriver(driver);
		report.setReportLogLevel(Integer.parseInt(properties
				.getProperty("LogLevel")));
		//set the extent report
		if(testParameters.getBrowser().equalsIgnoreCase("Mobile")) {
			extentTest = extent.createTest(testParameters.getDevicename()+"_"+testParameters.getCurrentTestDescription()).assignDevice(testParameters.getDevicename());
		}else{
			extentTest = extent.createTest(testParameters.getCurrentTestDescription()).assignDevice(testParameters.getDevicename());
		}
		//report.setExtentTest(extentTest);
		String strDevice=testParameters.getDevicename().replaceAll(" ", "");
		// TODO Change made here; verify it works
		report.setReportName(testParameters.getCurrentScenario() + "_"
				+ testParameters.getCurrentCleanTestcase()+"_"+strDevice);
		report.initialize();
		report.createTestLogHeader(
				testParameters.getIterationMode().toString(),
				testParameters.getStartIteration(),
				testParameters.getEndIteration());
	}
	/**
	 * Function to do required setup activities before starting the test
	 * execution
	 */
	protected void beforeHook() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		InetAddress addr;
		String hostName = "Host name not found";
		try {
			addr = InetAddress.getLocalHost();
			hostName = addr.getHostName();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}
	private void executeTestFlow() {
		while (currentIteration <= testParameters.getEndIteration()) {
			report.createIterationHeader(currentIteration);
			try {
				executeTestcase(businessFlowData);
			} catch (UnExpectedException fx) {
				exceptionHandler(fx, fx.errorName);
			} catch (InvocationTargetException ix) {
				exceptionHandler((Exception) ix.getCause(), "Error");
			} catch (Exception ex) {
				exceptionHandler(ex, "Error");
			}
			currentIteration++;
		}
	}
	private ArrayList<String> getBusinessFlow() {
		String businessFlowPath = getClass().getClassLoader().getResource("businessflows").getPath();
		XcelAccess businessFlowAccess = new XcelAccess(businessFlowPath,
				testParameters.getCurrentScenario());
		businessFlowAccess.setDatasheetName("Business_flows");
		int rowNum = businessFlowAccess.getRowNum(
				testParameters.getCurrentTestcase(), 0);
		if (rowNum == -1) {
			throw new UnExpectedException("The test case \""
					+ testParameters.getCurrentTestcase()
					+ "\" is not found in the Business Flow sheet!");
		}
		String dataValue;
		ArrayList<String> businessFlowData = new ArrayList<String>();
		int currentColumnNum = 1;
		while (true) {
			dataValue = businessFlowAccess.getValue(rowNum, currentColumnNum);
			if (dataValue.equals("")) {
				break;
			}
			businessFlowData.add(dataValue);
			currentColumnNum++;
		}
		if (businessFlowData.size() == 0) {
			throw new UnExpectedException(
					"No business flow found against the test case \""
							+ testParameters.getCurrentTestcase() + "\"");
		}
		return businessFlowData;
	}
	private void executeTestcase(ArrayList<String> businessFlowData)
			throws IllegalArgumentException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException,
			InstantiationException {
		HashMap<String, Integer> keywordDirectory = new HashMap<String, Integer>();
		for (int currentKeywordNum = 0; currentKeywordNum < businessFlowData
				.size(); currentKeywordNum++) {
			String[] currentFlowData = businessFlowData.get(currentKeywordNum)
					.split(",");
			String currentKeyword = currentFlowData[0];
			int nKeywordIterations;
			if (currentFlowData.length > 1) {
				nKeywordIterations = Integer.parseInt(currentFlowData[1]);
			} else {
				nKeywordIterations = 1;
			}
			for (int currentKeywordIteration = 0; currentKeywordIteration < nKeywordIterations; currentKeywordIteration++) {
				if (keywordDirectory.containsKey(currentKeyword)) {
					keywordDirectory.put(currentKeyword,
							keywordDirectory.get(currentKeyword) + 1);
				} else {
					keywordDirectory.put(currentKeyword, 1);
				}
				currentSubIteration = keywordDirectory.get(currentKeyword);
				testData.setCurrentRow(testParameters.getCurrentTestcase(),
						currentIteration, currentSubIteration);
				if (currentSubIteration > 1) {
					report.createSectionHeader(currentKeyword
							+ " (Sub-Iteration: " + currentSubIteration + ")");
				} else {
					report.createSectionHeader(currentKeyword);
				}
				testData.setCurrentRow(testParameters.getCurrentTestcase(),
						currentIteration, currentSubIteration);
				node = extentTest.createNode(currentKeyword);
				report.setExtentTest(node);
				//logic to iterate the steps for each component
				//stepDefinitions = getComponentFLow(currentKeyword);
				System.out.println("\n----------------------The Current component: "+currentKeyword+" -------");
				//for(int k=0; k<stepDefinitions.size(); k++) {
				invokeBusinessComponent(currentKeyword);
				//}
			}
		}
	}
	private void invokeBusinessComponent(String currentKeyword)
			throws IllegalArgumentException, IllegalAccessException,
			InvocationTargetException, ClassNotFoundException,
			InstantiationException {
		Boolean isMethodFound = false;
		final String CLASS_FILE_EXTENSION = ".class";
		File[] packageDirectories = { new File(
				frameworkParameters.getRelativePath()
						+ frameworkParameters.fileSeparator+ "target"+
						frameworkParameters.fileSeparator+"test-classes"+
						frameworkParameters.fileSeparator+"org"+frameworkParameters.fileSeparator+"firstlight"+frameworkParameters.fileSeparator
						+"test"+frameworkParameters.fileSeparator+"pages")};
		for (File packageDirectory : packageDirectories) {
			File[] packageFiles = packageDirectory.listFiles();
			String packageName = packageDirectory.getName();
			for (int i = 0; i < packageFiles.length; i++) {
				File packageFile = packageFiles[i];
				String fileName = packageFile.getName();
				// We only want the .class files
				if (fileName.endsWith(CLASS_FILE_EXTENSION)) {
					// Remove the .class extension to get the class name
					String className = fileName.substring(0, fileName.length()
							- CLASS_FILE_EXTENSION.length());
					Class<?> reusableComponents = Class.forName("org.firstlight.test."+packageName
							+ "." + className);
					Method executeComponent;
					try {
						// Convert the first letter of the method to lowercase
						// (in line with java naming conventions)
						currentKeyword = currentKeyword.substring(0, 1)
								.toLowerCase() + currentKeyword.substring(1);
						executeComponent = reusableComponents.getMethod(
								currentKeyword, (Class<?>[]) null);
					} catch (NoSuchMethodException ex) {
						// If the method is not found in this class, search the
						// next class
						continue;
					}
					isMethodFound = true;
					Constructor<?> constructor = reusableComponents
							.getDeclaredConstructors()[0];
					Object businessComponent = constructor.newInstance(scriptHelper);
					Field fieldCommonData = null;
					try {
						fieldCommonData = reusableComponents
								.getDeclaredField("commonData");
						fieldCommonData.setAccessible(true);
						fieldCommonData.set(businessComponent, commonData);
					} catch (Exception e) {
						//System.out.println("Failed to set common data");
					}
					System.out.println("In class: "+className);
					System.out.println("Executing current keyword "+currentKeyword);
					long startTime = System.currentTimeMillis();
					executeComponent.invoke(businessComponent, (Object[]) null);
					System.out
							.println("=== Done === Time taken : "
									+ (System.currentTimeMillis() - startTime)
									+ " ===");
					System.out
							.println("\n");
					break;
				}
			}
		}
		if (!isMethodFound) {
			throw new UnExpectedException("Keyword " + currentKeyword
					+ " not found within any class "
					+ "inside the component package");
		}
	}
	private void exceptionHandler(Exception ex, String exceptionName) {
		// Error reporting
		node.fail(ex);
		String exceptionDescription = ex.getMessage();
		if (exceptionDescription == null) {
			exceptionDescription = ex.toString();
		}
		if (ex.getCause() != null) {
			report.updateTestLog(exceptionName, exceptionDescription
					+ " <b>Caused by: </b>" + ex.getCause(), Status.FAIL);
		} else {
			report.updateTestLog(exceptionName, exceptionDescription,
					Status.FAIL);
		}
		ex.printStackTrace();
		// Error response
		OnError onError = OnError.valueOf(properties.getProperty("OnError"));
		switch (onError) {
			case NextIteration:
				report.updateTestLog(
						"User Info",
						"Test case iteration terminated by user! Proceeding to next iteration (if applicable)...",
						Status.DONE);
				currentIteration++;
				executeTestFlow();
				break;
			case NextTestCase:
				report.updateTestLog(
						"User Info",
						"Test case terminated by user! Proceeding to next test case (if applicable)...",
						Status.DONE);
				break;
			case Stop:
				frameworkParameters.setStopExecution(true);
				break;
		}
		// Wrap up execution
		afterHook();
		wrapUp();
	}

	/**
	 * Function to do required teardown activities at the end of the test
	 * execution
	 */
	protected void afterHook() {
		driver.quit();
	}
	private void wrapUp() {
		endTime = Util.getCurrentTime();
		closeTestReport();
		if(Objects.nonNull(extent))
			extent.flush();
		if (report.testStatus.equalsIgnoreCase("Failed")) {
			Assert.fail(report.failureDescription);
		}
	}
	private void closeTestReport() {
		String executionTime = Util.getTimeDifference(startTime, endTime);
		report.createTestLogFooter(executionTime);
	}



}