package org.firstlight.test.driver;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.firstlight.test.parameters.TestParameters;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

import java.util.HashMap;
import java.util.Map;


/**
 * Factory for creating the Driver object based on the required browser
 *
 * @author rthanan
 * @version 1.0
 * @since June 2019
 */
public class DriverFactory {

    /**
     * Function to return the appropriate {@link RemoteWebDriver} object based on the browser name passed
     *
     * @return The corresponding {@link RemoteWebDriver} object
     * @param: browser The name of the browser
     */
    public static WebDriver getDriver(TestParameters testparameters) {
        WebDriver webDriver = null;
        if (testparameters.getBrowser().equalsIgnoreCase("Firefox")) {
            //this webdriverManager take care of set up the **.exe file in system path
            WebDriverManager.firefoxdriver().setup();
            webDriver = new FirefoxDriver();
        } else if (testparameters.getBrowser().equalsIgnoreCase("InternetExplorer")) {
            WebDriverManager.iedriver().setup();
            webDriver = new InternetExplorerDriver();
        } else if (testparameters.getBrowser().equalsIgnoreCase("Chrome")) {
            WebDriverManager.chromedriver().setup();
            webDriver = new ChromeDriver();
        } else if (testparameters.getBrowser().equalsIgnoreCase("Safari")) {
            WebDriverManager.safaridriver().setup();
            webDriver = new SafariDriver();
        } else if (testparameters.getBrowser().equalsIgnoreCase("Mobile")) {
            // below code is for mobile emulation set up
            WebDriverManager.chromedriver().setup();
            Map<String, String> mobileEmulation = new HashMap<>();
            mobileEmulation.put("deviceName", testparameters.getDevicename());
            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation);
            webDriver = new ChromeDriver(chromeOptions);
        } else if (testparameters.getBrowser().equalsIgnoreCase("Android")){


        }

        //TODO: to implement event firing webdriver for an unexpected error handling
            webDriver.manage().deleteAllCookies();

        return webDriver;
    }
}