package org.example;

public class Main {

    public static void main(String[] args) {
        System.out.println("Running the src main class");
    }
}
