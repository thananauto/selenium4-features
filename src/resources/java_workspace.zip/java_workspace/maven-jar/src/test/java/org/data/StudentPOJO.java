package org.data;

import com.creditdatamw.zerocell.annotation.Column;
import com.creditdatamw.zerocell.annotation.RowNumber;
import lombok.Getter;


@Getter
public class StudentPOJO {

    @RowNumber
    private int rowNumber;

    @Column(index=0, name="Id")
    private int idCardNo;

    @Column(index=1, name="Name")
    private String fullName;

    @Column(index=2, name="Age")
    private double age;
}
