package org.example;

import com.github.javafaker.Faker;
import lombok.SneakyThrows;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;

public class TestMain {
    public static void main1(String[] args) {
        List<String> lst = new ArrayList<>();
        lst.add("asda");
        lst.add("asdas");
        lst.add("bf");
        String[] strs = lst.stream().toArray(String[]::new);
        //System.out.println(check("asda","asdas", "bf"));
        System.out.println(check(strs));

    }
    public static boolean check(String ...name){
        Arrays.stream(name).forEach(e -> System.out.println(e));
        return false;
    }

    @SneakyThrows
    public static void main(String[] args) {

        File opFile1 = null;
        if (args.length > 0) {
            System.out.println(args[0]);
            File opFile = new File(args[0]);


            InputStream ipOpStream = TestMain.class.getClassLoader().getResourceAsStream("Sample.xlsx");
            if (opFile.exists())
                opFile.delete();
            FileUtils.copyInputStreamToFile(ipOpStream, opFile);

             opFile1 = new File(args[1]);
            InputStream ipOpStream1 = TestMain.class.getClassLoader().getResourceAsStream("test.properties");

            if (opFile1.exists())
                opFile1.delete();
            opFile1.createNewFile();
            FileUtils.copyInputStreamToFile(ipOpStream1, opFile1);
            //FileUtils.copyFile(ipFile1, opFile1);
        }

        System.out.println("Running the src test class");
        Faker faker = new Faker();
        System.out.println("First name: " + faker.name().firstName());
        System.out.println("Last name: " + faker.name().lastName());

        Properties props = new Properties();
        props.load(TestMain.class.getClassLoader().getResourceAsStream("prop.properties"));
        System.out.println(props.getProperty("age"));
        System.out.println(props.getProperty("area"));

        Properties props1 = new Properties();
        props1.load(new FileInputStream(opFile1));
        System.out.println(props1.getProperty("city"));
        System.out.println(props1.getProperty("country"));
    }
}
