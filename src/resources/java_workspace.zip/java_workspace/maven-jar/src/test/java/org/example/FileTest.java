package org.example;

import com.creditdatamw.zerocell.Reader;
import lombok.SneakyThrows;
import org.apache.commons.io.FileUtils;
import org.data.Person;
import org.data.StudentPOJO;
import org.testng.annotations.Test;

import java.io.File;
import java.io.InputStream;
import java.util.*;

public class FileTest {

    public static boolean check(String ...name){
        Arrays.stream(name).forEach(e -> System.out.println(e));
        return false;
    }

    @SneakyThrows
    public static File inputStreamToFile(InputStream inputStream, String fileName)  {
        // Create a file object
        File file = new File(fileName);
        if(file.exists())
            file.delete();

        // Use Files.copy with Java 8 streams
      // try (InputStream is = inputStream) {
       //     Files.copy(inputStream, file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            FileUtils.copyInputStreamToFile(inputStream, file);
       // }

        return file;
    }
    //@SneakyThrows
    @Test
    public void readFile() {
       // InputStream ipOpStream = Objects.requireNonNull(FileTest.class.getClassLoader().getResourceAsStream("Sample.xlsx"));
     //  String filePath = inputStreamToFile(ipOpStream, "Copy_Sample.xlsx").getAbsolutePath();

        File file1 = new File(Objects.requireNonNull(getClass().getClassLoader().getResource("Destination.xlsx")).getFile());
        List<Person> lst = Reader.of(Person.class)
                .from(file1)
                .sheet("Sheet1")
                .list();

        File file = new File(Objects.requireNonNull(FileTest.class.getClassLoader().getResource("Sample.xlsx")).getFile());


        List<StudentPOJO> students = Reader.of(StudentPOJO.class)
                .from(file)
                .sheet("Info")
                .list();
        assert students.size() >3;

    }
}
