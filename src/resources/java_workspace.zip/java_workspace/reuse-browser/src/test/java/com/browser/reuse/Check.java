package com.browser.reuse;


import org.checkerframework.checker.units.qual.C;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.locators.RelativeLocator;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.net.URL;
import java.rmi.Remote;
import java.time.Duration;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Check {

    @Test
    public void testChrome(){

        Map<String, Object> prefs = new HashMap<>();
        prefs.put("download.default_directory", "/direction/path");


        Proxy proxy = new Proxy();
        proxy.setHttpProxy("localhost:3337");

        ChromeOptions options= new ChromeOptions();
        options.setProxy(proxy); // add proxy
        options.addExtensions(new File("")); // add extension
        options.addArguments("user-data-dir:<path>"); // add for profile path
        options.addArguments("start-maximized"); // launch the browser in maximised position
        options.setBinary("<path to chrome browsr>"); // choose any different location
        options.setExperimentalOption("excludeSwitches", Arrays.asList("disable-popup-blocking"));
        options.setExperimentalOption("prefs", prefs);
        WebDriver driver = new ChromeDriver(options);

    }

    @Test
    public void testService(){
        ChromeDriverService service =
                new ChromeDriverService.Builder().withLogOutput(System.out).build();

    }


    @Test
    public void mobileEmulation(){
        Map<String, String> mobileEmulation = new HashMap<>();
        mobileEmulation.put("deviceName", "Nexus 5");
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("mobileEmulation", mobileEmulation);
        WebDriver driver = new ChromeDriver(options);

        driver.get("https://google.com");
        //RemoteWebDriver d1= new RemoteWebDriver(new URL(""), )
        driver.quit();;
    }


    @Test
    public void sauceTest(){
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/");
        By textUserName = RelativeLocator.with(By.id("user-name")).above(By.id("password"));
        By textPassword= RelativeLocator.with(By.id("password")).below(By.id("user-name"));
        By login= RelativeLocator.with(By.id("login-button")).below(By.id("user-name"));
        driver.findElement(textUserName).sendKeys("standard_user");
        driver.findElement(textPassword).sendKeys("secret_sauce");
        driver.findElement(login).click();

        TakesScreenshot takesScreenshot = (TakesScreenshot)driver;
       File file =  takesScreenshot.getScreenshotAs(OutputType.FILE);
        new WebDriverWait(driver, Duration.ofSeconds(20)).until(new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver webDriver) {
                return driver.findElements(By.id("<elements props>")).size() <= 4;
            }
        });

        driver.quit();
    }
}
