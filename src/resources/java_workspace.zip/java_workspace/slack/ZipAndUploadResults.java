package org.firstlight.test.slack;

import org.zeroturnaround.zip.ZipUtil;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ZipAndUploadResults {

    public static void main(String[] args) {

        Path root = FileSystems.getDefault().getPath("").toAbsolutePath();
        Path filePath = Paths.get(root.toString(),"target", "results", "latest");

        System.out.println(filePath);
        System.out.println(filePath.getParent());


        SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");
        Date date = new Date();
        System.out.println(formatter.format(date));
        String zipFolderPathName = String.valueOf(filePath.getParent())+"\\results_"+formatter.format(date)+".zip";
        ZipUtil.pack(new File(String.valueOf(filePath)+"\\"), new File(zipFolderPathName));

        //upload in to google drive
        DriveSample.UPLOAD_FILE_PATH = zipFolderPathName;
        DriveSample.uploadZipFolder();

    }
}
