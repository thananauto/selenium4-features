package org.firstlight.test.slack;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.Properties;
import java.util.Set;

public class ReadReportProperties {


    private final  String fileName = "report.properties";
    private final Properties configProp = new Properties();

    private String filePath;

    private ReadReportProperties(){
        //Private constructor to restrict new instances
        try {
        URL url = this.getClass().getClassLoader().getResource(fileName);
        filePath = url.getPath();
        InputStream in = url.openStream();
            configProp.load(in);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    private static  ReadReportProperties INSTANCE;
    public static ReadReportProperties getInstance() {
        return INSTANCE != null ? INSTANCE : new ReadReportProperties();
    }

    public String getProperty(String key){
        return configProp.getProperty(key);
    }

    public Set<String> getAllPropertyNames(){
        return configProp.stringPropertyNames();
    }

    public boolean containsKey(String key){
        return configProp.containsKey(key);
    }

    public void setProperty(String key, String value){
        configProp.setProperty(key, value);
    }

    public void flush(){
        try {

            OutputStream out = new FileOutputStream(filePath);
            configProp.store(out, "Save the report properties file");
        }catch (Exception e){

    }
    }




}
