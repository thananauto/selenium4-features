package org.firstlight.test.slack;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SlackMessage {

    private static ReadReportProperties prop = ReadReportProperties.getInstance();

    public static void main(String[] args) throws IOException {

        CloseableHttpClient client = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(prop.getProperty("slackMsgChannel"));

       // String json = "{"id":1,"name":"John"}";

        InputStream is = getFileAsIOStream("slack_msg_template.json");
        //printFileContent(is);
        String json1 = readFileFromResources(is);
        String json = json1
                .replaceAll("\\$TOTAL_TEST_CASE", prop.getProperty("totalTestCases"))
                .replaceAll("\\$PASSED_COUNT", prop.getProperty("passedCount"))
                .replaceAll("\\$FAILED_COUNT", prop.getProperty("failedCount"))
                .replaceAll("\\$DATE", sdf())
                .replaceAll("\\$WEB_VIEW_LINK", prop.getProperty("webViewLink"))
                .replaceAll("\\$WEB_CONTENT_LINK", prop.getProperty("webContentLink"));
        is.close();
        StringEntity entity = new StringEntity(json);
        httpPost.setEntity(entity);
        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("Content-type", "application/x-www-form-urlencoded");

        CloseableHttpResponse response = client.execute(httpPost);
        client.close();
    }

    private static String readFileFromResources(InputStream inputStream) throws IOException {
        return  IOUtils.toString(inputStream, StandardCharsets.UTF_8);
    }

    private static InputStream getFileAsIOStream(final String fileName)
    {
        InputStream ioStream = SlackMessage.class
                .getClassLoader()
                .getResourceAsStream(fileName);

        if (ioStream == null) {
            throw new IllegalArgumentException(fileName + " is not found");
        }
        return ioStream;
    }

    private static void printFileContent(InputStream is) throws IOException
    {
        try (InputStreamReader isr = new InputStreamReader(is);
             BufferedReader br = new BufferedReader(isr);)
        {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
            is.close();
        }
    }
    private static String sdf(){
        SimpleDateFormat sdf = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z");
        Date date = new Date();
        return String.valueOf(sdf.format(date));
    }
}
