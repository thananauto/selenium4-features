package org.firstlight.test.mobilesetup;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeClass {


    @Test
    public void test(){
        WebDriverManager.chromedriver().setup();;
        WebDriver driver = new ChromeDriver();


        driver.get("https://www.aha.video/");
    }
}
