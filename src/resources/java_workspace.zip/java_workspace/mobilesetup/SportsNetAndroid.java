package org.firstlight.test.mobilesetup;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.github.javafaker.Faker;
import io.appium.java_client.*;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;
import org.testng.collections.Lists;

import java.io.File;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class SportsNetAndroid {

    public static final String USERNAME = "mobileqa_NhXWiy";
    public static final String ACCESS_KEY = "9EBpFo4kiDN5H9XypTFH";
    public static final String URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@hub-cloud.browserstack.com/wd/hub";
    public static AndroidDriver mobiledriver;


    //builds a new report using the html template
    ExtentSparkReporter htmlReporter;

    ExtentReports extent;
    //helps to generate the logs in test report.
    ExtentTest test, node;




    public void realDevice() throws Exception{

        File file = new File("src");
        File app = new File(file, "aaha-app.apk");
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("deviceName", "192.168.231.199:5555");
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("app", app.getAbsolutePath());
        capabilities.setCapability("appPackage", "com.rogers.sportsnet.sportsnet");
        capabilities.setCapability("appActivity", "com.rogers.sportsnet.tv.ui.AppActivity");

        mobiledriver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        // mobiledriver = (AndroidDriver)driver;
        //Current Activity .views.MainActivity
        //Current Package ahaflix.tv

    }


    @BeforeTest
    public void beforeTest( ) throws MalformedURLException {
        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability("device", "Samsung Galaxy Tab S7");
        capabilities.setCapability("os_version", "10.0");
        capabilities.setCapability("project", "Sports Net Project");
        capabilities.setCapability("build", "My First Build");
        capabilities.setCapability("name", "Bstack-[Java] Sample Test");
        capabilities.setCapability("app", "bs://08691ec02398b26d9a1e8b9d43ac29b334a067e5");
        mobiledriver = new AndroidDriver(new URL(URL), capabilities);
        //"app_url": "bs://2a124867460e7881d6aa95f1bb10b715fdd7b2d7"
        //Current Activity com.rogers.sportsnet.tv.ui.AppActivity
        //Current Package com.rogers.sportsnet.sportsnet
    }

    @AfterTest
    public void afterTest( ){
        mobiledriver.quit();
    }

    @Test
    public  void navigateAnimation() throws Exception{


        System.out.println(mobiledriver.getSessionId());
        // set timeout for driver actions (similar to step timeout)
        mobiledriver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
        By by;
        boolean booleanResult;

    // adb commands using adb:shell play and pause the movie
        Map<String, Object> args = new HashMap<>();
        args.put("command", "echo");
        args.put("args", Lists.newArrayList("input keyevent 85"));
        args.put("includeStderr", true);
        String output = (String) mobiledriver.executeScript("mobile: shell", args);
        System.out.println(output);



        //
        JavascriptExecutor js = (JavascriptExecutor) mobiledriver;
        HashMap<String, String> scrollObject = new HashMap<String, String>();
        scrollObject.put("direction", "down");
        AndroidElement element = (AndroidElement) mobiledriver.findElement(By.xpath("//android.widget.TextView[contains(@text, 'Videos')]"));
        scrollObject.put("element", ((RemoteWebElement) element).getId());
        js.executeScript("mobile: scroll", scrollObject);
        // 1. Reset App
        //    Clear application data and restart (Auto-generated)
        Thread.sleep(500);
        mobiledriver.resetApp();

        System.out.println("Current Activity " +mobiledriver.currentActivity());
        System.out.println("Current Package "+ mobiledriver.getCurrentPackage());
        // 2. Pause for '20000'ms
        Thread.sleep(500);
        mobiledriver.manage().timeouts().implicitlyWait(20000, TimeUnit.MILLISECONDS);

        // 3. Click 'Home'
        Thread.sleep(500);
        by = By.xpath("//android.widget.TextView[@text = 'Home']");
        mobiledriver.findElement(by).click();
        node = test.createNode("Click the Home from navigation bar", "Home link clicked");

        // 4. Does 'Live & Upcoming' contain 'Live & Upcoming'?
        Thread.sleep(500);
        by = By.id("com.rogers.sportsnet.sportsnet:id/txt_list_title");
        Assert.assertTrue(mobiledriver.findElement(by).getText().contains("Live & Upcoming"));
        node = test.createNode("Is Live & Upcoming present");


        // 5. Click 'Schedule'
        Thread.sleep(500);
        by = By.xpath("//android.widget.TextView[@text = 'Schedule']");
        mobiledriver.findElement(by).click();
        node = test.createNode("Click Schedule");

        // 6. Does 'Schedule1' contain 'Schedule'?
        Thread.sleep(500);
        by = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text = 'Schedule']");
        Assert.assertTrue(mobiledriver.findElement(by).getText().contains("Schedule"));
        node = test.createNode("Validate schedule section displays");

        // 7. Click 'Highlights'
        Thread.sleep(500);
        by = By.xpath("//android.widget.TextView[@text = 'Highlights']");
        mobiledriver.findElement(by).click();
        node = test.createNode("Click Highlights");

        // 8. Does 'Highlights1' contain 'Highlights'?
        Thread.sleep(500);
        by = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text = 'Highlights']");
        Assert.assertTrue(mobiledriver.findElement(by).getText().contains("Highlights"));
        node = test.createNode("Validate highlight section displays");

        // 9. Click 'Leagues'
        Thread.sleep(500);
        by = By.xpath("//android.widget.TextView[@text = 'Leagues']");
        mobiledriver.findElement(by).click();
        node = test.createNode("Click Leagues");

        // 10. Does 'Leagues1' contain 'Leagues'?
        Thread.sleep(500);
        by = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text = 'Leagues']");
        (new WebDriverWait(mobiledriver, 30)).until(ExpectedConditions.visibilityOf(mobiledriver.findElement(by)));
        Assert.assertTrue(mobiledriver.findElement(by).getText().contains("Leagues"));
        node = test.createNode("Validate leagues displays");

        // 11. Click 'Shows'
        Thread.sleep(500);
        by = By.xpath("//android.widget.TextView[@text = 'Shows']");
        mobiledriver.findElement(by).click();
        node = test.createNode("Click Shows");

        // 12. Does 'Shows1' contain 'Shows'?
        Thread.sleep(500);
        by = By.xpath("//android.view.ViewGroup/android.widget.TextView[@text = 'Shows']");
        Assert.assertTrue(mobiledriver.findElement(by).getText().contains("Shows"));
        node = test.createNode("Validate shows present");

        // 13. Click 'Home'
        Thread.sleep(500);
        by = By.xpath("//android.widget.TextView[@text = 'Home']");
        mobiledriver.findElement(by).click();
        node = test.createNode("Click Home");

        // 14. Does 'Live & Upcoming' contain 'Live & Upcoming'?
        Thread.sleep(500);
        by = By.id("com.rogers.sportsnet.sportsnet:id/txt_list_title");
        Assert.assertTrue(mobiledriver.findElement(by).getText().contains("Live & Upcoming"));
        node = test.createNode("validate LIve and upcoming displays");

        // 15. Make a Swipe gesture from ('873','1037') to ('847','138') (941, 842, 909, 147) (1014, 835, 1046
        Thread.sleep(500);
        (new TouchAction(mobiledriver)).press(PointOption.point(893,877))
                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(300)))
                .moveTo(PointOption.point(883,170)).release().perform();

        Thread.sleep(500);
        (new TouchAction(mobiledriver)).press(PointOption.point(928,685))
                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(300)))
                .moveTo(PointOption.point(944,240)).release().perform();
       // TouchActions actions = new TouchActions(mobiledriver);
       // actions.scroll(mobiledriver.findElement(), )

        // 16. Is 'Top Videos' present?
        Thread.sleep(1000);
        by = By.xpath("//android.widget.TextView[contains(@text, 'Videos')]");
        mobiledriver.findElement(by);

        // 17. Click 'com.rogers.sportsnet.sportsnet:id/img...'
        Thread.sleep(500);
        by = By.xpath("//android.view.ViewGroup[3]/androidx.recyclerview.widget.RecyclerView[1]/android.view.ViewGroup[1]//android.widget.ImageView");
        mobiledriver.findElement(by).click();

        // 18. Pause for '30000'ms
        Thread.sleep(500);
        mobiledriver.manage().timeouts().implicitlyWait(30000, TimeUnit.MILLISECONDS);

        // 19. Is 'com.rogers.sportsnet.sportsnet:id/loa...' not present or invisible?
        Thread.sleep(500);
        by = By.id("com.rogers.sportsnet.sportsnet:id/loading_indicator");
        (new WebDriverWait(mobiledriver, 15)).until(ExpectedConditions.invisibilityOf(mobiledriver.findElement(by)));

        node = test.createNode("Validate loading indicator present");

        // 20. Pause for '30000'ms
        Thread.sleep(500);
        mobiledriver.manage().timeouts().implicitlyWait(30000, TimeUnit.MILLISECONDS);

        // 21. Is 'com.rogers.sportsnet.sportsnet:id/loa...' not present or invisible?
        Thread.sleep(500);
        by = By.id("com.rogers.sportsnet.sportsnet:id/loading_indicator");
        (new WebDriverWait(mobiledriver, 15)).until(ExpectedConditions.invisibilityOf(mobiledriver.findElement(by)));
        node = test.createNode("Validate laoding indciator should not present");
        // 22. Pause for '30000'ms
        Thread.sleep(500);
        mobiledriver.manage().timeouts().implicitlyWait(30000, TimeUnit.MILLISECONDS);

        // 23. Is 'com.rogers.sportsnet.sportsnet:id/loa...' not present or invisible?
        Thread.sleep(500);
        by = By.id("com.rogers.sportsnet.sportsnet:id/loading_indicator");
        (new WebDriverWait(mobiledriver, 15)).until(ExpectedConditions.invisibilityOf(mobiledriver.findElement(by)));

        // 24. Pause for '30000'ms
        Thread.sleep(500);
        mobiledriver.manage().timeouts().implicitlyWait(30000, TimeUnit.MILLISECONDS);

        // 25. Is 'com.rogers.sportsnet.sportsnet:id/loa...' not present or invisible?
        Thread.sleep(500);
        by = By.id("com.rogers.sportsnet.sportsnet:id/loading_indicator");
        (new WebDriverWait(mobiledriver, 15)).until(ExpectedConditions.invisibilityOf(mobiledriver.findElement(by)));

        // 26. Close App
        Thread.sleep(500);
        mobiledriver.closeApp();
        node = test.createNode("Click the app");

    }




    @BeforeTest
    public void startReport() throws Exception {
        // initialize the HtmlReporter

        Path targetPath = Paths.get(getClass().getResource("/").toURI()).getParent();

        htmlReporter = new ExtentSparkReporter(targetPath.toString() +"\\results\\testReport.html");

        //initialize ExtentReports and attach the HtmlReporter
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        //To add system or environment info by using the setSystemInfo method.
        extent.setSystemInfo("OS", "Android");
        extent.setSystemInfo("Browser", "Null");

        //configuration items to change the look and feel
        //add content, manage tests etc
        //htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setDocumentTitle("Extent Report Demo");
        htmlReporter.config().setReportName("Test Report");
        //htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
    }


    @AfterTest
    public void tearDown() {
        //to write or update test information to reporter
        if (extent != null) {

            extent.flush();

        }
    }

    public  String capture(MobileDriver driver) throws Exception
    {
        TakesScreenshot ts = (TakesScreenshot)driver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        Faker faker = new Faker();
        Path targetPath = Paths.get(getClass().getResource("/").toURI()).getParent();
        String dest =  "errorscreenshots/screenshot_"+ faker.number().randomNumber()+".png";

        File directory = new File(new File(targetPath + "\\results\\" + dest).getParent());
        if(!directory.exists()){
            directory.mkdir();
        }
        //targetPath+"\\results\\
        File destination = new File(targetPath+"\\results\\"+dest);
        FileUtils.copyFile(source, destination);

        return dest;
    }

    @BeforeMethod
    public void nameBefore(Method method)
    {
        test = extent.createTest(method.getName());

    }

    @AfterMethod
    public void getResult(ITestResult result) throws Exception{
        if(result.getStatus() == ITestResult.FAILURE) {
            node.log(Status.FAIL, MarkupHelper.createLabel(result.getName()+" FAILED ", ExtentColor.RED));
            node.fail(result.getThrowable());
            node.addScreenCaptureFromPath(capture(mobiledriver));

        }
        else if(result.getStatus() == ITestResult.SUCCESS) {
            node.log(Status.PASS, MarkupHelper.createLabel(result.getName()+" PASSED ", ExtentColor.GREEN));
            node.addScreenCaptureFromPath(capture(mobiledriver));

        }
        else {
            node.log(Status.SKIP, MarkupHelper.createLabel(result.getName()+" SKIPPED ", ExtentColor.ORANGE));
            node.skip(result.getThrowable());
            node.addScreenCaptureFromPath(capture(mobiledriver));


        }
    }

}
