package org.firstlight.test.mobilesetup;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.github.javafaker.Faker;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class AahaAndroidEmulator {

    public static AndroidDriver mobiledriver;
    public static WebDriverWait wait;


    //builds a new report using the html template
    ExtentSparkReporter htmlReporter;

    ExtentReports extent;
    //helps to generate the logs in test report.
    ExtentTest test, node;

    @BeforeTest
    public void setUp() throws Exception{

        File file = new File("src");
        File app = new File(file, "aaha-app.apk");
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("deviceName", "emulator-5554");
        capabilities.setCapability("app", app.getAbsolutePath());
        capabilities.setCapability("appPackage", "ahaflix.tv");
        capabilities.setCapability("appActivity", "ahaflix.tv.views.MainActivity");
        //TODO: Have to update the logic based on the test scenarios condition
        //capabilities.setCapability("fullReset", false);
       //capabilities.setCapability("noReset", true);
        capabilities.setCapability("newCommandTimeout", 60);

        mobiledriver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

    }





    @Test(priority = 0)
    public void launchTheApp() throws Exception{

        System.out.println("Current session Id: "+mobiledriver.getSessionId());
        // set timeout for driver actions (similar to step timeout)
        mobiledriver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);
        By by;

        // 1. Reset App
        // Clear application data and restart (Auto-generated)
        Thread.sleep(500);
        mobiledriver.launchApp();
        node = test.createNode("App is launched");

        //default telugu and english
        System.out.println("Current Activity " +mobiledriver.currentActivity());
        System.out.println("Current Package "+ mobiledriver.getCurrentPackage());
        //verify home page is displayed
        wait = new WebDriverWait(mobiledriver, 30);
        AndroidElement loaded = (AndroidElement) wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text='New Releases']")));
        if(loaded.isDisplayed())
             node = test.createNode("Verify home page is loaded");
        else
            Assert.fail("Home page is not loaded");


    }

    private void defaultOption(AndroidDriver mobiledriver) throws Exception{

        try {
            //select the telugu content
            mobiledriver.manage().timeouts().implicitlyWait(20000, TimeUnit.MILLISECONDS);
            By by = By.xpath("//android.widget.TextView[@text='Telugu']");
            mobiledriver.findElement(by).click();
            node = test.createNode("Click the Telugu Option ", "Successfully Clicked");
            Thread.sleep(500);
            by = By.xpath("//android.widget.TextView[@text='English']");
            mobiledriver.findElement(by).click();
            node = test.createNode("Click the English Button", "Successfully Clicked");

        }catch(Exception e){
            node = test.createNode("Landing option page is skipped");
        }
    }

    private void adb_dpad_left(AndroidDriver mobiledriver) throws Exception{
        Thread.sleep(1000);
        Map<String, Object> leftSideMenu = new HashMap<>();
        leftSideMenu.put("command", "input keyevent 21");
        leftSideMenu.put("includeStderr", true);
        mobiledriver.executeScript("mobile: shell", leftSideMenu);
        Thread.sleep(3000);
    }


    @Test(priority = 1)
    public void navigateAllMenus() throws Exception{

        navigateMovies(mobiledriver);
        Thread.sleep(3000);
        navigateShows(mobiledriver);
        Thread.sleep(3000);
        navigateKids(mobiledriver);
        Thread.sleep(3000);
        navigateMyAha(mobiledriver);
        Thread.sleep(3000);
        navigateLanguage(mobiledriver);
        Thread.sleep(3000);

    }


    @Test(priority = 2)
    public void searchByText() throws Exception{
        adb_dpad_left(mobiledriver);
        Thread.sleep(2000);
        //click Movies and validate
        By by = By.xpath("//android.widget.TextView[contains(@text,'Search')]");
        mobiledriver.findElement(by).click();
        node = test.createNode("Navigate to Search Icon");

        Thread.sleep(3000);
        //enter the keys
        enterText(mobiledriver,"Hey");

        //validate result is displayed
        //TODO: Skip for now, need to do analysis why the below part skipping during execution
      /*  List<AndroidElement> lstMovies = (List<AndroidElement>) mobiledriver.findElementsByAccessibilityId("Card View");

        if(lstMovies.size()>0){
            node = test.createNode("Movies lists are displayed");
            //click the first movie
            AndroidElement firstMovie = (AndroidElement) mobiledriver.findElementByXPath("//android.widget.TextView[contains(@text,'Hey')]");
            firstMovie.click();
            node = test.createNode("First movie in search result is clicked");
        }else {
            Assert.fail("Movies are not returned for the given search parameter");
        }

       */

    }

    @Test(priority = 3)
    public void playMovie() throws Exception{
        //play the movie
        List<AndroidElement> lstButton = mobiledriver.findElements(By.xpath("//android.widget.TextView[contains(@text,'Start Watching')]"));

        if(lstButton.size()>0){
            lstButton.get(0).click();
            node = test.createNode("Start watching button is clicked");

            Thread.sleep(2000);
            //TODO: Add the login play movie functionality
            mobiledriver.navigate().back();
            mobiledriver.navigate().back();
            mobiledriver.navigate().back();

        }else
        {
            Assert.fail("Start watching button is not displayed");
        }
    }


    @Test(priority = 4)
    public void scrollDownToBottom() throws Exception{
        navigateMovies(mobiledriver);
        Thread.sleep(3000);
        try {
            mobiledriver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"aha Shorts\"))");
        }catch(Exception e) {
          Assert.fail("Scroll to end of the page is failed");
        }

        MobileElement scrollToEnd = (MobileElement) mobiledriver.findElementByXPath("//android.widget.TextView[contains(@text,'aha Shorts')]");

        if(scrollToEnd.isDisplayed()){
            node = test.createNode("Scrolled to end of the page and the last carousel is displaying");
        }
        //scroll to top for continue the flow
        try {
            mobiledriver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Trending Now\"))");
            node = test.createNode("Scrolled to top of the page and the first carousel is displaying");
        }catch(Exception e) {
            Assert.fail("Scroll to top of the page is failed");
        }
    }






    @Test(priority = 5)
    public void carouselSlider() throws Exception{
        navigateMovies(mobiledriver);
        By by = By.xpath("//android.view.ViewGroup[2]/android.widget.HorizontalScrollView/android.view.ViewGroup/android.view.ViewGroup");
        List<AndroidElement> e=mobiledriver.findElements(by);
        for(int i=0; i< e.size()/2; i++){
            horizontalScroll(mobiledriver,  e);
            e=mobiledriver.findElements(by);
        }

    }

    private void horizontalScroll(AndroidDriver mobiledriver, List<AndroidElement> e){
        AndroidElement firdelement=e.get(0);
        AndroidElement thirdElement=e.get(2);

        int midOfY =thirdElement.getLocation().y +(thirdElement.getSize().height/2);
        int fromXLocation=thirdElement.getLocation().x;
        int toXLocation=firdelement.getLocation().x;

        TouchAction action =new TouchAction(mobiledriver);
        action.press(PointOption.point(fromXLocation, midOfY))
                .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(3)))
                .moveTo(PointOption.point(toXLocation, midOfY))
                .release()
                .perform();
    }


    private void enterText(AndroidDriver mobiledriver, String moveiName) throws Exception{

        char[] eachChar = moveiName.toCharArray();

        for(int i=0; i<eachChar.length; i++){

            mobiledriver.findElementByXPath("//android.widget.TextView[contains(@text,'"+eachChar[i]+"')]").click();
            Thread.sleep(2000);
        }
    }

    private void navigateMovies(AndroidDriver mobiledriver) throws Exception{
        adb_dpad_left(mobiledriver);
        Thread.sleep(2000);
        //click Movies and validate
        By by = By.xpath("//android.widget.TextView[@text='Movies']");
        mobiledriver.findElement(by).click();
        AndroidElement moviesEle = (AndroidElement) wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text='Trending Now']")));
        if(moviesEle.isDisplayed())
            node = test.createNode("Navigate to movies");
        else
            Assert.fail("Navigate to movies failed");
    }

    private void navigateShows(AndroidDriver mobiledriver) throws Exception{
        adb_dpad_left(mobiledriver);
        Thread.sleep(2000);
        //click Movies and validate
        By by = By.xpath("//android.widget.TextView[@text='Shows']");
        mobiledriver.findElement(by).click();
        AndroidElement moviesEle = (AndroidElement) wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text='Latest Web Series']")));
        if(moviesEle.isDisplayed())
            node = test.createNode("Navigate to Shows");
        else
            Assert.fail("Navigate to Shows failed");
    }

    private void navigateKids(AndroidDriver mobiledriver) throws Exception{
        adb_dpad_left(mobiledriver);
        Thread.sleep(2000);
        //click Movies and validate
        By by = By.xpath("//android.widget.TextView[@text='Kids']");
        mobiledriver.findElement(by).click();
        AndroidElement moviesEle = (AndroidElement) wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text='Newly Added']")));
        if(moviesEle.isDisplayed())
            node = test.createNode("Navigate to Kids");
        else
            Assert.fail("Navigate to Kids failed");
    }

    private void navigateMyAha(AndroidDriver mobiledriver) throws Exception{
        adb_dpad_left(mobiledriver);
        Thread.sleep(2000);
        //click Movies and validate
        By by = By.xpath("//android.widget.TextView[contains(@text,'My')]");
        mobiledriver.findElement(by).click();
        node = test.createNode("Navigate to MyAha");
        wait.until(ExpectedConditions
                .visibilityOf( mobiledriver.findElementByAccessibilityId("Home")))
                .click();

    }

    private void navigateLanguage(AndroidDriver mobiledriver) throws Exception{
        adb_dpad_left(mobiledriver);
        Thread.sleep(2000);
        //click Movies and validate
        By by = By.xpath("//android.widget.TextView[contains(@text,'Language')]");
        mobiledriver.findElement(by).click();
        node = test.createNode("Navigate to Language");
        mobiledriver.navigate().back();


    }





    @BeforeTest
    public void startReport() throws Exception {
        // initialize the HtmlReporter

        Path targetPath = Paths.get(getClass().getResource("/").toURI()).getParent();

        htmlReporter = new ExtentSparkReporter(targetPath.toString() +"\\results\\testReport.html");

        //initialize ExtentReports and attach the HtmlReporter
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        //To add system or environment info by using the setSystemInfo method.
        extent.setSystemInfo("OS", "Android");
        extent.setSystemInfo("Browser", "Null");

        //configuration items to change the look and feel
        //add content, manage tests etc
        //htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setDocumentTitle("Extent Report Demo");
        htmlReporter.config().setReportName("Test Report");
        //htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
    }


    @AfterTest
    public void tearDown() {
        //to write or update test information to reporter
        if (extent != null) {

            extent.flush();

        }
        //mobiledriver.closeApp();
        mobiledriver.quit();
    }

    public  String capture(MobileDriver driver) throws Exception
    {
        TakesScreenshot ts = (TakesScreenshot)driver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        Faker faker = new Faker();
        Path targetPath = Paths.get(getClass().getResource("/").toURI()).getParent();
        String dest =  "errorscreenshots/screenshot_"+ faker.number().randomNumber()+".png";

        File directory = new File(new File(targetPath + "\\results\\" + dest).getParent());
        if(!directory.exists()){
            directory.mkdir();
        }
        //targetPath+"\\results\\
        File destination = new File(targetPath+"\\results\\"+dest);
        FileUtils.copyFile(source, destination);

        return dest;
    }

    @BeforeMethod
    public void nameBefore(Method method)
    {
        test = extent.createTest(method.getName());

    }

    @AfterMethod
    public void getResult(ITestResult result) throws Exception{
        if(result.getStatus() == ITestResult.FAILURE) {
            node.log(Status.FAIL, MarkupHelper.createLabel(result.getName()+" FAILED ", ExtentColor.RED));
            node.fail(result.getThrowable());
            node.addScreenCaptureFromPath(capture(mobiledriver));

        }
        else if(result.getStatus() == ITestResult.SUCCESS) {
            node.log(Status.PASS, MarkupHelper.createLabel(result.getName()+" PASSED ", ExtentColor.GREEN));
            node.addScreenCaptureFromPath(capture(mobiledriver));

        }
        else {
            node.log(Status.SKIP, MarkupHelper.createLabel(result.getName()+" SKIPPED ", ExtentColor.ORANGE));
            node.skip(result.getThrowable());
            node.addScreenCaptureFromPath(capture(mobiledriver));


        }
    }

}
