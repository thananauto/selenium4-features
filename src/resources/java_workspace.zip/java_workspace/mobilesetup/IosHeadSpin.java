package org.firstlight.test.mobilesetup;

import com.github.javafaker.Faker;
import com.google.common.collect.ImmutableMap;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

public class IosHeadSpin {



    public static void main(String[] args) throws Exception {

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("platformName", "tvOS");
        capabilities.setCapability("deviceName", "Apple TV 4K");
        capabilities.setCapability("udid", "d22ed6c0d68ce7a828d226ddf03e01fd4e2ee8b7");
        capabilities.setCapability("automationName", "XCUITest");
        capabilities.setCapability("bundleId", "com.aha.ahaflix");
        capabilities.setCapability("platformVersion", "14.4");

        String url = "https://dev-us-pao-5.headspin.io:7010/v0/03b742c600824a47971f06fe943f328e/wd/hub";
       IOSDriver iosDriver = new IOSDriver(new URL(url), capabilities);



        boolean isAppInstalled= iosDriver.isAppInstalled("com.aha.ahaflix");
        System.out.println("App Installed: "+isAppInstalled);

        iosDriver.executeScript("mobile: pressButton", ImmutableMap.of("name", "left"));

        capture(iosDriver);
        iosDriver.executeScript("mobile: scroll", ImmutableMap.of("direction", "down"));



    }

    public  static String capture(MobileDriver driver) throws Exception
    {
        TakesScreenshot ts = (TakesScreenshot)driver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        Faker faker = new Faker();
        Path targetPath = Paths.get(IosHeadSpin.class.getResource("/").toURI()).getParent();
        String dest =  "errorscreenshots/screenshot_"+ faker.number().randomNumber()+".png";

        File directory = new File(new File(targetPath + "\\results\\" + dest).getParent());
        if(!directory.exists()){
            directory.mkdir();
        }
        //targetPath+"\\results\\
        File destination = new File(targetPath+"\\results\\"+dest);
        FileUtils.copyFile(source, destination);

        return dest;
    }
}
