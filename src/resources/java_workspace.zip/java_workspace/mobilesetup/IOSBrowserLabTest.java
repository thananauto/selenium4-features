package org.firstlight.test.mobilesetup;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.ios.IOSDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class IOSBrowserLabTest {
    //TODO: need a ipk file to do a test
    public static final String USERNAME = "mobileqa_NhXWiy";
    public static final String ACCESS_KEY = "9EBpFo4kiDN5H9XypTFH";
    public static final String URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@hub-cloud.browserstack.com/wd/hub";
    public static IOSDriver mobiledriver;


    @BeforeTest
    public void beforeTest( ) throws MalformedURLException {
        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability("device", "Samsung Galaxy S8 Plus");
        capabilities.setCapability("os_version", "7.0");
        capabilities.setCapability("project", "My First Project");
        capabilities.setCapability("build", "My First Build");
        capabilities.setCapability("name", "Bstack-[Java] Sample Test");
        capabilities.setCapability("app", "bs://eaa00b9a52fde6d28ab5f66d9bf69255ac4c9580");
        mobiledriver = new IOSDriver(new URL(URL), capabilities);
    }

    @AfterTest
    public void afterTest( ){
        mobiledriver.quit();
    }

    @Test
    public static void navigateAnimation() throws Exception{
        //wait for animation text

        MobileElement animationElement = (MobileElement) new WebDriverWait(mobiledriver, 30).until(
                ExpectedConditions.elementToBeClickable(
                        MobileBy.AccessibilityId("Animation")));
        animationElement.click();

        Thread.sleep(2000);
        List<MobileElement> allProductsName = (List<MobileElement>)mobiledriver.findElementsByAccessibilityId(
                "android:id/text1");
         assert(allProductsName.size() > 0);

        MobileElement eventsElement = (MobileElement) new WebDriverWait(mobiledriver, 30).until(
                ExpectedConditions.elementToBeClickable(
                        MobileBy.AccessibilityId("Events")));
        eventsElement.click();



        //single back


        mobiledriver.navigate().back();
        mobiledriver.navigate().back();




        // mobiledriver.get("http://appium.io/");
        //Assert.assertEquals(mobiledriver.getCurrentUrl(), "http://appium.io/", "URL Mismatch");
        //Assert.assertEquals(mobiledriver.getTitle(), "Appium: Mobile App Automation Made Awesome.", "Title Mismatch");
    }

}
