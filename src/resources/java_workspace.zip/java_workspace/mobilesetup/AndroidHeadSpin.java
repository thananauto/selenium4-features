package org.firstlight.test.mobilesetup;

import com.github.javafaker.Faker;
import com.google.common.collect.ImmutableMap;
import com.google.errorprone.annotations.Immutable;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.ios.IOSDriver;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

public class AndroidHeadSpin {



    public static void main(String[] args) throws Exception {

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("deviceName", "AFTMM");
        capabilities.setCapability("udid", "G070VM201225209X");
        capabilities.setCapability("automationName", "UiAutomator2");
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("appPackage", "ahaflix.tv");
        capabilities.setCapability("appActivity", "ahaflix.tv.views.MainActivity");
        capabilities.setCapability("autoAcceptAlerts", true);

       AndroidDriver mobileDriver = new AndroidDriver(new URL("https://dev-us-pao-5.headspin.io:7039/v0/03b742c600824a47971f06fe943f328e/wd/hub"), capabilities);



        mobileDriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        boolean isAppInstalled= mobileDriver.isAppInstalled("ahaflix.tv");
        System.out.println("App Installed: "+isAppInstalled);
         By objTelugu = By.xpath("//android.widget.TextView[contains(@text,'Telugu')]");
         By objEnglish = By.xpath("//android.widget.TextView[contains(@text,'English')]");
        mobileDriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

       mobileDriver.findElement(objTelugu).click();
       mobileDriver.findElement(objEnglish).click();

       Thread.sleep(4000);

        mobileDriver.executeScript("mobile: shell ", ImmutableMap.of("command","input keyevent 21"));

        Thread.sleep(4000);



    }

    public  static String capture(MobileDriver driver) throws Exception
    {
        TakesScreenshot ts = (TakesScreenshot)driver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        Faker faker = new Faker();
        Path targetPath = Paths.get(AndroidHeadSpin.class.getResource("/").toURI()).getParent();
        String dest =  "errorscreenshots/screenshot_"+ faker.number().randomNumber()+".png";

        File directory = new File(new File(targetPath + "\\results\\" + dest).getParent());
        if(!directory.exists()){
            directory.mkdir();
        }
        //targetPath+"\\results\\
        File destination = new File(targetPath+"\\results\\"+dest);
        FileUtils.copyFile(source, destination);

        return dest;
    }
}
