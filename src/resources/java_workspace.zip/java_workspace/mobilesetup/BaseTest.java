package org.firstlight.test.mobilesetup;

import io.appium.java_client.service.local.AppiumDriverLocalService;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import java.net.URL;

public abstract class BaseTest {


    private AppiumDriverLocalService service;

    @BeforeSuite
    public void startService(){
        service = AppiumDriverLocalService.buildDefaultService();
        service.start();
    }


    @AfterSuite
    public void tearTown(){
        if(service !=null){
            service.stop();
        }
    }

    public URL getServiceUrl(){
        return service.getUrl();
    }

}
