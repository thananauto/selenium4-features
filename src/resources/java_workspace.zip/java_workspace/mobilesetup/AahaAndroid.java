package org.firstlight.test.mobilesetup;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.github.javafaker.Faker;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class AahaAndroid {

    public static final String USERNAME = "mobileqa_NhXWiy";
    public static final String ACCESS_KEY = "9EBpFo4kiDN5H9XypTFH";
    public static final String URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@hub-cloud.browserstack.com/wd/hub";
    public static AndroidDriver mobiledriver;


    //builds a new report using the html template
    ExtentSparkReporter htmlReporter;

    ExtentReports extent;
    //helps to generate the logs in test report.
    ExtentTest test, node;

    @BeforeTest
    public void realDevice() throws Exception{

        File file = new File("src");
        File app = new File(file, "aaha-app.apk");
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("deviceName", "192.168.231.199:5555");
        capabilities.setCapability("app", app.getAbsolutePath());
        capabilities.setCapability("appPackage", "ahaflix.tv");
        capabilities.setCapability("appActivity", "ahaflix.tv.views.MainActivity");

        mobiledriver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
       // mobiledriver = (AndroidDriver)driver;
        //Current Activity appActivity : ahaflix.tv.views.MainActivity
        //Current Package appPackage:ahaflix.tv

    }




    public void beforeTest( ) throws MalformedURLException {
        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability("device", "Samsung Galaxy S21 Ultra");
        capabilities.setCapability("os_version", "11.0");
        capabilities.setCapability("project", "Aaha Project");
        capabilities.setCapability("build", "My First Build");
        capabilities.setCapability("name", "Bstack-[Java] Sample Test");
        capabilities.setCapability("app", "bs://2a124867460e7881d6aa95f1bb10b715fdd7b2d7");
        mobiledriver = new AndroidDriver(new URL(URL), capabilities);
       // mobiledriver = new AndroidDriver(getServiceUrl(), capabilities);
       // System.out.println(getServiceUrl());
        //"app_url": "bs://2a124867460e7881d6aa95f1bb10b715fdd7b2d7"
    }

    @AfterTest
    public void afterTest( ){
        mobiledriver.quit();
    }

    @Test
    public  void navigateAnimation() throws Exception{


        System.out.println(mobiledriver.getSessionId());
         // set timeout for driver actions (similar to step timeout)
        mobiledriver.manage().timeouts().implicitlyWait(15000, TimeUnit.MILLISECONDS);

        By by;
        boolean booleanResult;

        // 1. Reset App
        //    Clear application data and restart (Auto-generated)
        Thread.sleep(500);
        mobiledriver.resetApp();

        System.out.println("Current Activity " +mobiledriver.currentActivity());
        System.out.println("Current Package "+ mobiledriver.getCurrentPackage());

        //1. click the next button
        by= By.xpath("//android.view.ViewGroup[@content-desc='NEXT_BUTTON']/android.view.View");
        mobiledriver.findElement(by).click();

        // 2. Click the proceed button
        Thread.sleep(500);
        by = By.xpath("//android.widget.TextView[@text='Proceed']");
        mobiledriver.findElement(by).click();
        mobiledriver.manage().timeouts().implicitlyWait(20000, TimeUnit.MILLISECONDS);

        // 3. Click the Skip button
        Thread.sleep(500);
        by = By.xpath("//android.widget.TextView[@text='Skip']");
        mobiledriver.findElement(by).click();

        // 4. Click the Movies  tab
        Thread.sleep(500);
        by = By.xpath("//android.widget.TextView[@text='Movies']");
        mobiledriver.findElement(by).click();

        // 5. Click the Movies  tab
        Thread.sleep(500);
        by = By.xpath("//android.widget.TextView[@text='Shows']");
        mobiledriver.findElement(by).click();

        // 5. Click the Movies  tab
        Thread.sleep(500);
        by = By.xpath("//android.widget.TextView[@text='Kids']");
        mobiledriver.findElement(by).click();

        // 6. Click 'My aha tab button'
        Thread.sleep(500);
        MobileElement myAhaELe = (MobileElement) mobiledriver.findElementByAccessibilityId("My aha, tab, 3 of 5");
        myAhaELe.click();

        mobiledriver.navigate().back();

        //7. Click the search button
        MobileElement searchIcon = (MobileElement) mobiledriver.findElementByAccessibilityId("Search, tab, 4 of 5");
        myAhaELe.click();


        //8. click the search box
        MobileElement textBox= (MobileElement) mobiledriver.findElementByXPath("//android.widget.EditText[contains(@text,'Search Title')]");
        textBox.sendKeys("Addham");


        //9. verify search result return a result

        List<MobileElement> lstSearchRslt = mobiledriver.findElementsByXPath("//android.view.ViewGroup[@content-desc='Card View']");

        if(lstSearchRslt.size() >0){

        }else{
            throw new Exception("Search result didn't yield any result");
        }

        //10 click Start Watching button
        MobileElement startWatching =(MobileElement) mobiledriver.findElementByXPath("//android.widget.TextView[@text='Start Watching']");
        startWatching.click();

        // 26. Close App
        Thread.sleep(500);

        node = test.createNode("Click the app");

    }




    @BeforeTest
    public void startReport() throws Exception {
        // initialize the HtmlReporter

        Path targetPath = Paths.get(getClass().getResource("/").toURI()).getParent();

        htmlReporter = new ExtentSparkReporter(targetPath.toString() +"\\results\\testReport.html");

        //initialize ExtentReports and attach the HtmlReporter
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        //To add system or environment info by using the setSystemInfo method.
        extent.setSystemInfo("OS", "Android");
        extent.setSystemInfo("Browser", "Null");

        //configuration items to change the look and feel
        //add content, manage tests etc
        //htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setDocumentTitle("Extent Report Demo");
        htmlReporter.config().setReportName("Test Report");
        //htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
    }


    @AfterTest
    public void tearDown() {
        //to write or update test information to reporter
        if (extent != null) {

            extent.flush();

        }
        mobiledriver.closeApp();
    }

    public  String capture(MobileDriver driver) throws Exception
    {
        TakesScreenshot ts = (TakesScreenshot)driver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        Faker faker = new Faker();
        Path targetPath = Paths.get(getClass().getResource("/").toURI()).getParent();
        String dest =  "errorscreenshots/screenshot_"+ faker.number().randomNumber()+".png";

        File directory = new File(new File(targetPath + "\\results\\" + dest).getParent());
        if(!directory.exists()){
            directory.mkdir();
        }
        //targetPath+"\\results\\
        File destination = new File(targetPath+"\\results\\"+dest);
        FileUtils.copyFile(source, destination);

        return dest;
    }

    @BeforeMethod
    public void nameBefore(Method method)
    {
        test = extent.createTest(method.getName());

    }

    @AfterMethod
    public void getResult(ITestResult result) throws Exception{
        if(result.getStatus() == ITestResult.FAILURE) {
            node.log(Status.FAIL, MarkupHelper.createLabel(result.getName()+" FAILED ", ExtentColor.RED));
            node.fail(result.getThrowable());
            node.addScreenCaptureFromPath(capture(mobiledriver));

        }
        else if(result.getStatus() == ITestResult.SUCCESS) {
            node.log(Status.PASS, MarkupHelper.createLabel(result.getName()+" PASSED ", ExtentColor.GREEN));
            node.addScreenCaptureFromPath(capture(mobiledriver));

        }
        else {
            node.log(Status.SKIP, MarkupHelper.createLabel(result.getName()+" SKIPPED ", ExtentColor.ORANGE));
            node.skip(result.getThrowable());
            node.addScreenCaptureFromPath(capture(mobiledriver));


        }
    }

}
