package org.firstlight.test.mobilesetup;

import com.github.javafaker.Faker;
import org.apache.commons.io.FileUtils;
import org.firstlight.test.runner.TestRunner;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class GetScreenShot {




}
