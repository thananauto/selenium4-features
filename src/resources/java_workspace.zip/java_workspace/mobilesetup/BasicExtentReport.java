package org.firstlight.test.mobilesetup;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.github.javafaker.Faker;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.*;

import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

public class BasicExtentReport {

    //builds a new report using the html template
    ExtentSparkReporter htmlReporter;

    ExtentReports extent;
    //helps to generate the logs in test report.
    ExtentTest test, node;

    //extent node



    @BeforeTest
    public void startReport() throws Exception {
        // initialize the HtmlReporter

        Path targetPath = Paths.get(getClass().getResource("/").toURI()).getParent();

        htmlReporter = new ExtentSparkReporter(targetPath.toString() +"\\results\\testReport.html");

        //initialize ExtentReports and attach the HtmlReporter
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        //To add system or environment info by using the setSystemInfo method.
        extent.setSystemInfo("OS", "Android");
        extent.setSystemInfo("Browser", "Null");

        //configuration items to change the look and feel
        //add content, manage tests etc
       // htmlReporter.config().setChartVisibilityOnOpen(true);
        htmlReporter.config().setDocumentTitle("Extent Report Demo");
        htmlReporter.config().setReportName("Test Report");
       // htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
        htmlReporter.config().setTheme(Theme.STANDARD);
        htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
    }


    @AfterTest
    public void tearDown() {
        //to write or update test information to reporter
        if (extent != null) {
            extent.flush();

        }
    }

    public  String capture(WebDriver driver, String screenShotName) throws Exception
    {
        TakesScreenshot ts = (TakesScreenshot)driver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        String scenarioSheetPath = GetScreenShot.class.getClassLoader().getResource("target").getPath();
        Faker faker = new Faker();
        Path targetPath = Paths.get(getClass().getResource("/").toURI()).getParent();
        String dest =  targetPath+"\\results\\ErrorScreenshots\\screenshot_"+ faker.number().randomNumber()+".png";
        File destination = new File(dest);
        FileUtils.copyFile(source, destination);

        return dest;
    }

    @BeforeMethod
    public void nameBefore(Method method)
    {
        test = extent.createTest(method.getName());

    }

    @AfterMethod
    public void getResult(ITestResult result) {
        if(result.getStatus() == ITestResult.FAILURE) {
            node.log(Status.FAIL, MarkupHelper.createLabel(result.getName()+" FAILED ", ExtentColor.RED));
            node.fail(result.getThrowable());

        }
        else if(result.getStatus() == ITestResult.SUCCESS) {
            node.log(Status.PASS, MarkupHelper.createLabel(result.getName()+" PASSED ", ExtentColor.GREEN));
        }
        else {
            node.log(Status.SKIP, MarkupHelper.createLabel(result.getName()+" SKIPPED ", ExtentColor.ORANGE));
            node.skip(result.getThrowable());

        }
    }
}

/**
@Test
public void testCase1() {
    node = test.createNode("Test Case 1", "PASSED test case");
    Assert.assertTrue(true);
}

@Test
public void testCase2() {
    node = test.createNode("Test Case 2", "PASSED test case");

    Assert.assertTrue(true);
}

@Test
public void testCase3() {
    node = test.createNode("Test Case 3", "PASSED test case");
    Assert.assertTrue(true);
}

@Test
public void testCase4() {
    node = test.createNode("Test Case 4", "PASSED test case");
    Assert.assertTrue(false);
}

@Test
public void testCase5() {
    node = test.createNode("Test Case 5", "SKIPPED test case");
    throw new SkipException("Skipping this test with exception");
}

@Test(enabled=false)
public void testCase6(){
    node = test.createNode("Test Case 6", "I'm Not Ready, please don't execute me");
}

@BeforeMethod
public void nameBefore(Method method)
{
    test = extent.createTest(method.getName());

}

@AfterMethod
public void getResult(ITestResult result) {
    if(result.getStatus() == ITestResult.FAILURE) {
        node.log(Status.FAIL, MarkupHelper.createLabel(result.getName()+" FAILED ", ExtentColor.RED));
        node.fail(result.getThrowable());

    }
    else if(result.getStatus() == ITestResult.SUCCESS) {
        node.log(Status.PASS, MarkupHelper.createLabel(result.getName()+" PASSED ", ExtentColor.GREEN));
    }
    else {
        node.log(Status.SKIP, MarkupHelper.createLabel(result.getName()+" SKIPPED ", ExtentColor.ORANGE));
        node.skip(result.getThrowable());

    }
}
**/
