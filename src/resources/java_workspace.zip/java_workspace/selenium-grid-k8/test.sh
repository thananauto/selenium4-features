input=$1
echo input
while [ "$input" == "false" ]
  do
      # Print the values
       echo "I came inside while loop"
       input=true
done

echo "Loop successfully exited $1"