package com.test.slack;

import com.github.seratch.jslack.Slack;
import com.github.seratch.jslack.api.model.Attachment;
import com.github.seratch.jslack.api.webhook.Payload;
import com.github.seratch.jslack.api.webhook.WebhookResponse;
import com.github.seratch.jslack.app_backend.interactive_messages.payload.AttachmentActionPayload;
import org.junit.Test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SlackJavaIntegration {


    private static final Logger LOGGER =  LoggerFactory.getLogger(SlackJavaIntegration.class);
    private static final String NEW_LINE = "\n";

    private static String urlSlackWebHook = "https://hooks.slack.com/services/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";



    @Test
    public void attachment(){

    }

    @Test
    public void test() throws IOException {

       /* Slack slack = Slack.getInstance();
        Payload payload = Payload.builder().text("Hello, World!").build();
        WebhookResponse response = slack.send(urlSlackWebHook, payload);
        System.out.println(response);*/
        sendMessageToSlack("Hi..  I am new here");

    }



    public void sendMessageToSlack(String message) {
        StringBuilder messageBuider = new StringBuilder();
        messageBuider.append("*My message*: " + message + NEW_LINE);
        messageBuider.append("*Item example:* " + exampleMessage() + NEW_LINE);

        process(messageBuider.toString());
    }

    private void process(String message) {

        List<Attachment> lstAttachment = new ArrayList<>();

        Payload payload = Payload.builder()
                .channel("#automation-qa")
                .username("automation-qa")
                .iconEmoji(":rocket:")
                //.attachments(lstAttachment)
                .build();
        try {
            WebhookResponse webhookResponse = Slack.getInstance().send(
                    urlSlackWebHook, payload);
            LOGGER.info("code -> " + webhookResponse.getCode());
            LOGGER.info("body -> " + webhookResponse.getBody());
        } catch (IOException e) {
            LOGGER.error("Unexpected Error! WebHook:" + urlSlackWebHook);
        }
    }

    private String exampleMessage(){
        return "Lorem ipsum dolor sit amet, consectetur adipiscing elit. "
                + "Aliquam eu odio est. Donec viverra hendrerit lacus et tempor.";
    }
}
