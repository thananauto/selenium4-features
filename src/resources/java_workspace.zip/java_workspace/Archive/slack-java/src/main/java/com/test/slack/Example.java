package com.test.slack;


import com.github.seratch.jslack.api.webhook.Payload;

import java.io.FileNotFoundException;

public class Example {
    public static void main(String[] args) throws FileNotFoundException {
        SlackMessage slackMessage = SlackMessage.builder()
                .channel("#automation-qa")
                .username("automation-qa")
                .text("Sending zip files")
                .iconEmoji(":rocket:")
                .build();
       /*Payload payload = Payload.builder()
                .channel("#automation-qa")
                .username("automation-qa")
                .iconEmoji(":rocket:")
                .build();
                */

        SlackUtils.sendMessage(slackMessage);
    }
}