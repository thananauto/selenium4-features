package com.test.slack;

import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.OkHttpClient;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.FileEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;


import java.io.*;

public class SlackUtils {
    private static String slackWebhookUrl =  "https://hooks.slack.com/services/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";

    public static void sendMessage(SlackMessage message) throws FileNotFoundException {
        CloseableHttpClient client = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(slackWebhookUrl);
        InputStream inputStream = new FileInputStream("check.zip");
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String json = objectMapper.writeValueAsString(message);
            // StringEntity entity = new StringEntity(json);
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            //builder.addBinaryBody
            //        ("upfile", file, ContentType.DEFAULT_BINARY, imageFileName);
            builder.addBinaryBody
                    ("file", inputStream, ContentType.create("application/zip"), "check.zip");
            builder.addTextBody("text", "New file", ContentType.TEXT_PLAIN);
            HttpEntity entity = builder.build();
            httpPost.setEntity(entity);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "multipart/form-data");

            client.execute(httpPost);
            client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
