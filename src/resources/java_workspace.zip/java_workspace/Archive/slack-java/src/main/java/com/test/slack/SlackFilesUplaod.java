package com.test.slack;


import com.slack.api.app_backend.slash_commands.payload.SlashCommandPayload;
import com.slack.api.bolt.App;
import com.slack.api.bolt.AppConfig;
import com.slack.api.bolt.jetty.SlackAppServer;
import com.slack.api.methods.SlackApiException;
import com.slack.api.webhook.Payload;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Logger;

public class SlackFilesUplaod {
        public static void main(String[] args) throws Exception {
            AppConfig config = new AppConfig();
            config.setSingleTeamBotToken(System.getenv("SLACK_BOT_TOKEN"));
            config.setSigningSecret(System.getenv("SLACK_SIGNING_SECRET"));
            App app = new App(config); // `new App()` does the same

            app.command("/testUpload", (req, ctx) -> {
                Logger logger = (Logger) ctx.logger;
                try {
                    SlashCommandPayload payload = req.getPayload();
                    // The name of the file you're going to upload
                    String filepath = "./myFileName.gif";
                    // Call the files.upload method using the built-in WebClient
                    Object result = ctx.client().filesUpload(r -> r
                            // The token you used to initialize your app is stored in the `context` object
                            .token(ctx.getBotToken())
                            .channels(Arrays.asList(payload.getChannelId()))
                            .initialComment("Here's my file :smile:")
                            // Include your filename in a ReadStream here
                            .file(new File(filepath))
                    );
                    // Print result
                    logger.info((String) result);
                } catch (IOException | SlackApiException e) {
                   // logger.error("error: {}", e.getMessage(), e);
                }
                // Acknowledge incoming command event
                return ctx.ack();
            });

            SlackAppServer server = new SlackAppServer(app);
            server.start();
        }

    }

