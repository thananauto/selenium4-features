Feature: ScenariosExample Example Feature File

  @one
  Scenario: Number One
    Given a step from 'Scenario 1' in 'ScenariosExampleExample' feature file

    @two @CHA-123
  Scenario: Number Two
    Given a step from 'Scenario 2' in 'ScenariosExampleExample' feature file

      @one
  Scenario: Number Three
    Given a step from 'Scenario 3' in 'ScenariosExample' feature file

        @two @CHA-456
  Scenario: Number Four
    Given a step from 'Scenario 4' in 'ScenariosExample' feature file

  @one
  Scenario: Number Five
    Given a step from 'Scenario 5' in 'ScenariosExample' feature file

  @two
  Scenario: Number Six
    Given a step from 'Scenario 6' in 'ScenariosExample' feature file

  @one
  Scenario: Number Seven
    Given a step from 'Scenario 7' in 'ScenariosExample' feature file

   @three
  Scenario: Number Eight
    Given a step from 'Scenario 8' in 'ScenariosExample' feature file

      @four @CHA-3
  Scenario: Number Nine
    Given a step from 'Scenario 9' in 'ScenariosExample' feature file

  @one @CHA-023
  Scenario: Number Ten
    Given a step from 'Scenario 10' in 'ScenariosExample' feature file