package com.qa.learn.runner;


 import com.qa.learn.utilities.TokenHolder;
 import io.cucumber.testng.AbstractTestNGCucumberTests;
 import io.cucumber.testng.CucumberOptions;
 import io.cucumber.testng.FeatureWrapper;
 import io.cucumber.testng.PickleWrapper;
 import org.testng.annotations.*;

 import java.util.HashMap;

@CucumberOptions(
        plugin =  {"summary", "json:target/cucumber-json.json",
        "tech.grasshopper.AllureCucumberMappingPlugin:target/cucumber-allure.json" },
        features = {"classpath:features"},
        glue = {"com.qa.learn.stepdefinition", "com.qa.learn.hooks"},
       // dryRun = true,
        tags = ""
)
public class TestRunnerIT extends AbstractTestNGCucumberTests {

private TokenHolder tokenHolder;
//public static HashMap<String, String> tokenMap;
 @BeforeClass
 public void setUp(){
  System.out.println("Calling for every scenarios" );
 }

 @AfterClass
 public void tearDown(){
 // TokenHolder.getMapToken().entrySet().stream().forEach(e -> System.out.println(e));

 }
 @Override
 @Test(
         groups = {"cucumber"},
         description = "Runs Cucumber Scenarios",
         dataProvider = "scenarios"

 )
 public void runScenario(PickleWrapper pickleWrapper, FeatureWrapper featureWrapper) {
  super.runScenario(pickleWrapper, featureWrapper);
 }

 @Override
 @DataProvider(parallel = true)
 public Object[][] scenarios() {

  return super.scenarios();
 }
}
