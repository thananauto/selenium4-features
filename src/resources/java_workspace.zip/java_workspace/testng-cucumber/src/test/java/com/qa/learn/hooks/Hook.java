package com.qa.learn.hooks;

import com.qa.learn.utilities.TokenHolder;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

import java.util.stream.Collectors;

public class Hook {


    private SharedObject sharedObject;
    private TokenHolder tokenHolder = TokenHolder.getInstance();

    public Hook(SharedObject sharedObject){
        this.sharedObject = sharedObject;
    }

    @Before
    public void scenarioSetUp(Scenario scenario){
       // tokenHolder = TokenHolder.getInstance();
       String tag = scenario.getSourceTagNames().stream().collect(Collectors.joining()).replace("@", "");
        System.out.println(tag);

        if( !tokenHolder.isTokenPresent(tag)){
            String random = (int)(Math.random()*(100-1+1)+1)+"";
            sharedObject.setToken(random);
            tokenHolder.setMapToken(tag, random);
            System.out.println("xx Name: "+scenario.getName()+" ----------> "+ random+" tag: "+tag);
        }else {
            String token = tokenHolder.getToken(tag);

            sharedObject.setToken(token);
            System.out.println("yy Name: "+scenario.getName()+" ----------> "+ token+" tag: "+tag);
        }


    }

    @After
    public void tearDownSetUp(Scenario scenario){

    }
}
