package com.qa.learn.utilities;


import java.util.HashMap;
import java.util.Map;

public  class TokenHolder {

    private  Map<String, String> mapToken = new HashMap<>();

    public static volatile TokenHolder INSTANCE;
    private static Object mutex = new Object();
    private TokenHolder(){

    }

    //double lock singelton design pattern
    public static TokenHolder getInstance() {
        TokenHolder result = INSTANCE;
        if (result == null) {
            synchronized (TokenHolder.class) {
                result = INSTANCE;
                if (result == null)
                    INSTANCE = result = new TokenHolder();
            }
        }
        return result;
    }
   /* // Inner class to provide instance of class
    private static class BillPughSingleton
    {
        private static final TokenHolder INSTANCE = new TokenHolder();
    }

    public static TokenHolder getInstance()
    {
        return BillPughSingleton.INSTANCE;
    }*/
/*
   public static  TokenHolder getInstance(){

            if(INSTANCE == null){
                synchronized (TokenHolder.class){
                    if(INSTANCE == null) {
                        INSTANCE = new TokenHolder();
                    }
            }
        }
       return INSTANCE ;
    }*/

    public  void setMapToken(String k, String v){

        mapToken.putIfAbsent(k, v);
    }

    public  Map<String, String> getMapToken(){
        return mapToken;
    }

    public  String getToken(String k){
        return mapToken.get(k);
    }

    public   boolean isTokenPresent(String token){

        return mapToken.containsKey(token);
    }

}
