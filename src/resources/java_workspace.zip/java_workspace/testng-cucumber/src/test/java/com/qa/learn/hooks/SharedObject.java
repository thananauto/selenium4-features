package com.qa.learn.hooks;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SharedObject {

    private String token;
    private String userName;
}
