package com.qa.learn.utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public final class TokenFactory {

    private static ThreadLocal<HashMap<String, String>> tokenThread =ThreadLocal.withInitial(HashMap::new);

    // To quit the drivers and browsers at the end only.
    private static List<HashMap<String, String>> storedDrivers = new ArrayList<>();

    static {
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                storedDrivers.forEach(e -> e.clear());
            }
        });
    }

    private TokenFactory() {}

    public static String getTokens(String key){
        return  tokenThread.get().get(key);
    }

    public static void addToken(String key, String value) {
        //storedDrivers.add(driver);
        tokenThread.get().putIfAbsent(key, value);
        //tokenThread.set(driver);
    }

    public static void removeToken() {
        tokenThread.get().clear();
        //drivers.remove();
    }

    public static boolean isTokenPresent(String key){
        return tokenThread.get().containsKey(key);

    }
}
