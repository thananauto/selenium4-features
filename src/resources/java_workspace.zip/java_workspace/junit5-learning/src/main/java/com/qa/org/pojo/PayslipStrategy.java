package com.qa.org.pojo;

import com.github.javafaker.Faker;
import com.qa.org.entity.Payslip;
import uk.co.jemos.podam.api.PodamFactoryImpl;
import uk.co.jemos.podam.common.AttributeStrategy;

import javax.xml.stream.events.Attribute;
import java.lang.annotation.Annotation;
import java.util.List;

public class PayslipStrategy implements AttributeStrategy<Payslip> {
    @Override
    public Payslip getValue(Class<?> aClass, List<Annotation> list) {
        return new PodamFactoryImpl().manufacturePojo(Payslip.class);
    }
}
