package com.qa.org.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import uk.co.jemos.podam.common.PodamDoubleValue;
import uk.co.jemos.podam.common.PodamFloatValue;
import uk.co.jemos.podam.common.PodamIntValue;
import uk.co.jemos.podam.common.PodamLongValue;

@Data
public class Payslip {
    @PodamIntValue(minValue = 1, maxValue = 12)
    private int month;
    @PodamLongValue(minValue = 2000L, maxValue = 2020L)
    private Long year;
    @PodamFloatValue(minValue = 100.0f, maxValue = 1000.0f)
    private float salary;

}
