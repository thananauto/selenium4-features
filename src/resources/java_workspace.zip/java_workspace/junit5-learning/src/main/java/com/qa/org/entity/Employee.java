package com.qa.org.entity;

import com.qa.org.pojo.NameStrategy;
import com.qa.org.pojo.PayslipStrategy;
import lombok.Data;
import uk.co.jemos.podam.common.PodamCollection;
import uk.co.jemos.podam.common.PodamIntValue;
import uk.co.jemos.podam.common.PodamStrategyValue;

import java.util.List;

@Data
public class Employee {
    @PodamStrategyValue(value = NameStrategy.class)
    private String firstName;

    @PodamStrategyValue(value = NameStrategy.class)
    private String lastName;

    @PodamIntValue(minValue = 23, maxValue = 40)
    private Integer age;

    @PodamCollection(nbrElements = 3, collectionElementStrategy = PayslipStrategy.class)
    private List<Payslip> salaryPayslip;
}
