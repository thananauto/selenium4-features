package com.qa.org.testdata;

import com.qa.org.entity.Employee;
import com.qa.org.entity.Payslip;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class TestData {
    private static PodamFactoryImpl FACTORY = new PodamFactoryImpl();



    public static Employee getEmployeeFata(){
        return FACTORY.manufacturePojo(Employee.class);
    }
}
