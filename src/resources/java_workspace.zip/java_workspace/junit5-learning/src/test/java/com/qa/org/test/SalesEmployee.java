package com.qa.org.test;

import com.qa.org.entity.Employee;
import com.qa.org.testdata.TestData;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

import java.util.regex.Pattern;

import static org.assertj.core.api.Assertions.assertThat;


public class SalesEmployee {
Employee employee;

    @BeforeEach
    void setUp(){
         employee = TestData.getEmployeeFata();
    }


    @Test
    @DisplayName("Employee age should be number")
    @SneakyThrows
    public void employee_age_is_number(){
        assertThat(employee.getAge())
                .as("Age should be more that 20")
                .isGreaterThan(20);
        Thread.sleep(2000);
    }

    @Test
    @DisplayName("Employee name is string only")
    public void employee_name_is_string(){
        assertThat(employee.getFirstName())
        .as("Employee name should be string")
        .containsPattern(Pattern.compile("^[^0-9]*$"));
    }

    @ParameterizedTest
    @DisplayName("Empoyee: ${0} and age: ${1}")
    @CsvFileSource(resources = "/employee.csv", numLinesToSkip = 1)
    void check_all_employee_age_from_csv(String name, int age){
        assertThat(age).isGreaterThanOrEqualTo(20);
    }


}
