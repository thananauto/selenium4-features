package org.coding;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Sorting {

    @Test
    public void java8Sort(){
        int[] arr ={3,9,5,7,2};
       Integer[] arr1= Arrays.stream(arr)
                .boxed()
                        .toArray(Integer[]::new);
       //sorted in descending order
        Arrays.sort(arr1, Collections.reverseOrder());
        Arrays.stream(arr1).collect(Collectors.toList()).forEach(System.out::println);
    }

    @Test
    public void bubbleSort(){
        //swap the element instantly
        int[] arr ={3,9,5,7,2};

        for(int i=0; i<arr.length-1; i++){
            for(int j=0; j<arr.length - i-1; j++){
                if(arr[j] > arr[j+1]){
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;

                }
            }
        }
        Arrays.stream(arr).boxed().collect(Collectors.toList()).forEach(System.out::println);
    }


    @Test
    public void selectionSort(){
        //get the minimum index and sort based on that

        String name = "Thanan";

        int[] arr ={3,9,5,7,2};


        int n = arr.length;
        for(int i=0; i<n-1; i++){
            int minIndex = i;
            for(int j=i+1; j<n ; j++){
                if(arr[minIndex] > arr[j]){
                    minIndex = j;
                }
            }

            //now swap the value
                int temp = arr[minIndex];
                arr[minIndex] = arr[i];
                arr[i] =temp;
        }
        Arrays.stream(arr).boxed().collect(Collectors.toList()).forEach(System.out::println);
    }

    @Test
    public void countingDuplicates(){
        String op ="indivisibility".toLowerCase();

       int ip = Arrays.stream(op.split(""))
                .collect(Collectors.groupingBy(e->e, Collectors.counting()))
                .entrySet()
                .stream()
                .filter(e->e.getValue()>1)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue))
                .size();

        System.out.println(ip);
    }




}
