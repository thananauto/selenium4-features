package org.java7;

import org.junit.Test;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
public class Tester {

    public int recursion(int i){
        if (i == 0)
            return 1;
        else
            return(i * recursion(i-1));
    }

    @Test
    public void test(){

        System.out.println(recursion(5));

    }


    @Test
    public void check_array(){
        //String arr = "Mani,kandan,Thanan,Jayan";
       String arr = "Manikandan";
        for (int i = 0; i < arr.split(",").length; i++) {
            System.out.println(arr.split(",")[i]);

        }
       // Arrays.stream(arr.split(",")).forEach(e -> System.out.println(e));
    }

    @Test
    public void getSystemEnv(){
        System.setProperty("PASSEd", "5");
       // System.getenv().forEach((k,v)-> System.out.println(k+" ----> "+v));

        System.getProperties().forEach((k,v)-> System.out.println(k+" ----> "+v));
    }

    @Test
    public void string_literal(){
        String key ="{{myKey}}";
        if(key.contains("{{myKey}}")){
            key = key.replaceAll("\\{\\{myKey}}", "super");
            System.out.println(key);
        }

        String id = String.format("%04d", new Random().nextInt(10000));
        System.out.println(id);
    }


    @Test
    public void removeDupliciateInArray(){
        Integer[] arr = {1,2,1,4,5,6,7, 3, 5, 2, 1,0};
        List<Integer> lstArr = Arrays.asList(arr);
        HashMap<Integer, Integer> op = new HashMap<>();

        for(Integer eachItem: lstArr){
            if(op.containsKey(eachItem)){
                int count = op.get(eachItem);
                count++;
                op.put(eachItem, count);
            }else{
                op.put(eachItem, 0);
            }
        }
        System.out.println(op);
    }


    @Test
    public void reverseAnArray() throws Exception {
        String[] arr = {"a", "b", "c", "d"};
        String[] newArr = new String[arr.length];
        int count =0;
        for(int i = arr.length-1; i>=0; i--){
            newArr[count] = arr[i];
            count++;

        }
        Arrays.stream(newArr).forEach(e -> System.out.println(e));

        String name = "ManiMi";
        char[] charName = name.toCharArray();
        for(int  j=0; j<charName.length; j++){
            for(int k=j+1; k<charName.length; k++){
                if(charName[j] == charName[k]){
                    System.out.println(charName[j] );
                }
            }
        }


    }


    @Test
    public void testMap(){
        HashMap<String, String> mapInput=  new HashMap<>();
        mapInput.put("name", "David");
        mapInput.put("email", "test@gmail");
        mapInput.put("age", "30");

        int size = mapInput.size();
        System.out.println(size);

        String name = mapInput.get("name");
        System.out.println(name);

        for(Map.Entry<String, String> each: mapInput.entrySet()){
            System.out.println(each.getKey()+ " -------> "+each.getValue());
        }

    }

    @Test
    public  void dateTest() {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("M/d/yyyy");
        LocalDate today = LocalDate.parse("1/9/2024", dateTimeFormatter);//LocalDate.of(2020, 5, 5);
        System.out.println("Today: "+today);

        System.out.println("Added  business days "+addBusinessDays(today, 5, Optional.empty()));

        // Add one holiday for testing
        List<LocalDate> holidays = new ArrayList<>();
        holidays.add(LocalDate.of(2024, 1, 11));
        holidays.add(LocalDate.of(2024, 1, 16));
        System.out.println("calendar :"+calendarDays(LocalDate.now(), 5));
        System.out.println(addBusinessDays(today, 5, Optional.of(holidays)));

        System.out.println(subtractBusinessDays(today, 5, Optional.empty()));
        System.out
                .println(subtractBusinessDays(today, 5, Optional.of(holidays)));

        System.out.println(countBusinessDaysBetween_Java8(today,
                today.plusDays(20), Optional.empty()).size());
       /* System.out.println(countBusinessDaysBetween_Java9(today,
                today.plusDays(20), Optional.of(holidays)).size());*/
    }

    private static LocalDate addBusinessDays(final LocalDate localDate,
                                             int days, final Optional<List<LocalDate>> holidays) {
        if (localDate == null || days <= 0) {
            throw new IllegalArgumentException(
                    "Invalid method argument(s) to addBusinessDays(" + localDate
                            + "," + days + "," + holidays + ")");
        }

        Predicate<LocalDate> isHoliday = date -> holidays.isPresent()
                && holidays.get()
                .contains(date);

        Predicate<LocalDate> isWeekend = date -> date
                .getDayOfWeek() == DayOfWeek.SATURDAY
                || date.getDayOfWeek() == DayOfWeek.SUNDAY;

        LocalDate result = localDate;
        while (days > 0) {
            result = result.plusDays(1);
            if (isHoliday.or(isWeekend)
                    .negate()
                    .test(result)) {
                days--;
            }
        }
        return result;
    }

    private static LocalDate calendarDays(final LocalDate localDate,
                                          int days){
        LocalDate result = localDate;
        while(days > 0){
            result = result.plusDays(1);
            days --;
        }

        return result;
    }

    private static LocalDate subtractBusinessDays(final LocalDate localDate,
                                                  int days, final Optional<List<LocalDate>> holidays) {

        if (localDate == null || days <= 0) {
            throw new IllegalArgumentException(
                    "Invalid method argument(s) to addBusinessDays(" + localDate
                            + "," + days + "," + holidays + ")");
        }

        Predicate<LocalDate> isHoliday = date -> holidays.isPresent()
                && holidays.get()
                .contains(date);

        Predicate<LocalDate> isWeekend = date -> date
                .getDayOfWeek() == DayOfWeek.SATURDAY
                || date.getDayOfWeek() == DayOfWeek.SUNDAY;

        LocalDate result = localDate;
        while (days > 0) {
            result = result.minusDays(1);
            if (isHoliday.or(isWeekend)
                    .negate()
                    .test(result)) {
                days--;
            }
        }
        return result;
    }

    private static List<LocalDate> countBusinessDaysBetween_Java8(
            final LocalDate startDate, final LocalDate endDate,
            final Optional<List<LocalDate>> holidays) {
        // Validate method arguments
        if (startDate == null || endDate == null) {
            throw new IllegalArgumentException(
                    "Invalid method argument(s) to countBusinessDaysBetween ("
                            + startDate + "," + endDate + "," + holidays + ")");
        }

        // Predicate 1 : Is a given date is holiday
        Predicate<LocalDate> isHoliday = date -> holidays.isPresent()
                && holidays.get()
                .contains(date);

        // Predicate 2 : Is a given date is weekday
        Predicate<LocalDate> isWeekend = date -> date
                .getDayOfWeek() == DayOfWeek.SATURDAY
                || date.getDayOfWeek() == DayOfWeek.SUNDAY;

        // Get all days between two dates
        long daysBetween = ChronoUnit.DAYS.between(startDate, endDate);

        // Iterate over stream of all dates and check each day against any weekday or
        // holiday
        return Stream.iterate(startDate, date -> date.plusDays(1))
                .limit(daysBetween)
                .filter(isHoliday.or(isWeekend)
                        .negate())
                .collect(Collectors.toList());
    }

    /*private static List<LocalDate> countBusinessDaysBetween_Java9(
            final LocalDate startDate, final LocalDate endDate,
            final Optional<List<LocalDate>> holidays) {
        // Validate method arguments
        if (startDate == null || endDate == null) {
            throw new IllegalArgumentException(
                    "Invalid method argument(s) to countBusinessDaysBetween ("
                            + startDate + "," + endDate + "," + holidays + ")");
        }

        // Predicate 1 : Is a given date is holiday
        Predicate<LocalDate> isHoliday = date -> holidays.isPresent()
                && holidays.get()
                .contains(date);

        // Predicate 2 : Is a given date is weekday
        Predicate<LocalDate> isWeekend = date -> date
                .getDayOfWeek() == DayOfWeek.SATURDAY
                || date.getDayOfWeek() == DayOfWeek.SUNDAY;

        // Iterate over stream of all dates and check each day against any weekday or
        // holiday
        List<LocalDate> businessDays = startDate.datesUntil(endDate)
                .filter(isWeekend.or(isHoliday)
                        .negate())
                .collect(Collectors.toList());

        return businessDays;
    }*/
}
