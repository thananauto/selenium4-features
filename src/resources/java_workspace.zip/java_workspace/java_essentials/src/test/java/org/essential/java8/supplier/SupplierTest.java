package org.essential.java8.supplier;

import org.junit.Test;

import java.util.function.Supplier;

public class SupplierTest {


    @Test
    public void createClass(){
        Human hum = getObject(Human::new);

    }

    public <T> T getObject(Supplier<T> obj){
        return obj.get();
    }
}

class Human{
    String person;
    String age;
    Human(){}
    Human(String name, String age){
        this.person = name;
        this.age = age;
    }
}
