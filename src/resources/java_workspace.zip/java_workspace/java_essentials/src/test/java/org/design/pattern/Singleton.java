package org.design.pattern;

import groovy.util.logging.Log4j;
import org.checkerframework.checker.units.qual.C;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Singleton {



    @Test
    public void singlePattern(){

        WebDriver driver = GetDriver.getInstance();
        driver.get("http://saucedemo.com");

       new  WebDriverWait(driver, Duration.ofSeconds(10))
               .until(ExpectedConditions.titleContains("Swag"));

       driver.quit();

    }

}

class GetDriver {
    private static  WebDriver driver ;
    private GetDriver(){}
    public static WebDriver getInstance(){

        synchronized (GetDriver.class){
            if(Objects.isNull(driver))
                return  new ChromeDriver();
            return driver;
        }


    }

}

class LoggerClass {
    private static Logger log4j;
    private LoggerClass(){}

    public Logger getInstance(){
        return Objects.isNull(log4j) ? Logger.getLogger(LoggerClass.class.getName()): log4j;
    }

    public void setInfo(String msg){
        log4j.info(msg);
        log4j.log(Level.SEVERE, msg);
    }

    public void setWarn(String warn){
        log4j.warning(warn);
    }


}
