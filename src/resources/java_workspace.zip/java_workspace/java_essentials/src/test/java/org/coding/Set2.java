package org.coding;

import org.checkerframework.checker.units.qual.A;
import org.hamcrest.Condition;
import org.junit.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.function.Function;
import java.util.function.LongUnaryOperator;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.Stream;

public class Set2 {

    @Test
    public void validParanthesis(){
        String[] ip = "([])".split("");
        String op ="";
        String pattern = ")]}";
        Stack<String> lstOp = new Stack<>();
        for(String a : ip){
            if(pattern.contains(a)){
                op+=lstOp.pop()+a;
            }else{
                lstOp.push(a);
            }
        }
        System.out.println(op);
        if(op.equals(String.join("", ip)))
            System.out.println("Both are equal");
        else
            System.out.println("Not equal");
    }

    @Test
    public void checkTwoStringAnaghram(){
        String ip1 ="Silent".toLowerCase();
        String[] ip2 = {"Liston".toLowerCase()};
        char[] charsIp1 = ip1.toCharArray();
        ip1.chars()
                .mapToObj(n -> (char) n + "")
                .toList()
                . forEach(e->{
            ip2[0] = ip2[0].replace(e,"");
        });
        if(ip2[0].equals(""))
            System.out.println("Both string are anagharam");


    }
    @Test
    public void factorialRecursion(){
        int n = 5;
        int op = IntStream.rangeClosed(1, n).reduce(1,(a,b)-> a*b);
        System.out.println(op);
    }

    @Test
    public void secondLargestEle(){
        int[] arr = {12, 5, 8, 19, 29};
       int op = Arrays.stream(arr)
                .sorted()
                .limit(arr.length -1)
                .max().getAsInt();
        System.out.println(op);
    }


    @Test
    public void fibonacciNumber(){
        int n =100;
       /* List<Long> lsyOp = new ArrayList<>();
        lsyOp.add(0L);
        lsyOp.add(1L);
        while(0<=n-2){
            lsyOp.add(lsyOp.get(lsyOp.size()-1) + lsyOp.get(lsyOp.size()-2));
            n--;

        }
        lsyOp.forEach(System.out::println);*/
        long[] a={0};
        long[] b={1};
        LongUnaryOperator assign = (z) ->{
            long next = a[0];
            a[0] = b[0];
            b[0] = next + b[0];
            return b[0];
        };
        LongStream.range(0,n-2)
                .map(assign)
                .forEach(System.out::println);


    }

    @Test
    public void bungleWord() {
        char[][] chars = {{'I', 'L', 'A', 'W'},
                {'B', 'N', 'G', 'E'},
                {'I', 'U', 'A', 'O'},
                {'A', 'S', 'R', 'L'}};

        for(int i=0; i<chars.length-1; i++){
            for(int j = 0; j< chars[i].length-1; i++){
                System.out.println(chars[i][j]);
            }
        }


    }

    @Test
    public void firstNonRepeatCharacters(){
        String s = "streSS".toLowerCase();

       String op = Arrays.stream(s.toLowerCase().split("")).filter(e -> s.indexOf(e) == s.lastIndexOf(e))
                .findFirst()
                .get();

      int index1 = IntStream.range(0, s.length())
                       .filter(index ->{
                           char c = s.charAt(index);
                            return s.indexOf(c) == s.lastIndexOf(c);
                       })
                               .findFirst().getAsInt();
        System.out.println(op);
        System.out.println(s.charAt(index1));
    }

    @Test
    public void zeroToInfinity(){

        Function<Double, Double> factorial = (x)->{
            double op = 1;
            while(x>=1){
                op= op * x;
                x--;
            }
            return op;
        };
        int n =7;
       double sum = IntStream.rangeClosed(1, n)
                .boxed()
                .map(x -> factorial.apply((double)x))
                .mapToDouble(Double::valueOf)
                .sum();

        double div = factorial.apply((double)n);
            System.out.println((1/div)* sum);
        BigDecimal bd = new BigDecimal((1/div)* sum).setScale(6, RoundingMode.HALF_DOWN);
        System.out.println(bd.doubleValue());

    }

    @Test
    public void testMeanSquareError(){
       int[] arr1 = {1, 2, 3};
       int[] arr2 = {4, 5, 6};
        List<Integer> lstIn = new ArrayList<>(Arrays.stream(arr1).boxed().toList());
       Collections.sort(lstIn,(o1, o2) -> o1.compareTo(o2));
        System.out.println(lstIn);
        Collections.unmodifiableSet(new HashSet<>(lstIn));
          IntStream.range(0,arr1.length)
                  .map((index -> arr1[index] - arr2[index]))
                  .map(e -> e*e)
                  .average().orElse(0);


    }

    @Test
    public void JosephusSurvivor(){
        Integer[] arr = {1,2,3,4,5,6,7};
        List<Integer> ip = new ArrayList<>(Arrays.asList(arr));
        List<Integer> index = new ArrayList<>();
        int count = 0;
        while (ip.size() >1) {
            for (int i = 0; i < ip.size(); i++) {
                count++;
                if (count == 3) {
                    count = 0;
                    index.add(i + 1);
                }

            }
            index.forEach(ip::remove);
        }

        System.out.println(ip);


      //  System.out.println(ip);
    }

    @Test
    public void binaryMulTo3(){
       boolean val = Pattern.compile("[0-9]*").matcher("110").matches();
        System.out.println(val);
    }

    @Test
    public void sumOfInterval(){
       // int[][] arrIp = {{0,20},{-100_000_000, 10}, {30, 40}};
        int[][] arrIp = {{-7,8},{-2, 10}, {5, 15}, {2000,3150}, {-5400, -5338}};
        //15+12+10+1150 +62
        Function<int[], Integer> number = (ele)->{
            return Arrays.stream(ele).boxed().reduce(0, (x, y) -> y - x);
        };

        int op = Arrays.stream(arrIp)
                .map(number)
                //.distinct()
                .mapToInt(Integer::valueOf)
                .sum();
        System.out.println(op);
    }

    @Test
    public void iterate(){
    String str = "How can mirrors be real if our eyes aren't real";
    List<String> lstStr = Arrays.asList(str.split(" "));
    Comparator<String> comparator = String::compareTo;

    Map<String, String> map = new HashMap<>();
    map.put("Hellpw","asdasd");
    map.put("Heldaslpw","asdasd");
    map.put("Hellpasw","asdasd");
    map.put("Hellasdpw","asdasd");

    boolean bln = true;
    Iterator<Map.Entry<String, String>> lstMap = map.entrySet().iterator();
    while (lstMap.hasNext()) {
        Map.Entry<String, String> op = lstMap.next();
        System.out.println(op.getKey() + " --- >> " + op.getValue());
        if(bln){
            lstMap.remove();
            bln = false;
        }

    }
        System.out.println(map);
}
    @Test
    public void firstCapitalCase(){

        String str = "How can mirrors be real if our eyes aren't real";
        Arrays.stream(str.split(" "))
                .map(e->e.substring(0,1).toUpperCase()+e.substring(1))
                .collect(Collectors.joining(" "));
        Collections.sort(Arrays.asList(str.split("")));

    }

    @Test
    public void binaryToNumber(){
        List<Integer> lstInt = Arrays.asList(0,0,1,1);

        String op =lstInt.stream()
                .map(String::valueOf)
                .collect(Collectors.joining(""));

        System.out.println(Integer.parseInt(op, 2));
    }

    @Test
    public void removeLastAndFirst(){
        String name = "Thanan";
        name = name.substring(1, name.length()-2);
    }

    @Test
    public void vowelsCount(){
        String ip = "pear tree";
        Arrays.stream(ip.split(""))
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet()
                .stream()
                .filter(e-> Arrays.asList("a","e","i","o","u").contains(e.getKey()))
                .mapToLong(e->e.getValue())
                .sum();




    }

    @Test
    public void duplicateEncoder(){
        String ip ="(( @".toLowerCase();
        String[] chars = ip.split("");
        String op="";
        for(String c:chars){
            op+=ip.indexOf(c) == ip.lastIndexOf(c) ? "(" :")";
        }
        System.out.println(op);

       String oo = ip.chars()
                .mapToObj(e->ip.indexOf(e) == ip.lastIndexOf(e) ? "(" :")")
                .collect(Collectors.joining());
        System.out.println(oo);
    }

    @Test
    public void sumOfNumbers(){
        int a = -1, b=2;

        a = Math.min(a, b);


        int op =IntStream.rangeClosed(a, b)
                .sum();
        System.out.println(op);
    }

    @Test
    public void persistentBugger(){
        int num = 4;

        int count = 0;
        while(num>9){
            num = Math.toIntExact(Arrays.stream(String.valueOf(num).split(""))
                    .map(Long::valueOf)
                    .reduce(1L, (n1, n2) -> n1 * n2));
            count++;
        }
        System.out.println(count);
        System.out.println(Math.absExact(-9));
    }

    @Test
    public void givenSideTraingle(){
        int a = 4,b=2, c=3;
        int[] arr ={1,-4,7,12};


        Arrays.stream(arr).filter(e-> e>0).sum();
        System.out.println(Math.ceil((double) 1705/100));
    }

    @Test
    public void highAndLow(){
        String numbers = "1 2 -3 4 5";

        Stream.of(numbers.split(" ")).mapToInt(Integer::parseInt).summaryStatistics();
       List<Integer> minAndMax = Stream.of(numbers.split(" "))
               .map(Integer::parseInt)
               .sorted().toList();

        System.out.println(minAndMax.get(0));
        System.out.println(minAndMax.get(minAndMax.size() -1));

    }

    @Test
    public void binaryAddition(){
        int n = 2;
        String result = "";
        while(n>=1){
            result =   n%2+result;
             n= Math.abs(n/2);
        }
        System.out.println(result);
    }

    @Test
    public void sumNumbers(){
        IntStream.rangeClosed(0, 6).sum();
        long l = 144;
        double db = Math.sqrt( l);
        System.out.println(db/(int)db);
        System.out.println(db);
        System.out.println(Math.pow(12, 2));
    }

    @Test
    public void  squareSum(){
        int[] numbers = {1, 2, 2};
        Arrays.stream(numbers).boxed()
                .mapToInt(e->e*2)
                .sum();
    }

    @Test
    public void shortestString(){
        String s = "import java ut stream IntStream";


        Integer a = Arrays.asList(s.split(" "))
                .stream().map(String::length)
                .reduce(Integer::min).get();
        System.out.println(a);
    }

    @Test
    public void  stringRepeat(){

        Object op =IntStream.range(0,5)
                .boxed()
                .map(e-> "Hello")
                .collect(Collectors.joining(""));
        System.out.println(op);

    }

    @Test
    public void consecutiveOddNumber(){

        LinkedList<Integer> oddInt = IntStream.range(0, 100)
                .boxed()
                .filter(e -> !(e%2==0))
                .collect(Collectors.toCollection(LinkedList::new));

        System.out.println(IntStream.range(0, 100)
                .boxed()
                .filter(e -> !(e%2==0)).toList());


        int n= 3;

       HashMap<Integer, List<Integer>> lstItem = new HashMap<>();
       for(int i=1; i<n; i++){
           for(int j=0; j<i; j++)
           oddInt.remove(j);
       }
        System.out.println(oddInt);


    }

    @Test
    public void listFiltering(){
         List.of(1, 2, "a", "b").stream()
                 //.map(String::valueOf)
                 .filter(e->e instanceof Integer)

                 .toList();


    }

    @Test
    public void casting()
    {
        String num = "4";
        int intNum = 4;
        double dbleNum = 4.2345;
        float fltNum = 4.2345f;



        System.out.println(dbleNum);
        System.out.println(fltNum);

        System.out.println(String.valueOf(fltNum));
    }

    @Test
    public void leapYear(){
        int leap = 2015;

        Integer s = Stream.of(leap).filter(e -> e % 4 == 0 )
                .findFirst()
                .orElseGet(() -> {
                    return Stream.of(leap).filter(e -> !(e % 100 == 0) &&  e % 400 == 0)
                            .findFirst()
                            .orElse(null);
                });



       if(Objects.nonNull(s))
           System.out.println("Leap year");
       else
           System.out.println("Not leap year");

        System.out.println(String.format("Octal: %x",100));
        System.out.println(String.format("%s,%09d","Thanan",0));
        System.out.println(String.format("%09d",100));
        System.out.println(String.format("Output is %b",9!=9));
        System.out.println(String.format("Hello world %09.4f, %s",100.00, "Thanan"));

    }

    @Test
    public void stripComments(){
        String text = """
               a #b\nc\nd $e f g
                """;
        String[] commentSymbols ={"#", "$"};
        String[] textArr = text.split("\n");;
        for(String sym: commentSymbols){
            for(int i=0; i< textArr.length; i++){
                textArr[i] = textArr[i].split(sym)[0];
            }
        }
        String op = Arrays.stream(textArr)
                //.reduce("", (b1,b2)->b1+b2+"\n");
                .map(e->e.trim())
                        .collect(Collectors.joining("\n"));
        System.out.println(op);
    }

    @Test
    public void wordScrambles(){
        String ip = "scriptjavx";
        String com = "javascript";

        for(int i=0; i< com.length(); i++){

            int index = ip.indexOf(com.charAt(i));
            if(index <0){
                System.out.println("Not found");
                break;
            }
            ip= ip.substring(0,index)+ip.substring(index+1);
           // iparr[index] ="";
        }
    }


    @Test
    public void whoLikesIt(){
        String[] names = {"John", "peter", "Mahen", "Welldone", "sdas"};
        String[] charac = {",", "and"};
        List<String> lstNames = Arrays.asList(names);
        if(lstNames.size() == 0) {
            System.out.println("no one likes this");
        }else if(lstNames.size() >3){
            String op = lstNames.stream().limit(2).collect(Collectors.joining(", "))+" and "+(lstNames.size()-2)+" others like this";
            System.out.println(op);
        }else {
           // lstNames.stream().

        }
    }

    @Test
    public void giveMeDiamond(){



        int n = 5;
        Function<Integer, String> func = num ->{

            String op ="";
            while(num>0){
                op+="*";
                num--;
            }
            return op+"\n";
        };

        IntStream.rangeClosed(1, n)
                .boxed()
                .filter(i->!(i%2==0))
                .map(func)
                .forEach(System.out::println);
    }


    @Test
    public void topWords(){
        String ip = """
        In a village of La Mancha, the name of which I have no desire to call to
        mind, there lived not long since one of those gentlemen that keep a lance
        in the lance-rack, an old buckler, a lean hack, and a greyhound for
        coursing. An olla of rather more beef than mutton, a salad on most
        nights, scraps on Saturdays, lentils on Fridays, and a pigeon or so extra
        on Sundays, made away with three-quarters of his income.
        """;
        Function<String, String> rep = e -> e.replaceAll(",", " ")
                                            .replaceAll("#", " ")
                .replaceAll("/", " ")
                .replaceAll(".", " ").replaceAll("...", " ");

       Arrays.asList(ip.split(" ")).stream()
                .map(e->e.replaceAll(","," "))
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet()
                .stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
               .limit(3)
               .map(Map.Entry::getKey)
               .collect(Collectors.toList())
               .forEach(System.out::println);
             //   .max(Map.Entry.comparingByValue())
              //  .map(e-> e.getKey())
               // .orElse("not maximum");
       // System.out.println(poes);
    }
}
