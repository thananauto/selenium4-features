package org.abs.java8.training;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class AnonymousInnerClass {

    public static void main(String[] args) {
        //anonymous inner class using concrete
        Car jeep = new Car(){
            public void  howManyTyres(){
                System.out.println("Should have 5 tyres");
            }
        };

        jeep.howManyTyres();
        Car audi = new Car();
        audi.howManyTyres();

        //anonnmous class with Abstract
        Animal cow = new Animal() {
            @Override
            void isCarOrHerb() {
                System.out.println("Is Herbivores");
            }
            public void  sense(){
                System.out.println("Have 4 sense....");
            }

        };
        cow.isCarOrHerb();
        cow.haveLegs();


    //interface anonymous class
    Rainbow blue = new Rainbow() {

        @Override
        public void setColors(List<String> color) {

                colors.addAll(color);
        }

        @Override
        public String getColors() {
            return colors.stream().collect(Collectors.joining(" "));
        }
    };

       blue.setColors(Arrays.asList("Red", "blue", "green"));
       blue.getBlueprint();
        System.out.println(blue.getColors());
    }





}

interface Rainbow {
    public static final List<String> colors = new ArrayList<>();
    void setColors(List<String> colors);
    String getColors();

    static void check(){
        System.out.println("dadas");
    }

    default  List<String> getBlueprint(){
        System.out.println("Get the blue print");
        return colors;

    }
}

abstract  class Animal{
    public void haveLegs(){
        System.out.println("All animal have four legs");
    }

    public void  sense(){
        System.out.println("Have 5 sense....");
    }

    abstract void isCarOrHerb();
}

class  Car{

    public void safetyFeatures(){
        System.out.println("Car should have safetly features ");
    }

    public void powerStering(){
        System.out.println("Should have power stering");
    }

    public void  howManyTyres(){
        System.out.println("Should have 4 tyres");
    }
}


