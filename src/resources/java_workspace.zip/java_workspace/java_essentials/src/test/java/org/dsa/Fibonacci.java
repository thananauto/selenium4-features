package org.dsa;

public class Fibonacci {

    public static long fibonacci(int N) {
        if (N <= 0) {
            return 0;
        } else if (N == 1) {
            return 1;
        }

        long a = 0, b = 1;
        for (int i = 2; i <= N; i++) {
            long next = a + b;
            a = b;
            b = next;
        }
        return b;
    }

    public static void main(String[] args) {
        int N = 100;
        System.out.println("The " + N + "th Fibonacci number is: " + fibonacci(N));
    }
}