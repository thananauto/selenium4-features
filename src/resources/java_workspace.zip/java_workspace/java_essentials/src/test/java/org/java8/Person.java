package org.java8;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class Person {
    private String fname;
    private String lname;
    private  int age;
    private double salary;
}
