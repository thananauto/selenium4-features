package org.abs.java8.training;

import org.junit.Test;

public class DefaultMethodInterface {

    @Test
    public void checkMethod(){

        Browser chrome = new Chrome();
        chrome.maximise();
        chrome.minimise();

        Browser firefox = new Firefox();
        firefox.maximise();
        firefox.minimise();
    }
}
@FunctionalInterface
interface Browser {

    void maximise();

    default void minimise(){
        System.out.println("Minimised browser");
    }

}

class Chrome implements Browser{
    void capabilities(){
        System.out.println("chrome capabilities");
    }

    @Override
    public void maximise() {
        System.out.println("Maximise windows");
    }
}


class Firefox implements Browser{
    void capabilities(){
        System.out.println("firefox capabilities");
    }

    public void minimise(){
        System.out.println("Minimised firefox");
    }
    @Override
    public void maximise() {
        System.out.println("Maximise windows");
    }
}

