package org.abs.java8.training;

import org.junit.Test;
import org.testng.AssertJUnit;

import java.util.*;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class ComparatorClass {

   static List<Pupil> lstPupil =  Arrays.asList(new Pupil("Kumar", 40, 3, "Male"),
           new Pupil("Lenin", 56, 6, "Male"),
           new Pupil("Thanan", 32, 5, "Male"),
           new Pupil("Ann", 30, 3, "Female"),
           new Pupil("Linga", 27, 6, "Male"),
           new Pupil("Sugnathi", 49, 5, "Female"),
           new Pupil("Lenin", 30, 3, "Male"));
    @Test
    public void testComparableDefaultObject() {
        String obj2 = "Thanans";
        String obj1 = "Thanansadasd";
        if (obj1.compareTo(obj2) == 0)
            System.out.println("Both are equal");
        else if (obj1.compareTo(obj2) < 1)
            System.out.println("Both are not equal: " + obj1.compareTo(obj2));
        else
            System.out.println("Both are not not equal: " + obj1.compareTo(obj2));
    }

    @Test
    public void testComparableObject() {
        String ip = "aBcA1bC2";
        char[] character = ip.toCharArray();
        Pupil pupil = new Pupil("Thanan", 20, 35, "Male");

        List<Pupil> lstPupil = new ArrayList<Pupil>() {
            {
                add(new Pupil("Kumar", 40, 3, "Male"));
                add(new Pupil("Lofan", 60, 6, "Male"));
                add(new Pupil("Thanan", 20, 5, "Male"));
                add(new Pupil("Mani", 30, 3, "Male"));
            }
        };
        System.out.println("========================");
        lstPupil.forEach(System.out::println);
        List<Pupil> lstPupil2 = lstPupil.stream().map(p -> {
                    p.setPlace("chennai");
                    return p;
                })
                .peek(System.out::println).collect(Collectors.toList());
    }

    @Test
    public void testComparator() {

        Comparator<Pupil> lowToHighAge = (pupil1, pupil2) -> Integer.compare(pupil1.getAge(), pupil2.getAge());
        Comparator<Pupil> highToLowAge = (pupil1, pupil2) -> Integer.compare(pupil2.getAge(), pupil1.getAge());

        Comparator<Pupil> lowToHighStd = (pupil1, pupil2) -> pupil1.getStandard() - pupil2.getStandard();
        Comparator<Pupil> highToLowStd = (pupil1, pupil2) -> pupil2.getStandard() - pupil1.getStandard();

        List<Pupil> lstPupil = Arrays.asList(new Pupil("Kumar", 40, 3, "Male"),
                new Pupil("Lofan", Integer.MAX_VALUE, 6, "Male"),
                new Pupil("Thanan", Integer.MIN_VALUE, 5, "Male"),
                new Pupil("Mani", 30, 3, "Male"));
        Collections.sort(lstPupil, lowToHighAge);
        lstPupil.forEach(System.out::println);
        System.out.println("========================");
        Collections.sort(lstPupil, highToLowAge);
        lstPupil.forEach(System.out::println);
        System.out.println("========================");
        Collections.sort(lstPupil, lowToHighStd);
        lstPupil.forEach(System.out::println);
        System.out.println("========================");
        Collections.sort(lstPupil, highToLowStd);
        lstPupil.forEach(System.out::println);

    }

    @Test
    public void testComparatorFilter() {

        Comparator<Pupil> lowToHighAge = (pupil1, pupil2) -> Integer.compare(pupil1.getAge(), pupil2.getAge());
        Comparator<Pupil> highToLowAge = (pupil1, pupil2) -> Integer.compare(pupil2.getAge(), pupil1.getAge());

        Comparator<Pupil> lowToHighStd = (pupil1, pupil2) -> pupil1.getStandard() - pupil2.getStandard();
        Comparator<Pupil> highToLowStd = (pupil1, pupil2) -> pupil2.getStandard() - pupil1.getStandard();

        List<Pupil> lstPupil = Arrays.asList(new Pupil("Kumar", 40, 3, "Male"),
                new Pupil("Lofan", 56, 6, "Male"),
                new Pupil("Thanan", 32, 5, "Male"),
                new Pupil("Ann", 30, 3, "Female"),
                new Pupil("Linga", 27, 6, "Male"),
                new Pupil("Sugnathi", 49, 5, "Female"),
                new Pupil("Lenin", 30, 3, "Male"));


        lstPupil.stream()
                .map(e -> {
                    e.setPlace("Mumbai");
                    return e;
                })
                .filter(e -> e.getGender().equalsIgnoreCase("male"))
                .sorted(Comparator.comparing(Pupil::getAge))
                .collect(Collectors.toList())
                .forEach(System.out::println);
    }

    @Test
    public void testDistinct(){
        Comparator<String> comp = (x, y) -> y.compareTo(x);
        Arrays.asList("A","A","C","V","D","Z")
                .stream()
                .distinct()
                .max(comp.reversed())
                .ifPresent(System.out::println);


    }

    @Test
    public void testLimit(){
        Comparator<String> comp = (x, y) -> x.compareTo(y);
        Supplier<String> supp = ()->"A";
        Arrays.asList("A","A","C","V","D","Z")
                .stream()
                .limit(3)
                .forEach(System.out::println );



    }

    @Test
    public void testMap(){
        Comparator<String> comp = (x, y) -> x.compareTo(y);
        lstPupil
                .stream()
                .map(e -> {e.setPlace("Bombay"); return e;})
                .filter(e -> e.getAge() > 40)
                .collect(Collectors.groupingBy(Pupil::getName))
                .forEach((k,v)->{
                    System.out.println("Key: "+k);
                    System.out.println("Value "+v);
                });

      int sum =  Arrays.asList("Hello", "World", "Life", "Welcome")
                .stream()
                .filter(e -> e.length() >4)
                .collect(Collectors.toMap(Function.identity(), String::length))
                .entrySet()
                .stream().peek(e-> System.out.println(e.getValue()))
                .map(Map.Entry::getValue)
                .collect(Collectors.summingInt(e->e));

        System.out.println(sum);

    }

    @Test
    public void testFlatMap(){
        List<List<String>> listOfLists = Arrays.asList(
                Arrays.asList("Geeks", "For"),
                Arrays.asList("GeeksForGeeks", "A computer portal"),
                Arrays.asList("Java", "Programming")
        );
        listOfLists
                .stream()
                .flatMap(lst -> lst.stream().map(String::toUpperCase))
                //.map(e->e.stream().map(f->f.toUpperCase(Locale.ROOT)))
                .collect(Collectors.toList())
                .stream().collect(Collectors.toMap(String::toLowerCase, e ->e.toUpperCase(Locale.ROOT)))
               .entrySet().forEach(System.out::println);

        // Creating a List of Strings
        List<String> list = Arrays.asList("Geeks", "GFG", "GeeksforGeeks", "gfg");

        // Using Stream flatMap(Function mapper)
        list.stream()
                .map(str -> str.charAt(2))
                .forEach(System.out::println);


    }

    @Test
    public void testAnyMatch(){
        List<String> list = Arrays.asList("Geeks", "GFG", "GeeksforGeeks", "gfg");
      boolean op = list.stream()
               .anyMatch(e-> e.length() >3);
        System.out.println(op);
    }

    @Test
    public void testAllMatch(){
        List<String> list = Arrays.asList("Geeks", "GFGs", "GeeksforGeeks", "gfgs");
       boolean op = list.stream()
                .allMatch(e-> e.length() >3);
        System.out.println(op);
    }

    @Test
    public void testNoneMatch(){
        List<String> list = Arrays.asList("Geeks", "GFGs", "GeeksforGeeks", "gfgs");
        boolean op = list.stream()
                .noneMatch(e-> e.length() >100);
        System.out.println(op);
    }

    @Test
    public void testFindFirst(){
        List<String> list = Arrays.asList("Geeks", "GFGs", "GeeksforGeeks", "gfgs");
        String op =list.stream()
                .findFirst().get();
        System.out.println(op);
    }
}
