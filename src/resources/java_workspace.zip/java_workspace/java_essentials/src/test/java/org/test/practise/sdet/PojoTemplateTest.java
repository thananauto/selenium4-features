package org.test.practise.sdet;

import br.com.six2six.fixturefactory.Fixture;
import br.com.six2six.fixturefactory.loader.FixtureFactoryLoader;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.test.practise.pojo.Employee;

import java.util.List;

import static io.restassured.RestAssured.given;

public class PojoTemplateTest {

    @Before
    public void setUp(){
        FixtureFactoryLoader.loadTemplates("org.test.practise.template");
    }


    @Test
    public void fixtureTemplate(){
       /* Fixture.of(Employee.class).addTemplate("valid", new Rule(){{
            add("id", random(Integer.class, range(0, 100)));
            add("firstName", random("thanan", "jayan", "majni"));
            add("isFTE", random(true, false));
            add("address", random(new Address("kamaraj", "chennai")));
            add("roles", uniqueRandom(Arrays.asList("tester"), Arrays.asList("Manager")));
        }});*/

       List<Employee> employee = Fixture.from(Employee.class).gimme(10, "valid");
       employee.forEach(System.out::println);
    }

    @Test
    public void postEmployeeTest_validdata_201() throws JsonProcessingException {

        //get the all templates by label name

        Employee employee = Fixture.from(Employee.class).gimme("valid");
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String json = ow.writeValueAsString(employee);
        System.out.println(json);
        Response response = given()
                .contentType(ContentType.JSON)
                .log()
                .all()
                .body(employee)
                .post("http://localhost:3000/user");

        Assert.assertEquals(response.getStatusCode(), 201);

    }

    @Test
    public void postEmployeeTest_invalidid_500(){

        //get the all templates by label name

        Employee employee = Fixture.from(Employee.class).gimme("invalid");
        Response response = given()
                .contentType(ContentType.JSON)
                .log()
                .all()
                .body(employee)
                .post("http://localhost:3000/user");

        Assert.assertEquals(response.getStatusCode(), 500);

    }

    @Test
    public void postEmployeeTest_invalidname_201(){

        //get the all templates by label name

        Employee employee = Fixture.from(Employee.class).gimme("invalidFirstName");
        Response response = given()
                .contentType(ContentType.JSON)
                .log()
                .all()
                .body(employee)
                .post("http://localhost:3000/user");

        Assert.assertEquals(response.getStatusCode(), 201);

    }

}
