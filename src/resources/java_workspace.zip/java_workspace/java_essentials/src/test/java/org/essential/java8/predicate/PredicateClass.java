package org.essential.java8.predicate;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PredicateClass {


    @Test
    public void test_predicate(){

        Predicate<Animal> pred = x -> x.getSex().equalsIgnoreCase("male");
        Predicate<Animal> nameWith_C = x-> x.getName().startsWith("C");
        Predicate<Animal> nameWith_X = x-> x.getName().startsWith("X");

        List<Animal> lstAnimals = Arrays.asList(new Animal("Jackey", "Male"),
                                                new Animal("Cuckoo", "Female"),
                                                new Animal("Labrator", "male"));

        lstAnimals.forEach(animal -> {
           if( pred.or(nameWith_C).test(animal)){
               System.out.println(animal.toString());
           }
        });
    }
}
