package org.generics;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TestGen {

    @Test
    public void addNumbers(){
        addNum(Arrays.asList(4,6,7,9));
        addNum(Arrays.asList(4.0,6.9,7.3,9.0));

    }

    public void addNum(List<? extends Number> numbers){

        int op = numbers.stream().mapToInt(e -> (int)e).sum();
        System.out.println(op);
    }

    @Test
    public void testTreeMap(){
        String[] names = {"Jumar", "Mahesg", "Felix", "Lovada"};

        Arrays.stream(names)
                .collect(Collectors.toMap(Function.identity(),String::length,(integer, integer2) -> integer.compareTo(integer2), TreeMap::new))
                .entrySet().forEach(e-> System.out.println(e.getKey()+" --> "+e.getValue()));

    }


    public void bubbleSort(){
        Integer[] numbers = { 5, 7,8,4};
        Character[] characters ={ 'a', 'd', 'u', 'l', 'p'};
        String[] names = {"Jumar", "Mahesg", "Felix", "Lovada"};
        bubbleSort(names);
        //bubbleSort(characters);
       // bubbleSort(names);
        //selectionSort(numbers);

    }
    public <K,V>  K hashCheck(Map<K, V> map){
        K k= map.entrySet().iterator().next().getKey();
        return k;
    }

    public <T extends Comparable<T>>  T[] selectionSort(T[] t){

        for(int i=0; i< t.length-1; i++){
            int min = i;
            for(int j=i+1; j<t.length ; j++){
                if(t[j].compareTo(t[min])<0)
                    min = j;
            }
            T temp = t[min];
            t[min] = t[i];
            t[i] = temp;

        }
        Stream.of(t).forEach(System.out::println);
        return t;

    }

    public <T extends Comparable<T>> T[] bubbleSort(T[] t){

        for(int i=0; i<t.length; i++){
            for(int j=0; j<t.length-1-i; j++){
                if(t[j].compareTo(t[j+1]) > 0){
                    T temp = t[j];
                      t[j] =t[j+1];
                    t[j+1] = temp;
                }

            }
        }
        Stream.of(t).forEach(System.out::println);
        return t;

    }
   @org.junit.Test
    public void genericsTest(){
       Add<String,String, String> addString = new StringAdd();
       addString.set("Hellow", "world");
       System.out.println(addString.add());

       Add<Integer, Integer, String>  addString1 = new IntegerAdd();
       addString1.set(4,5);
       System.out.println(addString1.add());

   }

   public <T> void print(T[] lst){
        Arrays.stream(lst).sorted()
                .mapToInt(e-> (int)e)
                .forEach(System.out::println);
   }
   @org.junit.Test
    public void methodGenerics(){
       Integer[] arrInt = {2,4,5,7,8};
       new TestGen().print(arrInt);

       Long[] arrDbl = {2l,4l,5l,7l,8l};
       new TestGen().print(arrDbl);

   }
}

class IntegerAdd implements Add<Integer, Integer,String>{
    private Integer op;
    @Override
    public void set(Integer a1, Integer a2) {
        this.op = a1+a2;
    }

    @Override
    public String add() {
        return String.valueOf(op);
    }
}
class StringAdd implements  Add<String, String, String>{

    private String op;
    @Override
    public void set(String a1, String a2) {
        this.op = a1+a2;
    }

    @Override
    public String add() {
        return op;
    }
}
