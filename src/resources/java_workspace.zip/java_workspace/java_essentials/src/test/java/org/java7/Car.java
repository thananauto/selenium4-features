package org.java7;

public interface Car {

    public static final String var = "car";

    void fourTyre();

    default void test(){
        System.out.println("Car running");
    }

}
