package org.test.practise.synchronisation;

import org.junit.Test;

public class MainThread {

    @Test
    public void test() throws InterruptedException {

        Counter c = new Counter();

        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                for(int i=0; i<100; i++){
                    c.incr();
                }
            }
        });
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                for(int i=0; i<100; i++){
                    c.incr();
                }
            }
        });

        t1.start();
        t2.start();

        System.out.println("Before"+ c.count);
        t1.join();

        System.out.println("After" + c.count);
        t2.join();
        System.out.println("Last" + c.count);
    }
}
