package org.abs.java8.training;

import org.builder.pattern.request.Employee;
import org.junit.Test;
import org.testng.AssertJUnit;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.*;

public class MethodReference {

    @Test
    public void testDesignPattern() {
        Student student = new Student.StudentBuilder()
                .setAge(20).setClassRoom(5).setName("prakask").build();
        assert student.getAge() == 20;
        assert student.getClassRoom() == 5;
        assert student.getName().equals("prakask");
        System.out.println(student);

        Organisation org = Organisation.builder()
                .setName("Thanan")
                .setAddress("Hellow")
                .build();
        assertThat(org.getAddress()).isEqualTo("Hellow");

    }

    @Test
    public void testStaticMethodReference(){
        BusDepot busDepot= new BusDepot();
        List<String> buses = Arrays.asList("27A", "12B", "39C");

        buses.stream().map(String::length).collect(Collectors.toSet());
        buses.forEach(BusDepot::getLocalBus);
        Map<String , String> mapBuses = buses.stream()
                .collect(Collectors.toMap((e)->e.substring(0,1), busDepot::getRouteBus));
        System.out.println(mapBuses);
        mapBuses.replaceAll((k,v)->{
            String s = v.split(" ")[v.split(" ").length -1];
            return s;
        });
        System.out.println(mapBuses);

        System.out.println(mapBuses);
    }
}

class BusDepot {

    public static  void getLocalBus(String localbus){
        System.out.println("This is local bus "+localbus);
    }


    public   String getRouteBus(String bus){
        return "This bus goes on route "+ bus;
    }

}
