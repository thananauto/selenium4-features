package org.java8.supporting;

public class Dog implements Animal{

    @Override
    public void run() {
        System.out.println("Running at 50 kmph");
    }
}

