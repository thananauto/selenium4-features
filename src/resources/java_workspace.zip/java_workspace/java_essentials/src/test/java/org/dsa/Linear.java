package org.dsa;

import org.apache.commons.collections4.queue.CircularFifoQueue;
import org.testng.annotations.Test;

import java.util.*;

public class Linear {

    @Test
    public void queueTest(){
        String msg = "Welcome";
        Queue q = new LinkedList();

        for(char c: msg.toCharArray()){
            q.add(c);
        }

        while(!q.isEmpty()){
            System.out.print(q.peek());
        }

    }

    @Test
    public void reverseStringStack(){
        String name = "Hello";
        Stack<Character> op = new Stack<>();
        for(char e : name.toCharArray()){
                    op.push(e);
        }

        while(!op.isEmpty()){
            System.out.print(op.pop());
        }
    }

    @Test
    public void circularQueue() throws Exception{

        CircularQueue q = new CircularQueue(4);
        q.enQueue('e');
        q.enQueue('r');
        q.enQueue('e');
        q.display();
        q.enQueue('f');
        q.deQueue();
        q.deQueue();
        q.deQueue();
        q.display();
        q.deQueue();
        //q.deQueue();

        q.enQueue('z');
        q.display();

        System.out.println(q.deQueue());




    }
}
