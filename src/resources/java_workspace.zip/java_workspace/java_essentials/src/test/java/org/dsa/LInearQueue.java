package org.dsa;

import org.openqa.selenium.remote.RemoteWebDriver;

public class LInearQueue {
    int FRONT = -1;
    int REAR = -1;
    int[] nums ;
    int size;
        LInearQueue(int size){
            this.size = size;
            this.nums = new int[size];
    }
    public void enQueue(int num){
            if(ifFull()){
                System.err.println("Queue is full");
            }else {
                if(FRONT == -1)
                    FRONT = 0;
                REAR++;
                nums[REAR] = num;
            }

    }
    public int deQueue(){
            int ele ;
            if(isEmpty()){
                System.err.println("Queue is empty");
            }else{
                ele = nums[FRONT];
                if(FRONT >= REAR){
                    FRONT = -1;
                    REAR = -1;
                }else{
                    FRONT++;
                }
                return ele;
            }

            return -1;

    }

    public boolean ifFull(){
            if(FRONT == 0 &&  size == REAR - 1)
                return true;
            else
                return false;

    }

    public boolean isEmpty(){
            if( FRONT == -1)
                return  true;
            else
                return false;
    }
}
