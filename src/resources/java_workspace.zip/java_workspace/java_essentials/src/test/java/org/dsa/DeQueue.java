package org.dsa;

import lombok.SneakyThrows;

public class DeQueue {

    private int size;
    int front = -1;
    int rear = 0;
    int arr[];

    DeQueue(int size){
        this.size = size;
        this.arr = new int[this.size];
    }

    public boolean isEmpty(){
        if(this.arr.length == 0){
            front = -1;
            rear = 0;
            return true;
        }
        return false;
    }

    public boolean isFull(){
        if(this.arr.length == this.size)
            return false;
        else
            return true;
    }
    @SneakyThrows
    public void insertAtFront(int num){
        //check array is full
        if(isFull())
            throw new Exception("Given array is full");
        if(front < 1) {
            front = this.size - 1;
            arr[front] = num;
        }else {
            front = front -1;
            arr[front] = num;
        }

    }

    @SneakyThrows
    public  void  insertRear(int num){
        if(isFull()) {
           this.rear = 0;
            throw new Exception("Given array is full");
        }else{
            rear = rear +  1;
            arr[rear] = num;
        }

    }

    @SneakyThrows
    public void deleteFront(){

        if(isEmpty()) {
            System.out.println("Is the arr empty");
            front = -1;
            rear = 0;
        }else{

        }

    }


}
