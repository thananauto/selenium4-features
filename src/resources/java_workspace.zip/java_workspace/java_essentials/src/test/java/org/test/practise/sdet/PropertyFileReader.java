package org.test.practise.sdet;

import org.aeonbits.owner.ConfigFactory;
import org.junit.Test;
import org.test.practise.config.ConfigReader;

public class PropertyFileReader {

    @Test
    public void readPropertyFile(){
        ConfigReader propertyReader = ConfigFactory.create(ConfigReader.class);
        System.out.println(propertyReader.browserName());
        propertyReader.message().forEach(System.out::println);
        System.out.println(propertyReader.helloMsg());
        System.out.println(propertyReader.teaMsg());
    }


}
