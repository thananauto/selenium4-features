package org.java7;

public abstract class Lorry {

    public void testTyre(){
        System.out.println("Four tyre");
    }
}
