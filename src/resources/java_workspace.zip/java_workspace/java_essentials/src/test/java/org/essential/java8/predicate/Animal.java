package org.essential.java8.predicate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
public class Animal {
    private String name;
    private String sex;

    public String toString(){
        return "Name: "+this.name+" Sex: "+this.sex;
    }

}
