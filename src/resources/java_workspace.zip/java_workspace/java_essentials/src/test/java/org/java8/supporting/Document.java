package org.java8.supporting;

public class Document implements Printable{


    @Override
    public Object print(Object o, Object o2) {
        return null;
    }
}
