package org.abs.java8.training;

import lombok.Getter;

import java.util.Objects;

@Getter
public class Organisation {

    private String name;
    private int year;
    private String address;
    private int employeecount;

    private static Organisation org = null;
    public Organisation setName(String name) {
        this.name = name;
        return this;
    }

    public Organisation setYear(int year) {
        this.year = year;
        return this;
    }

    public Organisation setAddress(String address) {
        this.address = address;
        return this;
    }

    public Organisation setEmployeecount(int employeecount) {
        this.employeecount = employeecount;
        return this;
    }




    public static Organisation builder(){
        return Objects.isNull(org) ? new Organisation() : org;
    }

    public Organisation build(){
        return this;
    }

}
