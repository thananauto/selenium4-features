package org.java8;

import java.util.function.Consumer;

public class PersonBuilder {
    public String fname;
    public String lname;
    public  int age;
    public double salary;

    public PersonBuilder builder(Consumer<PersonBuilder> personBuilder){
        personBuilder.accept(this);
        return this;
    }

    public Person build(){
        return new Person(fname, lname, age, salary);
    }
}
