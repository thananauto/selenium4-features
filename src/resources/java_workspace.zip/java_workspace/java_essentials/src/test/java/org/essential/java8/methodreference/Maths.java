package org.essential.java8.methodreference;

public class Maths {

    public static Integer addition(int a, int b){
        return a+b;
    }
    public static Integer subtraction(int a, int b){
        return a-b;
    }
    public static Integer multiplication(int a, int b){
        return a*b;
    }
    public static Integer division(int a){
        return a/10;
    }
}
