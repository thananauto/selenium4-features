package org.abs.java8.training;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


@Getter
public class Pupil  implements  Comparable<Pupil>{

    private String name;

    @Override
    public String toString() {
        return "Pupil{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", standard=" + standard +
                ", gender='" + gender + '\'' +
                ", place='" + place + '\'' +
                '}';
    }

    private int age;
    private int standard;
    private String gender;
    @Setter
    private String place;

    public Pupil(String name, int age, int standard, String gender) {
        this.name = name;
        this.age = age;
        this.standard = standard;
        this.gender = gender;
    }



    @Override
    public int compareTo( Pupil pupil) {
        return this.age - pupil.getAge();
    }

}
