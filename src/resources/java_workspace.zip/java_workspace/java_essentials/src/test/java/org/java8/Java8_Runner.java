package org.java8;

import org.java8.supporting.Animal;
import org.java8.supporting.Document;
import org.java8.supporting.Dog;
import org.java8.supporting.Printable;
import org.junit.Test;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Java8_Runner {

    public void apply1(Animal animal){
        animal.run();
    }

    @Test
    public void test_method_behaviour(){
        Animal dog = new Dog();
        apply1(dog);
        apply1(() -> System.out.println("Running at 10 mph"));
        stringCount((e) -> System.out.println(e.length()), "Thanan");
        stringCount((e) -> System.out.println(e.toLowerCase(Locale.ROOT)), "Thanan");
        stringCount((e) -> System.out.println(e.toUpperCase(Locale.ROOT)), "Thanan");
    }

    public void stringCount(Consumer<String> cons, String var){
        cons.accept(var);

    }


    public void test(){

        //Conventional way of using the interface
        Document document = new Document();
        document.print("name", "first");


        //Using Java8 fucntional interface
        Printable<String, Integer, String> printable = ( name,  last) -> name+" "+last;
        printable.print("name", 1);
    }


    //consumer interface
    @Test
    public void consumer_Inteface(){

        List<String> lstNames = Arrays.asList("Kumar", "vicky", "Mathew");
        List<String> ele = new ArrayList<>();

        Consumer<String> printOut = (e) -> System.out.println(e);
        Consumer<String> upperCase = (e) -> System.out.println(e.toUpperCase());
        Consumer<String> addElement = (e) -> ele.add(e);

        lstNames.forEach(upperCase.andThen(addElement));
        System.out.println(ele.size());
    }


    @Test
    public void bi_consumer(){

        Map<String, String> mapNames = new HashMap<>();
        mapNames.put("thanan", "jayan");
        mapNames.put("mani", "kandan");
        mapNames.put("ruthran", "thanan");

        mapNames.forEach((k, v) -> System.out.println(k+" ---------> "+v));
       // ConsumerClass<Map<Object, Object>> uc = text -> text.get();
        Consumer<Map<String, String>> fname = Utility::updateData;
        Consumer<Map<String, String>> display = Utility::displayData;
        //fname.accept(mapNames);
        //display.accept(mapNames);
        fname.andThen(display).accept(mapNames);

    }

    @Test
    public void supplier_interface(){

        Supplier<?> message = () -> "Common error message";
    }

    @Test
    public void person_consumer(){

       Person person =  new PersonBuilder()
                .builder(personBuilder -> {
                    personBuilder.fname = "Thanan";
                    personBuilder.lname ="Jayab";
                    personBuilder.age = 32;
                    personBuilder.salary = 25000.00;
                }).build();

        System.out.println(person.getFname());
        System.out.println(person.getLname());
    }

}
class Utility {
    static void updateData(Map<String, String> persons) {
        persons.replaceAll((k, v) -> "Shree ".concat(v));
    }

    static void displayData(Map<String, String> persons) {
        persons.forEach((k,v) -> System.out.println(k+" --- "+v));
    }
}
