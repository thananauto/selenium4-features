package org.builder.pattern;

import com.github.javafaker.Faker;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.builder.pattern.request.Employee;
import org.junit.Assert;
import org.junit.Test;

public class BuilderDesignPattern {



    @Test
    public void test_employees(){
        RestAssured.baseURI = "http://localhost:3000";

        Employee employee = new Employee("Thanan", "Jayan", 23, getFakeId(), "Chennai");

        Response response = RestAssured.given()
                .body(employee)
                .log()
                .all()
                .contentType(ContentType.JSON)
                .post("/employees")
                .prettyPeek();

        Assert.assertEquals(response.getStatusCode(), 201);

    }

    private String getFakeId(){
        return String.valueOf(new Faker().number().digits(3));
    }
}
