package org.essential.java8.function;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor

public class Temparature {
    private String cityName;
    private Double deg;
    private Double fahr;


    @Override
    public String toString() {
        return "Temparature{" +
                "cityName='" + cityName + '\'' +
                ", deg=" + deg +
                ", fahr=" + fahr +
                '}';
    }
}
