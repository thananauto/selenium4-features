package org.java8.supporting;

@FunctionalInterface
public interface Printable<T, U, R> {

     public R  print(T t, U u);

}
