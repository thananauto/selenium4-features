package org.essential.java8.methodreference;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MethodReference {

    @Test
    public void method_test(){
        List<Integer> numbers = Arrays.asList(1,5,6,7);

        //with function interface declaration
        Stream<Object> m=numbers.stream().map(new Function<Integer, Integer>() {
            @Override
            public Integer apply(Integer integer) {
                return Maths.addition(integer, 4);
            }
        });
        System.out.println(m.collect(Collectors.toList()));
        //with lambda expression
        List<Integer> op1 = numbers.stream().map(e -> Maths.addition(e, 8)).collect(Collectors.toList());
        System.out.println(op1);


        //static method reference
        //array to array
        List<Integer> op2 = numbers.stream().map(Maths::division).collect(Collectors.toList());
        System.out.println(op2);

    }

    @Test
    public void array_to_map(){
        //array to map
        ArrayList<String> fruits = new ArrayList<>();
        fruits.add("Banana");
        fruits.add("Guava");
        fruits.add("Pineapple");
        fruits.add("Apple");

        Map<String, Integer> map =fruits.stream().collect(Collectors.toMap(e-> e, String::length));
        System.out.println(map);

        //map to modified map
        Function<String, String> addNumbers = k-> k+" Tested";
        Map<String, Integer> map1= map.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, e->e.getValue()+30));
        System.out.println(map1);
    }

}
