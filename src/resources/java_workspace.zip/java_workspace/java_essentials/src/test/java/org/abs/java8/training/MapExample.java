package org.abs.java8.training;

import org.junit.Test;

public class MapExample {
    int[] numbers = {5,7,8, 5,9,12,4,6};

    @Test
    public void testToMap(){

    }
}
