package org.coding;

import org.checkerframework.checker.units.qual.A;
import org.junit.Test;

import java.math.BigInteger;
import java.util.*;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.IntPredicate;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.Stream;

public class Easy {




    @Test
    public void testLearn(){
        String ip = "My name is Thanan";
    }

    @Test
    public void listPattern(){
        Integer[] lst = {1,2,3,4};
        //-> [24,12,8,6]

        Stream.of(lst)
                .map(e->Arrays.stream(lst).reduce(1, (c1, c2)->c1 * c2)/e)
                .forEach(System.out::println);
    }

    @Test
    public void findNearSqrNum(){
        int num = 47;

        System.out.println(Math.ceil(Math.sqrt(num)));
    }

    @Test
    public void delRepItemInArr(){
        Integer[] arr={37, 32, 97, 37, 37, 32, 62, 35, 76, 62};
       Set ls = new HashSet<>(Arrays.asList(arr));
        System.out.println(ls);

    }

    @Test
    public void firstNonRepCharacter(){
        String name = "ananjayan";

        String op = Arrays.stream(name.split(""))
                .filter(e-> name.indexOf(e)==name.lastIndexOf(e))
                .findFirst().get();
        System.out.println(op);
    }

    @Test
    public void moveZerosAndOnes(){
        Integer[] arr = { 0,2,0,3,4};
        Collections.sort(Arrays.asList(arr),(o1, o2) -> o2.compareTo(o1));
        Arrays.stream(arr).forEach(System.out::println);
       List<Integer> lst =  List.of(arr);
       lst.stream().sorted((c1, c2)-> c2.compareTo(c1)).forEach(System.out::println);
    }

    @Test
    public  void separateNumber(){
        String ip = "abc38gh89";
        String[] ipArr = ip.split("");
        String op = Arrays.stream(ipArr)
                .filter(s-> Character.isDigit(s.charAt(0)))
                .collect(Collectors.joining(""));
        System.out.println(op);
    }

    @Test
    public void reverseAlphaCharacter(){
        String ip ="34otua35aq@teds?25raey";
        char[] chars = ip.toCharArray();
        StringBuilder op = new StringBuilder();
        String temp = "";
       for(int i=0; i<chars.length; i++){
           if(Character.isLetter(chars[i])){
               temp = chars[i] + temp;
           }else if(!Character.isLetter(chars[i]) ){
               op.append(temp+chars[i]);
               temp ="";
                continue;
           }
           op.append(temp);
       }
        System.out.println(op.append(temp));
    }


    @Test
    public void codeToFindNextGreaterNum(){
        Integer[] arr= { 4 , 5 , 2 , 25 };

        Function<Integer, Integer> findNext = (arrNum)->{
            int temp = 0;
            for (Integer integer : arr) {
                if (Objects.equals(integer, arrNum)) {
                    temp = integer;
                } else if (temp != 0) {
                    if (temp < integer)
                        return integer;
                }
            }
            return -1;
        };
        Arrays.stream(arr).map(findNext).forEach(System.out::println);
    }


    @Test
    public void textNumber(){
       // Input: aaabbbacfwww
       // Output: a3b3acfw3
        String ip = "aaabbbacfwww";
        String copy = ip;
        int index = 0;
        String op = "";
        int count = 0;
       while(ip.length()>0){
           char c = copy.charAt(index);
           index++;
           ip = ip.substring(index);

           if(ip.startsWith(String.valueOf(c))){
               count++;
               continue;
           }
           op = String.valueOf(c)+count;
       }
    }

    @Test
    public void findOddOrEvenOut(){
        int[] integers = {2, 4, 0, 100, 4, 11, 2602, 36};


        List<Integer> los =Arrays.stream(integers)
                .filter(e ->! (e % 2 == 0))
                .boxed().toList();
       int op=  los.size() == 1 ? los.get(0) :  Arrays.stream(integers)
                .filter(e ->e % 2 == 0)
                .boxed().toList().get(0);
        System.out.println(op);


    }

    @Test
    public void testMexicanWave()
    {
        String ip = "Two words";
        Function<Integer, String> mapped = i ->{
            String op = ""+ip.charAt(i);
            if(op.matches("[^\\d\\w]"))
                return "dummy";
            else
                 return ip.substring(0,i)+op.toUpperCase()+ip.substring(i+1);

        };





       List<String> p = IntStream.range(0, ip.length())
                .boxed()
                .map(mapped)
               .filter(e->!e.equals("dummy"))
                .collect(Collectors.toList());
      //  p.forEach(System.out::println);

       // String[] o = p.toArray(new String[0]);

        IntFunction< String> lot = x -> {
            return  new StringBuilder(ip).replace(x, x+1, String.valueOf(ip.charAt(x)).toUpperCase()).toString();};
        IntStream
                .range(0, ip.length())

                .mapToObj(lot)
                .filter(x -> !x.equals(ip))
                .map(String::valueOf)
                .forEach(System.out::println);
               // .toArray(String[]::new);
    }

    @Test
    public void reverseString(){
        String ip = "Hello world";
        String[] arrIp = ip.split(" ");
        String op= "";
        for(String eachArr : arrIp){
            char[] charArr = eachArr.toCharArray();

            for(int i = charArr.length -1; i>=0; i--){
                op=op+charArr[i];
            }
            op=op+" ";
        }
        System.out.println(op);
        //using string builder
        StringBuilder sb = new StringBuilder(op);
        sb.reverse();
        System.out.println(sb);

       String op1 = Arrays.stream(ip.split(" "))
               .reduce(" ",(c,d)->d+c) ;
        System.out.println(op1);

    }

    @Test
    public void findLargestNumber(){
        int[] arr = { 2,7,1,5,0,3};
        int op = arr[0];
        for(int i = 1; i< arr.length; i++){
            if(op < arr[i]){
                op = arr[i];
            }
        }
        System.out.println(op);
        //using stream with comparator
        Comparator<Integer> comp = (c1, c2) -> c1.compareTo(c2);
       Integer lst= Arrays.stream(arr)
               .boxed()
               .max(comp).get();
        System.out.println(lst);

        //using stream max method
        Integer lst1 = Arrays.stream(arr)
                .max().getAsInt();
        System.out.println(lst1);

        //using stream with reduce function
        Integer lst2 = Arrays.stream(arr)
                .reduce(0,(c1,c2)-> Math.max(c1, c2));

        System.out.println(lst2);

    }

    @Test
    public void checkPalindrome(){
        String ip = "Malayalam";
        String[] arrIp = ip.toLowerCase(Locale.ROOT).split("");

        boolean flg = true;
        for(int i=0; i< arrIp.length;i++){
            if(!Objects.equals(arrIp[i], arrIp[(arrIp.length - 1) - i])){
              flg= false;
                break;
            }
        }
        if(flg)
            System.out.println(ip+ " is palindrome");
        else
            System.out.println(ip+ " is not palindrome");

        IntPredicate pred = (i)-> arrIp[i].equals(arrIp[(arrIp.length-1)-i]);
        //using stream
        boolean flag = IntStream.range(0, arrIp.length)
                .allMatch(pred);
        System.out.println(flag);
    }

    @Test
    public void factorial(){

        int n = 4;
        int op =1;
        while(n>1){
            op = n*op;
            n = n-1;
        }
        System.out.println(op);
        //using java stream
        int lop = IntStream.rangeClosed(1, n)
                .reduce(1, (n1, n2)-> n1*n2);
        System.out.println(lop);

    }
    @Test
    public void largestNum(){
        int[] nums = {8,9,4,2,5,1};




       int s = Arrays.stream(nums).reduce(0,(c1,c2)-> Math.max(c2, c1));
        System.out.println(s);


    }

    @Test
    public void testFibonacciSeries(){
        int range = 9;
        List<Integer> lstOp = new ArrayList<>();
        lstOp.add(0);
        lstOp.add(1);
        while(0 <= (range-1) -2 ){
                int num = lstOp.get(lstOp.size()-2) + lstOp.get(lstOp.size()-1);
                lstOp.add(num);
            range --;
        }
        System.out.println(lstOp);

        Stream.iterate(new int[]{0, 1}, t->new int[]{t[1], t[0]+t[1]})
              .limit(10)
              .map(t->t[0])
              .mapToInt(Integer::intValue)
              .sum();

    }

    @Test
    public void testPrimeNumberRange(){
        Predicate<Integer> num = n -> {

            if(n<=1){
                return false;
            }else{
                for(int i=2; i<= Math.sqrt(n); i++){
                    if(n % i==0){
                        return false;
                    }
                }
            }
            return true;
            };

        Stream.iterate(1, n->n+1).limit(25)
                .filter(num)
                .collect(Collectors.toList())
                .forEach(System.out::println);
    }

    @Test
    public void testStringAnaghram(){
        String input1 = "Tac".toLowerCase();
        String input2 = "Trc".toLowerCase();

        if(input1.length() != input2.length())
            System.out.println("Both are not anaghram");

        List<String> ip1 = new ArrayList<>(Arrays.asList(input1.split("")));
        List<String> ip2 = new ArrayList<>(Arrays.asList(input2.split("")));

        ip1.forEach(e->{
            ip2.remove(e);
        });


        if(ip2.size() == 0)
            System.out.println("Both "+input1+" and "+input2+" are anaghram");
        else
            System.out.println("Both "+input1+" and "+input2+" are not anaghram");
    }

    @Test
    public void testDuplicate(){
        char[] character = {'a', 'b', 'a', 'c'};

       Arrays.stream(String.valueOf(character).split(""))
               .collect(Collectors.groupingBy(e->e,Collectors.joining("")))

                 .entrySet()
                .stream()
                .filter(e-> e.getValue().length() >1)
                // .map(Map.Entry::getKey)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue))
                .forEach((k,v)-> System.out.println(k+"-->"+v));
    }

    @Test
    public void stringIncrementer(){
        String ip ="321931313513914341504071111018";

        Pattern pattern = Pattern.compile("[0-9]+$");
        Matcher matcher = pattern.matcher(ip);
        if(matcher.find()) {
            String val = matcher.group();
            BigInteger number1 = new BigInteger(val);
            BigInteger  sum =number1.add(new BigInteger("1"));
            String op1 = String.format("%0"+val.length()+"d", sum);
            ip = ip.replaceAll("[0-9]+$","") + op1;

        }else {
            ip = ip + 1;
        }
        System.out.println(ip);


    }

    @Test
    public void raiseToPowAndSum(){

        Predicate<Long> predicate = n->{
            long org = n;
            int len = String.valueOf(n).length();
            long sum =0;
            while(n>0){
               long rem = n%10;
               sum+=Math.pow(rem, len);
               n=n/10;
               len--;
            }
            return (org==sum);
        };

       List<Long> lst= LongStream.range(1, 100)
                .boxed()
                .filter(predicate)

                .collect(Collectors.toList());
        }
}
