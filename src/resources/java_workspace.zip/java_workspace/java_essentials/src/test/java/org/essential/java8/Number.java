package org.essential.java8;

public interface Number {
    int func(int n);
}


