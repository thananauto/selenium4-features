package org.dsa;

public class CircularQueue
{

    int FRONT = -1;
    int REAR = -1;
    int size ;
    char[] chars;
    CircularQueue(int size){
        this.size = size;
        this.chars = new char[this.size];

    }

    public void enQueue(char c) throws Exception {
        //check if the queue is full
        if(isFull()){
            throw new Exception("Queue is full");
        }else{
            if(FRONT == -1)
                FRONT = 0;

            REAR = (REAR + 1) % size;
            chars[REAR] = c;
        }
    }

    void display() {
        /* Function to display status of Circular Queue */
        int i;
        if (isEmpty()) {
            System.out.println("Empty Queue");
        } else {
            System.out.println("Front -> " + FRONT);
            System.out.println("Items -> ");
            for (i = FRONT; i != REAR; i = (i + 1) % size)
                System.out.print(chars[i] + " ");
            System.out.println(chars[i]);
            System.out.println("Rear -> " + REAR);
        }
    }

    public int deQueue(){
        int ele;
        //check if the queue is empty
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return (-1);
        }else {
             ele = chars[FRONT];
             if( FRONT == REAR){
                 FRONT = -1;
                 REAR = -1;
             }else {
                 FRONT = (FRONT + 1) % size;
             }
            return ele;
        }
    }
    boolean isEmpty() {
        if (FRONT == -1)
            return true;
        else
            return false;
    }

    public boolean isFull(){
        if (FRONT == 0 && REAR == size - 1) {
            return true;
        }
        if (FRONT == REAR + 1) {
            return true;
        }
        return false;
    }


}
