package org.testng;

import java.util.Scanner;

public class Solution {
    static boolean flag;
    static int B;
    static int H;

    static {
        System.out.println("In the static block");
        try {
           int i = 0;
            int j = 10/i;
        } catch(Exception e){
            System.out.println("Exception while initializing" + e.getMessage());
            throw new RuntimeException(e.getMessage());
        }
    }
}
