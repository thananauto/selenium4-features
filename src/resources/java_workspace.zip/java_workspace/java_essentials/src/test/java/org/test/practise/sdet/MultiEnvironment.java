package org.test.practise.sdet;

import org.aeonbits.owner.ConfigFactory;
import org.junit.Before;
import org.junit.Test;
import org.test.practise.config.MultiEnvConfig;

public class MultiEnvironment {

    @Before
    public void setUp(){
        multiEnvConfig =ConfigFactory.create(MultiEnvConfig.class);


    }
    MultiEnvConfig multiEnvConfig;
    @Test
    public void getEnvVariables(){

        System.out.println(multiEnvConfig.browser());
        System.out.println(multiEnvConfig.dbUserName());
        System.out.println(multiEnvConfig.dbPassword());
        System.out.println("TestGen"+multiEnvConfig.testCycle()+"check");
        if(multiEnvConfig.tester()){
            System.out.println("passed");
        }else {
            System.out.println("failed");
        }
    }
}
