package org.essential.java8.function;

import org.junit.Test;

import java.util.function.Function;

public class FunctionInterface {

    @Test
    public void function_test(){
        Function<Temparature, Temparature> city_temp = t -> {t.setDeg(10.0);
                                                        return t;};
        Function<Temparature, Temparature> deg_temp = t -> {t.setDeg(20.0);
            return t;};

        Function<Temparature, Temparature> cel_temp = t -> {t.setDeg(30.0);
            return t;};

        Temparature temp = new Temparature();
        city_temp.compose(cel_temp).andThen(deg_temp).apply(temp);

        System.out.println(temp);

    }
}
