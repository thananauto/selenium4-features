package org.abs.java8.training;

import java.util.Optional;
import java.util.function.Function;

public class Client {

    private String name;
    private Optional<Truck> truck;

    public Client(String name, Truck truck){
        this.name = name;
        this.truck = Optional.ofNullable(truck);
    }

    public Optional<Truck> getTruck(){
        return this.truck;
    }

    public String getClientName(){
        return this.name;
    }

    public String getInsuranceDetails(Client client){

       /* Optional<Client> clent = Optional.ofNullable(client);
                clent.map(c-> c.getTruck().get())
                        .map(t-> t.getInsurance().get())
                        .map(Insurance::getInsuranceName)
                        .orElse("There is some error");*/
        Optional<Client> clent1 = Optional.ofNullable(client);
       return clent1.flatMap(Client::getTruck)
                .flatMap(Truck::getInsurance)
                .map(Insurance::getInsuranceName)
                .orElse("There is some error");

    }

}

class Truck {

    private String name ;
    private Optional<Insurance> insurance;
    public Truck(String name, Insurance insurance){
        this.name = name;
        this.insurance = Optional.ofNullable(insurance);

    }

    public Optional<Insurance> getInsurance(){
        return  this.insurance;
    }

    public String getCarName(){
        return  this.name;
    }

}
class Insurance {
    private String name;

    public  Insurance(String name){
        this.name = name;
    }

    public String getInsuranceName(){
        return this.name;
    }
}
