package org.test.practise.sdet;

import org.junit.Test;

import org.test.practise.blocks.Audi;
import org.test.practise.blocks.Car;

public class StaticVsInstanceBlock {

    @Test
    public void normalClass(){
        Car car = new Car();
    }

    @Test
    public void inAndAsClass(){
        Audi audi = new Audi();
    }
}
