package org.test.practise.anonymousclass;

import org.junit.Test;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ListToMap {


    @Test
    public void test(){
        String params = "LOANNUMBEZ=2323432&asdas=8868";
        List<String> lstParams = new ArrayList<>(Arrays.asList(params.split("&")));
        Map<String, String> map = lstParams.stream()
                .collect(Collectors.toMap(par -> par.split("=")[0], par -> par.split("=")[1] ));
        System.out.println(map);
    }

    @Test
    public void testMap(){

        BiFunction<String, String, String> biFunc = (x, y) -> y== null || y.equals("null") ? "" : y.replace("\"","");
        Map<String, String> data = new HashMap<String, String>();
        data.put("a", "1");
        data.put("b", null);
        data.put("c", "null");
        data.put("\"d\"","\"3\"");
        data.put("\"e\"","\"\"");

        System.out.println(data);

        for(String key: data.keySet()){
            data.compute(key, (k,v) -> biFunc.apply(k,v));

        }

        Map<String, String> lstMap = new HashMap<>();

        for(String key: data.keySet()){
             key = key.replaceAll("\"", "");
            String op= data.get(key);
            data.putIfAbsent(key, op);
           // data.remove(key);
        }
        System.out.println(data);
    }

}
