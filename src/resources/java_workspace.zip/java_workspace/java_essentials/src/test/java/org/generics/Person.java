package org.generics;

public class Person implements Comparable<Person>{


    public static void main(String[] args) {
        Pupil pupil = Pupil.valueOf("AGE");
        System.out.println(pupil);
    }

    @Override
    public int compareTo(Person o) {
        return 0;
    }
}

 enum Pupil{

    NAME("get the name"),
    AGE("get the age");

     private final String desc;
     Pupil(String desc) {
         this.desc = desc;
     }
 }
