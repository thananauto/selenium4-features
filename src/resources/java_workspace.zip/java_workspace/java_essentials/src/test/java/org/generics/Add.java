package org.generics;

public interface Add <T, U, R>{
    void set(T a1, U a2);
    R add();

}
