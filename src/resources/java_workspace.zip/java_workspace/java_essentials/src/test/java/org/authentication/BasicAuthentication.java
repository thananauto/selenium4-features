package org.authentication;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class BasicAuthentication {
private WebDriver driver;
    @Test
    public void testBasicAuth(){
        driver = new ChromeDriver();

        HasAuthentication authentication = (HasAuthentication) driver;
        authentication.register(() -> new UsernameAndPassword("admin", "admin"));

        driver.get("https://the-internet.herokuapp.com/basic_auth");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.linkText("Elemental Selenium")));
        driver.findElement(By.linkText("Elemental Selenium")).click();
    }

    @AfterMethod
    public void tearDown(){
        driver.quit();
    }
}
