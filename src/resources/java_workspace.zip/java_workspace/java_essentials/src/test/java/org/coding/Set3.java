package org.coding;

import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Locale;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Set3 {

    @Test
    public void convertList(){
        int[] ip ={1, 4, 3, 6, 8 };
        Arrays.stream(ip).boxed()
                .map(e-> e%2==0 ? e*e : e)
                .forEach(System.out::println);
        System.out.println(Math.sqrt(4)%1);
    }

    @Test
    public void getSqRtNumber(){
        int[] ip ={1, 4, 3, 16, 25, 26, 36 };
        Arrays.stream(ip).boxed()
                .filter(e-> Math.sqrt(e)% 1 !=0.0 )
                .forEach(System.out::println);
    }


    @Test
    public void replaceEachElement(){
        int[] ip ={1, 2, 3,4 };
        IntStream.range(0, ip.length)
                .boxed()
                .map(i -> Arrays.stream(ip)
                        .boxed().reduce(1, (a, b) -> a*b) / ip[i])
                .forEach(System.out::println);
    }

    @Test
    public void camelCase(){
        String str = "cats AND*Dogs-are Awesome";
        String[] words = str.split("[^a-zA-Z0-9]+");
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            String word = words[i];

            // Convert to lowercase and capitalize the first letter of each word (except the first word)
            if (i == 0) {
                result.append(word.toLowerCase());
            } else {
                String each = words[i].charAt(0)+"".toUpperCase();
                result.append(Character.toUpperCase(word.charAt(0)))
                        .append(word.substring(1).toLowerCase());
            }
        }

        System.out.println(result.toString());
    }
}
