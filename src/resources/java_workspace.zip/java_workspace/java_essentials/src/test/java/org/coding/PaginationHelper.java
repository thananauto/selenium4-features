package org.coding;


import org.apache.groovy.json.internal.Chr;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class PaginationHelper{
    public static void main(String[] args) {
        Helper<Character> helper = new Helper(Arrays.asList('a', 'b', 'c', 'd', 'e', 'f'), 4);
        System.out.println(helper.pageCount());
        System.out.println(helper.pageItemCount(3));
        System.out.println(helper.pageIndex(5));
    }

}

 class Helper<Character> {
    private  int itemsPerPage;
    private List<Character> collection;

    public Helper(List<Character> collection, int itemsPerPage) {
        this.collection = collection;
        this.itemsPerPage = itemsPerPage;
    }

    /**
     * returns the number of items within the entire collection
     */
    public int itemCount() {
        return collection.size();
    }

    /**
     * returns the number of pages
     */
    public int pageCount() {
        return (int)Math.ceil((double) collection.size()/(double) itemsPerPage) ;
    }


    /**
     * returns the number of items on the current page. page_index is zero based.
     * this method should return -1 for pageIndex values that are out of range
     */
    public int pageItemCount(int pageIndex) {

        //items in 2
        int productSize = collection.size();
        int q = productSize/4;
        int r = productSize % 4;
          if((pageIndex+1)<=q)
              return itemsPerPage;
          else if((pageIndex+1)<=q+1)
              return r;
          else
              return -1;



    }

    /**
     * determines what page an item is on. Zero based indexes
     * this method should return -1 for itemIndex values that are out of range
     */
    public int pageIndex(int itemIndex) {

        if((itemIndex+1) > itemCount())
            return -1;

        int page = (int)Math.ceil((double) itemIndex /(double) itemsPerPage);

        int count = 0;

        if(collection.size() < itemIndex)
            return -1;
        for(int i=0; i<=itemIndex; i++){
            if(i % itemsPerPage ==0){
                count ++;
            }
        }
        return count;
    }
}
