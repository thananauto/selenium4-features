package org.essential.java8.consumer;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Setter
@Getter
public class MathConsumer {
    private int a;
    private int b;

    public int addition(){
        return  this.a + this.b;
    }
    public int subractio(){
        return  this.a - this.b;
    }
    public int multiplication(){
        return  this.a * this.b;
    }

}
