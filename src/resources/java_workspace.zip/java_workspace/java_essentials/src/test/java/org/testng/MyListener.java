package org.testng;

import java.util.Date;
import java.util.HashMap;

public class MyListener implements ITestListener{

    private static HashMap<String, Integer> mapOut = new HashMap<>();

    @Override
    public void onTestStart(ITestResult iTestResult) {

    }

    @Override
    public void onTestSuccess(ITestResult iTestResult) {
        mapOut.put("PASSED", mapOut.get("PASSED")+1);

    }

    @Override
    public void onTestFailure(ITestResult iTestResult) {
        mapOut.put("FAILED", mapOut.get("FAILED")+1);
    }

    @Override
    public void onTestSkipped(ITestResult iTestResult) {
        mapOut.put("SKIPPED", mapOut.get("SKIPPED")+1);
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {

    }

    @Override
    public void onStart(ITestContext iTestContext) {
        mapOut.put("PASSED", 0);
        mapOut.put("FAILED", 0);
        mapOut.put("SKIPPED", 0);


    }

    @Override
    public void onFinish(ITestContext iTestContext) {
        mapOut.forEach((k,v) ->System.out.println(k+" : "+ v));

    }
}
