package org.abs.java8.training;

import org.junit.Test;

import java.io.File;
import java.io.FileFilter;
import java.util.Arrays;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class ThreadRunnable {

    @Test
    public void test(){

        Thread t1 = new Thread(() -> {for(int i =0 ; i<3; i++) System.out.println("Running the thread "+i);}, "Thread 1");
        t1.start();
        t1.getName();

    }

    @Test
    public void hiddendFiles(){
        File[] files = new File("C:\\Users\\thananjayan.r\\Desktop")
                .listFiles(File::isFile);

        Consumer<File> consFile = e -> System.out.println(e.getName());

       BiConsumer<Integer, Integer> sum = (a, b) ->{ System.out.println(a+b);};
        assert files != null;
        Arrays.stream(files).forEach(consFile);
    }
}

@FunctionalInterface
interface Parent {

    void hasGrandChild();
}

@FunctionalInterface
interface  Child extends Parent{
    void hasGrandChild();
}

