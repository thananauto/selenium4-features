package org.leetcode;

import org.essential.java8.Number;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Predicate;

public class Simple {
    public int[] twoSum(int[] nums, int target) {

        int[] output = {0,0};
        loop:
        for(int i=0; i< nums.length; i++){
            for(int j = 0; j< nums.length; j++){
                if((nums[i] + nums[j]) == target){
                    output[0] = i;
                    output[1] = j;
                    break loop;
                }
            }
        }
        return output;
    }


    @Test
    public void sortString(){
        String ip ="aBcA1bC2";
        char[] character = ip.toCharArray();
        Arrays.sort(character);
        String op ="";
        StringBuilder temp1 = new StringBuilder();
        StringBuilder temp2= new StringBuilder();
        StringBuilder temp3 = new StringBuilder();
        for (char c1 : character) {
            if (c1 >= 'A' && c1 <= 'Z')
                temp2.append(c1);
            else if (c1 >= 'a' && c1 <= 'z')
                temp1.append(c1);
            else
                temp3.append(c1);
        }
        System.out.println(temp1.toString() +temp2+temp3);
    }

    @Test
    public void addSum(){
       int[] nums = {2,4,11,3};
       int target = 6;
       int[] output = twoSum(nums, target);
        Arrays.asList(output).stream().forEach(System.out::println);
    }

    @Test
    public void palindrome(){
        int x = 121;
        StringBuilder output = new StringBuilder();
        int y =x;
        while(x>=1){

            output.append(x % 10);
            x= x/10;
        }

        if(y == Integer.parseInt(output.toString()))
            System.out.println("True");
        else
            System.out.println("False");

    }

    @Test
    public  void removeDuplicates(){
        int[] nums = {0,1,2,2,3,0,4,2};
        int val = 2;
        int index = 0;
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != val) {
                nums[index] = nums[i];
                index++;
            }
        }


    }
    public class ListNode {
      int val;
      ListNode next;
      ListNode() {}
      ListNode(int val) { this.val = val; }
      ListNode(int val, ListNode next) { this.val = val; this.next = next;}


       /*  public String toString(){
          return "Next: "+this.next+", and Val: "+this.val;
          }*/


  }

    @Test
    public void testLinkedNode(){
        ListNode listNode4 = new ListNode(4);
        ListNode listNode3 = new ListNode(3, listNode4);
        ListNode listNode2 = new ListNode(2, listNode3);
        ListNode listNode1 = new ListNode(1, listNode2);
        System.out.println(swapPairs(listNode1));


    }
    public ListNode swapPairs(ListNode head) {
        if(head == null || head.next == null) return head;
        ListNode prev = head;
        ListNode curr = head.next;
        ListNode ans = curr;
        while(true)
        {
            ListNode save = curr.next;
            if(save == null || save.next == null)
            {
                prev.next = save;
                curr.next = prev;
                break;
            }
            prev.next = save.next;
            curr.next = prev;
            prev = save;
            curr = save.next;
        }
        return ans;
    }
}
