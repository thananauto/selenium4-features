package org.java8.supporting;

@FunctionalInterface
public interface Animal {
    public void run();
}

