package org.essential.java8.consumer;

import com.google.gson.JsonObject;
import groovy.util.MapEntry;
import org.junit.Test;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ConsumerClass {

    @Test
    public void  consumer_test(){
        List<String> lstNames = Arrays.asList("Thanan", "Tishar", "Tandor", "ERabi");
        Consumer<String> conName = (x) -> System.out.println(x+" QT");
        lstNames.forEach(conName);

        List<Integer> lstNum = Arrays.asList(1,4,5,6);
        //function to multiply two numbers
        Function<Integer, Integer> mul_2 = x -> x*2;

        //consumer to invoke the function to multiply numbers
        Consumer<List<Integer>> intConsumer = lst -> {
          for(int i=0; i<lst.size(); i++){
              lst.set(i, mul_2.apply(lst.get(i)));
          }
        };

        //consumer to display the output
        Consumer<List<Integer>> displayList = lst -> lst.forEach(System.out::println);

        intConsumer.accept(lstNum);
        displayList.accept(lstNum);

        displayList.andThen(intConsumer).accept(lstNum);

    }

    @Test
    public void obj_consumer(){

        List<MathConsumer> lstMaths = Arrays.asList(new MathConsumer(1,1), new MathConsumer(2,2), new MathConsumer(3,3));

        //consumer to change the class values
        Function<MathConsumer, MathConsumer> funcMathConsumer = mathConsumer -> {
            return new MathConsumer(mathConsumer.getA()+4, mathConsumer.getB()+4);

        };
        Consumer<List<MathConsumer>> consumerMath = lst ->{
         for(int i=0; i< lst.size(); i++){
             lst.set(i, funcMathConsumer.apply(lst.get(i)));
         }

        };

        Consumer<List<MathConsumer>> displayOut = e -> e.forEach(mathConsumer -> System.out.println("A: "+mathConsumer.getA()+" B: "+mathConsumer.getB()));

        consumerMath
                .andThen(displayOut)
                .accept(lstMaths);

    }

    @Test
    public void bi_consumer(){
        Map<String, Integer> biCnsmrOp = new HashMap<>();
        BiConsumer<String, Integer > biMap = biCnsmrOp::put;

        List<String> names = Arrays.asList("Thanan", "Mani", "Tushar", "Raman");
       for(int i=0; i< names.size(); i++){
           biMap.accept(names.get(i), 0);
       }
       BiConsumer<String, Integer> biDisplay = (k, v)-> System.out.println(" Name: "+k+", Salary: "+v);
       biCnsmrOp.forEach(biDisplay);

       //add the salary for each employee
        Function<Integer, Integer> addSalary =(v)-> v+1000;
        Map<String, Integer> salary = biCnsmrOp.entrySet()
                .stream()
                .collect(Collectors.toMap(Map.Entry::getKey, k->addSalary.apply(k.getValue())));

        salary.forEach(biDisplay);


    }

    @Test
    public void addId(){
        Function<String, String> x1 = x->{

            return x.substring(0,3)+"-"+x.substring(3);
        };
        String val = "DCA4234234srwer";
        System.out.println(x1.apply(val));
    }

    @Test
    public void getStatus(){
        Map<String, JsonObject> map = new HashMap<>();
        Function<Integer, JsonObject> x = e ->{
          JsonObject obj = new JsonObject();
            obj.addProperty("id",e);
            return  obj;
        };
       map.put("DCA-123", x.apply(1));
       map.put("DCA-345", x.apply(2));
        map.put("DCA-423", x.apply(1));
        map.put("DCA-365", x.apply(2));
        map.put("DCA-223", x.apply(-1));
        map.put("DCA-2323", x.apply(-1));
        map.put("DCA-346", x.apply(2));

       long passed = map.entrySet().stream().filter(n -> n.getValue().get("id").getAsNumber().equals(1)).count();
       long failed = map.entrySet().stream().filter(n -> n.getValue().get("id").getAsNumber().equals(2)).count();
       long skipped = map.entrySet().stream().filter(n -> !n.getValue().get("id").getAsNumber().equals(2) && !n.getValue().get("id").getAsNumber().equals(1)).count();
       long total = map.entrySet().stream().count();
       List<String> ids = new ArrayList<>(map.keySet());
        System.out.println(ids);
        System.out.println("Total "+total+" Passed: "+passed+" Failed: "+failed+" Skipped: "+skipped);
    }


}
