package org.abs.java8.training;

import org.junit.Test;

import java.util.function.Function;

public class MultipleInterface {

    @Test
    public void test(){
        Person human = new Men(){


            private int age;
            private String name;

            public void setAge(int age){
                this.age = age;
            }

            public void setName(String name){
                this.name = name;
            }
            @Override
            public int age() {
                return this.age;
            }

            @Override
            public String name() {
                return this.name;
            }


            @Override
            public String sex(String sex) {
                return "Transgender";
            }
        };
        human.setAge(3);
        human.setName("Koli");


        System.out.println(human.age());
        System.out.println(human.name());
        System.out.println(human.sex("EMale"));
        System.out.println(human.isMinor());


    }

    @Test
    public void anonymous_class_as_method(){
         Audi audi = new Audi();
         audi.checkWheen(()-> System.out.println("car has four wheels"));
         Vehicle vehicle = new Vehicle() {
             @Override
             public void hasFourWheel() {
                 System.out.println("Anonymous car has four wheels");
             }
         };

         vehicle.checkSteering();
         audi.checkWheen(vehicle);

    }

    @Test
    public void test_multiple_implementation(){
        Circle circle = () -> System.out.println("Circle perimeter");
        circle.area();
        circle.perimeter();



    }

    @Test
    public void functionInterface(){
        Function<Integer, Double> conv = ruppes -> ruppes*30.3;
        System.out.println(conv.apply(98));
        System.out.println(conv.andThen(x -> x- 20).apply(10));
    }
}

class Calculate implements Circle, Rectangle{

    @Override
    public void area() {
        Circle.super.area();
    }

    @Override
    public void squaremeter() {
        System.out.println("Square meter");
    }

    @Override
    public void perimeter() {
        System.out.println("Perimeter");
    }
}


class Audi {

    public void checkWheen(Vehicle vehicle){
        vehicle.hasFourWheel();

    }
}
@FunctionalInterface
interface Vehicle {
    void hasFourWheel();
    default void  checkSteering(){
        System.out.println("car have steering");
    };
}

interface Men extends Person {
    static void getNames(){
        System.out.println("Can have all static methods");
    }
    default String sex(String sex) {
        return "Male";
    }


}
interface Women extends Person {
    default String sex(String sex) {
        return "Female";
    }

}
interface Person {
    void setAge(int age);
    void setName(String name);
    int age();
    String name();
   default  String sex(String sex){
        return  sex.equalsIgnoreCase("male") ? "Male" : "Female";
    }

    default String isMinor(){
        return age() > 18 ? "Major" : "Minor";
    }
}

interface Circle{
    default void area(){
        System.out.println("Circle area");
    }
    void perimeter();
}
interface Rectangle {
    default void area(){
        System.out.println("Rectangle area");
    }
    void squaremeter();
}
