package org.testng;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Car {

    @BeforeMethod
    public void createTestRepo(){

    }

    @Test
    public void have_brake(){
        Assert.assertEquals(0,0);
    }

    @Test
    public void have_four_wheels(){
        Assert.assertEquals(0,1);

    }
    @Test
    public void have_light(){
        String pattern = "yyyy-MM-dd";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

        String date = simpleDateFormat.format(new Date());
        String date1 = (new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS")).format(new Date());
        System.out.println(date1);

    }

}
