package org.test.practise.sdet;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

public class OptionalTest {

    @Test
    public void checkNullPointerException(){

        String text = null;
        Object name = Optional.ofNullable(text).orElseGet(this::getBrowser);
        System.out.println("name = " + name);

        Optional.ofNullable(System.getenv("browser")).ifPresent(System.out::println);
        Optional.ofNullable(System.getenv("browser")).
                ifPresent(System.out::println);
    }

    public String getBrowser(){
        return "chrome";
    }

    @Test
    public void arrTest(){
    //TODO: need to learn supplier, consumer and predicate

        List<String> arr = Arrays.asList("2,4,5,6,6,3");

      //  arr.stream().findAny().


        ;
    }
}
