package org.essential.java8.thread.lambda;

import lombok.SneakyThrows;

import java.util.Random;

public class Player {
    public static void main(String[] args) {

        String[] songs = {"Mario", "Jack", "Jennifer"};
        String[] musics = {"Pop", "classic", "Jazz"};

        SongPlayer songPlayer = new SongPlayer();
        Random random = new Random();
        Runnable songRun = () ->{
            songPlayer.playSong(songs[random.nextInt(songs.length)]);

        };
        Runnable MusicRun = () ->{
            songPlayer.playMusic(musics[random.nextInt(musics.length)]);

        };

        Thread t1 = new Thread(songRun);
        Thread t2 = new Thread(MusicRun);
        t2.start();
        t1.start();
    }

}

class SongPlayer{
    public void playSong(String songName){
        System.out.println("Started song "+songName);
    }
    public void playMusic(String musicName){
        System.out.println("Music song "+musicName);
    }
}
