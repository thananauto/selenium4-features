package org.essential.java8;

import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Lambda {
    List<Integer> lstNumbers = Arrays.asList(1, 3, 2, 8, 4, 5, 6);
    @Test
    public void test_lambda(){

        Num num =x -> System.out.println(x+x);
        lstNumbers.forEach(num::add_1);

    }

    int multi_func( Multiply multiply, Integer i){
      return  multiply.multi_2(i);
    }
    @Test
    public void multi_test(){
        System.out.println("Multiply by 1*5:"+multi_func(x -> x, 5));
        System.out.println("Multiply by 2*5:"+multi_func(x -> 2*x, 5));
        System.out.println("Multiply by 3*5:"+multi_func(x -> 3*x, 5));
        System.out.println("Multiply by 4*5:"+multi_func(x -> 4*x, 5));

    }

    @Test
    public void coll_sort(){
        Collections.sort(lstNumbers, (o1, o2)-> o1.compareTo(o2));
        lstNumbers.forEach(System.out::println);
    }



    @Test
    public void mutable_final(){
      //  Mutable mutable = new Mutable();
        //mutable.check();
        int[] local = {5};
        Num num = x -> {
            System.out.println(x+local[0]);
            local[0]++;
        };

        num.add_2(5);
        System.out.println(local[0]);
    }


    @Test
    public void lst_to_map(){
        List<String> names = Arrays.asList("Mani", "KUmar", "Velab", "Suku");

        Map<Integer, String> mapNames =
                names.stream()
                        .collect(Collectors.toMap(names::indexOf, e ->e));
        System.out.println(mapNames);
    }
}
class Mutable{

    int local = 3;
    public void check(){
        Num num = x -> {
            System.out.println(x+3);
            local++;
        };

        num.add_2(5);
    }
}

@FunctionalInterface
interface Num{
    void  add_2(int x);

    default void add_1(int x) {
        System.out.println("The number would be "+x);
    }
    default void add_3(int x) {
        System.out.println("The number would be "+x);
    }
}

 interface Multiply{

    int multi_2(int x);
 }