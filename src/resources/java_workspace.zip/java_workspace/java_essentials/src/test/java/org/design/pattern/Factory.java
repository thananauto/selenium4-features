package org.design.pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.safari.SafariDriver;

public class Factory {
    private static WebDriver driver;

    public static WebDriver getDriver(Browser browser){

        switch (browser){
            case CHROME -> new ChromeDriver();
            case EDGE -> new EdgeDriver();
            case SAFARI -> new SafariDriver();
            default -> new ChromeDriver();
        }

        return driver;
    }
}

enum Browser{

    CHROME,
    FIREFOX,
    EDGE,
    SAFARI;
}
