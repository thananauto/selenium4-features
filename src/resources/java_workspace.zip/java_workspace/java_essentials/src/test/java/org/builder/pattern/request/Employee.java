package org.builder.pattern.request;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class Employee {

    private String fname;
    private String lname;
    private int age;
    private String id;
    private String location;

}
