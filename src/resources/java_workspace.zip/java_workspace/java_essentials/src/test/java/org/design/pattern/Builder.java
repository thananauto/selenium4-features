package org.design.pattern;

public class Builder {

    PersonBuilder personBuilder = PersonBuilder.getInstance().setAge(34)
            .setName("Thanan").build();
}

class PersonBuilder {
    private String name;
    private int age;

    private PersonBuilder(BuilderClass builderClass){
        this.name = builderClass.name;
        this.age = builderClass.age;
    }

    static BuilderClass getInstance(){
        return new BuilderClass();
    }
    static class BuilderClass{
        private String name;
        private int age;

        BuilderClass setName(String name){
            this.name = name;
            return this;
        }
        BuilderClass setAge(int age){
            this.age = age;
            return this;
        }

        PersonBuilder build(){
            return new PersonBuilder(this);
        }
    }


}
