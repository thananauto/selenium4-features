package org.abs.java8.training;

import org.junit.Test;

import java.util.*;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.ToIntFunction;
import java.util.stream.Collectors;


public class Option {
    List<Pupil> lstPupil = Arrays.asList(new Pupil("Kumar", 40, 3, "Male"),
            new Pupil("Lofan", 56, 6, "Male"),
            new Pupil("Thanan", 32, 5, "Male"),
            new Pupil("Ann", 30, 3, "Female"),
            new Pupil("Linga", 27, 6, "Male"),
            new Pupil("Sugnathi", 49, 5, "Female"),
            new Pupil("Lenin", 30, 3, "Male"));

    @Test
    public void testOption(){
        Comparator<Pupil> compPupil = (pupil1, pupil2) -> pupil1.getAge() - pupil2.getAge();
        Optional<Pupil>  pup =lstPupil
                .stream()
                .max(compPupil);
        pup.ifPresent(System.out::println);

    }

    @Test
    public void testObjectOptions(){
        Insurance insurance = new Insurance("HDFC Finance");
        Truck truck = new Truck("Mahindra", insurance);
        Client client = new Client("Hemanth", null);
        System.out.println(client.getInsuranceDetails(client));

    }

    @Test
    public void testReduce(){
        //find the smallest pupil age object
       Pupil pup= lstPupil.stream()
               .reduce((pupil1, pupil2)-> pupil1.getAge() > pupil2.getAge() ? pupil1 :pupil2).get();
        System.out.println(pup);

        Pupil pup1 = lstPupil.stream()
               // .sorted((p1,p2)->p1.compareTo(p2))
                .collect(Collectors.maxBy((p1,p2)->p1.compareTo(p2))).get();
        System.out.println(pup1);
    }

    @Test
    public void testCollectors(){
        int[] numbers = {5,7,8,9,12,4,6};
        ToIntFunction<Integer> intFun =e-> e;
       int sum = Arrays.stream(numbers)
               .boxed().max((c1, c2) -> c1.compareTo(c2))
               .get();
        System.out.println(sum);

        //get the names and put it in list
       Arrays.stream(lstPupil.stream()
                .reduce("",(p1, p2) -> p1+p2.getName()+",", String::join)
               .split(","))
               .collect(Collectors.toMap(Function.identity(), String::length))
               .entrySet().forEach(e-> System.out.println(e.getKey()+" ---> "+e.getValue()));
    }

    @Test
    public void testCollectionList(){
        int[] numbers = {5,7,8, 5,9,12,4,6};

        Arrays.stream(numbers)
                .boxed()
                .collect(Collectors.toCollection(LinkedList::new))
                .forEach(System.out::println);
    }

}
