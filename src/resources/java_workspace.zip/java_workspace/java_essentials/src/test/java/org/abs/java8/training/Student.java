package org.abs.java8.training;

public class Student {
    private String name;
    private int age;
    private int classRoom;
    private double marks;
    private long pincode;

    private Student(StudentBuilder studentBuilder) {
        this.name = studentBuilder.name;
        this.age = studentBuilder.age;
        this.classRoom = studentBuilder.classRoom;
        this.marks = studentBuilder.marks;
        this.pincode = studentBuilder.pincode;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", classRoom=" + classRoom +
                ", marks=" + marks +
                ", pincode=" + pincode +
                '}';
    }

    public String getName() {
        return this.name;
    }

    public int getAge() {
        return this.age;
    }

    public int getClassRoom() {
        return this.classRoom;
    }

    public double getMarks() {
        return this.marks;
    }

    public long getPincode() {
        return this.pincode;
    }


    public static class StudentBuilder{
        private String name;

        public StudentBuilder setName(String name) {
            this.name = name;
            return this;
        }

        public StudentBuilder setAge(int age) {
            this.age = age;
            return this;
        }

        public StudentBuilder setClassRoom(int classRoom) {
            this.classRoom = classRoom;
            return this;
        }

        public StudentBuilder setMarks(double marks) {
            this.marks = marks;
            return this;
        }

        public StudentBuilder setPincode(long pincode) {
            this.pincode = pincode;
            return this;
        }

        private int age;
        private int classRoom;
        private double marks;
        private long pincode;

        public Student build(){
            return  new Student(this);
        }


    }

}
