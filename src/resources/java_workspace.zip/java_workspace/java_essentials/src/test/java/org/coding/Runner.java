package org.coding;


import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

public class Runner {

    public boolean checkPalindrome(long n){
        long input = n;
               String op = "";
        while(n>=1){
            op+=n%10;
            n=n/10;
        }

        return Long.parseLong(op) == input;
    }

    public long reverseNumber(long n){
        String op = "";
        while(n>=1){
            op+=n%10;
            n=n/10;
        }

        return  Long.parseLong(op) ;
    }

    @Test
    public void numberMatcher(){
        String text = "The case has been created 23456";
        text = text.replaceAll("[^0-9]+", " ").trim();
        System.out.println( text.split(" ")[0]);
      // String grp=  Pattern.compile("\\d+").matcher(text).find()group();
        System.out.println(text);
    }

    @Test
    public void checkPlaindrome(){
       // 5, 44, 171, 4884 are palindromes and 43, 194, 4773
        long n = 89;
        int counterLength = 0;
        long sum = n;
        while(true){

           if( checkPalindrome(n)){
               break;
           }else{
               counterLength++;
             n = n + reverseNumber(n);
           }
        }
        System.out.println("Counter length "+counterLength);
        System.out.println(n);

    }




















    @Test
    public void multiThread(){
        List<String> lst = Arrays.asList("Hello", "Thanna", "asfs", "dsafsfd", "dasdasd");

        ExecutorService es = Executors.newFixedThreadPool(4);
        lst.forEach(e->{
            es.execute(new Runner1(e));
        });
        es.shutdown();
    }
}
 class Runner1 implements Runnable{

     public Runner1(String name) {
        // synchronized ( name) {
             this.name = name;
        // }
    }

    private String name;


    @Override
    public void run() {
       // String namse = Thread.currentThread().getName();
      //  System.out.println(namse);
        System.out.println("Thread: "+this.name);
    }
}
