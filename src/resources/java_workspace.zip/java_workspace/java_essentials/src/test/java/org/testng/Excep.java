package org.testng;

import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

public class Excep {
    static final String text = "strrnuytrrrrooooooooooiingg";

    @Test
    public void checkString(){

        char[] data = text.toCharArray();
        HashMap<String, Integer> map = new HashMap<>();

        for(int i=0; i< data.length; i++) {
            if (!map.containsKey(data[i] + "")) {
                map.putIfAbsent(data[i] + "", 1);
            } else {
                int val = map.get(data[i] + "");
                val++;
                map.put(data[i] + "", val);
            }
        }
            String xx ="";
            for(Map.Entry<String, Integer> each: map.entrySet()){
                int val = each.getValue();
                if(val>=4){
                    val=3;
                }
                for(int i=0; i<val; i++){
                    xx=xx+each.getKey();
                }
            }
        System.out.println(xx);

    }


}
