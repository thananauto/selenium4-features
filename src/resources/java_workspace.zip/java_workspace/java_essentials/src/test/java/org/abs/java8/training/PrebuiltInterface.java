package org.abs.java8.training;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.junit.Test;

import java.time.LocalDate;
import java.util.*;
import java.util.function.*;
import java.util.stream.Collectors;

public class PrebuiltInterface {

    @Test
    public void testFruitsPrice(){
        Map<String, Double> lstNames = new HashMap<>();
        lstNames.put("apple", 20.0);
        lstNames.put("blueberry", 40.0);

        Function<Map.Entry<String, Double>, Double> price = (k)-> k.getValue() *2;
        BiFunction<String, Double, Double> dbLprice = (k, v)-> v *2;
        Function<Double, Double> dble = (k)-> k *2;
        Function<String, Double> dble2 = (k)-> 13.0;

        //lstNames.values().stream().map(dble::apply).forEach(System.out::println);

       // lstNames.compute("apple", dbLprice);
        lstNames.computeIfAbsent("klori",dble2);
        lstNames.computeIfPresent("klori",dbLprice);
        lstNames.replaceAll(dbLprice);
        System.out.println(lstNames);
    }


    @Test
    public void  test_BiPredicate(){
        BiPredicate<String, String> mapItems = (k,v)-> k.contains(v);
        BiFunction<String, String, String> replaceName = (k, v)-> k+v;
        Function<Map.Entry<String, String>, String> item = (k)-> k.getValue();
        Map<String, String> lstNames = new HashMap<>();
        lstNames.put("firstname", "Thanan");
        lstNames.put("lastname", "Jayan");
        lstNames.entrySet().stream()
                .map(item)
                        .forEach(System.out::println);
                //.collect(Collectors.toMap(Function.identity(),v->v));
       // System.out.println(op);

    }

    @Test
    public void test_BiFunction(){
        BiFunction<Integer, Integer, Integer> addition = Integer::sum;
        BiFunction<Integer, Integer, Integer> subtraction = (s1, s2) -> s1-s2;
        BiFunction<Integer, Integer, Integer> multiplication = (s1, s2) -> s1*s2;
        Function<Integer, Integer> sqreRoot = x -> x*x;

       int op = addition.andThen(sqreRoot).apply(4,3);
        System.out.println(op);
    }

    @Test
    public void realSupplier(){
        Supplier<Integer> ran = () -> new Random().nextInt(100);
        Student[] student = { new Student("Than", 445),new Student("Than", 480),
                new Student("Than", 433),new Student("Than", 464),
                new Student("Than", ran.get())};

        Arrays.stream(student).forEach(System.out::println);
    }

    @Test
    public void testSupplier(){
        Supplier<LocalDate> sup = LocalDate::now;
        System.out.println(sup.get());

    }

    @Test
    public void testConsumer(){
        Consumer<String> cons = s -> System.out.println(s+" accept");
        Consumer<String> consAndThen = s -> System.out.println(s+" And Then");
        cons.andThen(consAndThen).andThen(cons).accept("This is consumer");
    }

    @Test
    public void testPredicate(){
        Predicate<String> pr = s -> s.length() >1;

        String ip = "Hello World..!";
        boolean result = pr.and(s-> s.length() > 0).test(ip);
        System.out.println(result);
    }



    @Test
    public void testPredicateRealExample(){
        Student[] student = { new Student("Than", 445),new Student("Than", 480),
                new Student("Than", 433),new Student("Than", 464) };

        Predicate<Student> stu = s ->s.getAge() > 450;
        //array way
         Student[] student2 = Arrays.stream(student)
                .filter(stu ).toArray(Student[]::new);

        //listway
        List<Student> lst = Arrays.asList(student).stream().filter(stu).collect(Collectors.toList());
       lst.forEach( System.out::println);
    }

    @Test
    public void testFunctionInterface(){
        Function<String, String> askQuestion = qs -> "Your question: "+qs;

        System.out.println( askQuestion.apply("What's your name?"));

        Function<Integer, Integer> square = integer -> integer*integer;
        Function<Integer, Integer> area = integer -> 2*integer;
        Function<Integer, Boolean> notnull = in -> in!=0;
        BiFunction<Integer,Integer, Integer> length = (a, b) -> 2*(a+b);
        int ip = 5;
        //played with numbers
        System.out.println("Square "+ square.andThen(e->e-1).andThen(e -> e%2).apply(ip));
        System.out.println("Area "+ area.andThen(e -> e%2).apply(ip));
        System.out.println("Rectangle "+ length.andThen(e -> e%2).apply(ip, ip));
        System.out.println("Chaining "+square.compose(area).andThen(notnull).apply(ip));

        //play with string
        Function<String, Integer> len = l -> l.length();
        Function<String, Boolean> noNull = t -> !t.isEmpty();
        Function<String, String> printString = s->s;

        String ip1 = "Thanan";

        System.out.println(printString.andThen(noNull).apply(ip1));

    }

    @AllArgsConstructor
    @Getter
    class Student{
        private String name;
        private int age;

    public String toString(){
        return "Name: "+this.name+" Age: "+this.age;
    }
    }
}
