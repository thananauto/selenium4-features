package org.java8.supporting;

public class Cat implements Animal{

    @Override
    public void run() {
        System.out.println("Running at 20 kmph");
    }
}
