package org.test.practise.anonymousclass;



import anonymous.Audi;
import anonymous.ICar;
import anonymous.ITyre;
import org.junit.Test;

public class AnonymousClassTest {

    @Test
    public void anonymous_test() {

        // single interface implementation
        ICar car = new Audi();
        car.speed();

        // anonymous inner class, it's very usefull for single method implementation
        ICar newCar = new ICar() {
            @Override
            public void speed() {
                System.out.println("This is ICar speed");
            }
        };
        newCar.speed();

        // lambda expression

        ICar  lamCar = () -> System.out.println("In lambda car");
        lamCar.speed();
        ITyre tyre = () ->  { return 5*2;};
        System.out.println(tyre.getTyreCount());


    }
}
