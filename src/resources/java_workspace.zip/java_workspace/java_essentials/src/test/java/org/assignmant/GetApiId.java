package org.assignmant;



import java.util.HashMap;
import org.testng.Assert;
import org.testng.annotations.*;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import io.restassured.response.Response;

public class GetApiId {

    // ExtentReport ext;
    @BeforeSuite
    public void initiateReport(){
        // ext = new Exte()

    }

    @AfterSuite
    public void tearDown(){
        //ext.flush()
        //ext.close()
    }

    @BeforeClass
    public void setUp(){
        RestAssured.baseURI ="https://reqres.in/";
    }

    @Test(priority=1)
    public void sendGetRequest() {

        Response response=RestAssured.given()
                .when()
                .get("api/users")
                .then()
                .extract()
                .response();

        String body=response.getBody().asString();
        System.out.println("Body of the code is "+body);

        int statusCode=response.getStatusCode();
        System.out.println("Status code is "+statusCode);
    }



    @Test(priority=2)
    public void sendPostLogin(){
        HashMap data=new HashMap();

        data.put("username", "emma.wong@reqres.in");
        data.put("email", "emma.wong@reqres.in");
        data.put("password", "emma");

        Response res=
                given()
                        .contentType("application/json")
                        .body(data)
                        .when()
                        .post("api/login")
                        .then()
                        .assertThat()
                        .statusCode(201)
                        .log().body().extract().response();



    }
    @Test(priority=3, description = "send post register")
    public void  sendPostRegister(){
        HashMap data=new HashMap();
        data.put("email", "eve.holt@reqres.in");
        data.put("username", "na");
        data.put("password", "pistol");
        Response response=RestAssured.given()
                .body(data)
                .when().post("api/register")
                .then()
                .extract().response();



        Assert.assertTrue(response.getStatusCode() == 400, "Code is not equal");

    }

    @Test(priority=4, description = "updated the user ID")
    public void putUserId(){
        HashMap data=new HashMap();
        data.put("id", 20);
        Response response=RestAssured.given()
                .body(data)
                .when().put("api/users/2")
                .then()
                .assertThat()
                .statusCode(200)
                .log().body()
                .extract().response();



    }
    @Test(priority=5)
    public  void deleteUserId() {
        HashMap data=new HashMap();

        Response response=RestAssured.given()
                .body(data)
                .when().delete("api/users/2")
                .then()
                .log().body()
                .extract().response();

        int statusCode=response.getStatusCode();
        System.out.println("Status code for delete user id is "+statusCode);
    }
}