package anonymous;


@FunctionalInterface
public interface ICar {

    public abstract void speed();


    default void engine(){
        System.out.println("Engine sound");
    }

    static void abs(){
        System.out.println("Anti brake system");
    }
}
