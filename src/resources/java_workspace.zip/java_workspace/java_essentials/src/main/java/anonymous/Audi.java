package anonymous;

public class Audi implements ICar{
    @Override
    public void speed() {
        System.out.println("Audi car is in good speed");
    }
}
