package org.test.practise.template;

import br.com.six2six.fixturefactory.Fixture;
import br.com.six2six.fixturefactory.Rule;
import br.com.six2six.fixturefactory.loader.TemplateLoader;
import org.test.practise.pojo.Address;
import org.test.practise.pojo.Employee;

import java.util.Arrays;

public class EmployeeTemplate implements TemplateLoader {
    @Override
    public void load() {
        Address address = Fixture.from(Address.class).gimme("address");
        Fixture.of(Employee.class).addTemplate("valid", new Rule(){{
            add("id", random(Integer.class, range(20, 100)));
            add("firstName", random("thanan", "jayan", "majni"));
            add("isFTE", random(true, false));
            add("address", random(new Address("kamaraj", "chennai"), address));
            add("roles", uniqueRandom(Arrays.asList("tester"), Arrays.asList("Manager")));
        }});

        Fixture.of(Employee.class).addTemplate("invalid", new Rule(){{
            add("id", random(Integer.class, range(1, 2)));
            add("firstName", random("thanan", "jayan", "majni"));
            add("isFTE", random(true, false));
            add("address", random(address));
            add("roles", uniqueRandom(Arrays.asList("tester"), Arrays.asList("Manager")));
        }});

        Fixture.of(Employee.class).addTemplate("invalidFirstName").inherits("valid", new Rule(){{
            add("firstName", random("than-an", "ja*yan", "ma-jn-i"));
        }});
    }
}
