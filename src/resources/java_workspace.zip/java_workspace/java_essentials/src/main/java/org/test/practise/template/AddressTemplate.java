package org.test.practise.template;

import br.com.six2six.fixturefactory.Fixture;
import br.com.six2six.fixturefactory.Rule;
import br.com.six2six.fixturefactory.loader.TemplateLoader;
import org.test.practise.pojo.Address;

public class AddressTemplate implements TemplateLoader {
    @Override
    public void load() {
        Fixture.of(Address.class).addTemplate("address", new Rule(){{
            add("street", random("kamaraj", "anna", "MGR"));
            add("city", random("mumbai", "delhi"));

        }});
    }
}
