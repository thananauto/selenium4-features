package org.test.practise.blocks;

public class Car {

    static {
        System.out.println("This is static block of Car ");
    }

    {
        System.out.println("Non static  block of car ");
    }

    public Car() {
        System.out.println("Car Constructor");
    }
}
