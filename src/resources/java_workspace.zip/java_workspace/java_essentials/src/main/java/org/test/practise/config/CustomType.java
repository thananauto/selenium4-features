package org.test.practise.config;

public class CustomType {

    private String text;
    public CustomType(String text) {
        this.text = text;
    }

    public String getText() {
        return text.startsWith("$") || text.equals("") ? "qa" : text;

    }



}
