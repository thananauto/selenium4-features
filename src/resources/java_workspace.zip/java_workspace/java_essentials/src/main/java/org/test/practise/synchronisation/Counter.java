package org.test.practise.synchronisation;

public class Counter {

    int count;

    public void incr(){
        count++;
    }
}
