package org.test.practise.pojo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;
import java.util.Map;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Employee {

    private int id;
    private  String firstName;
    private boolean isFTE;
    private Address address;
    private List<String> roles;


}
