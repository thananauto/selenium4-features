package org.test.practise.blocks;

public class Audi extends Car{

    public Audi() {
        System.out.println("Audi Constructor");
    }

    static {
        System.out.println("Static block of Audi");
    }

    {
        System.out.println("Non static block of Audi");
    }
}
