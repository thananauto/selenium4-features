package listners;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Car {

    @Test
    public void have_brake(){
        Assert.assertEquals(0,0);
    }

    @Test
    public void have_four_wheels(){
        Assert.assertEquals(0,0);

    }
    @Test
    public void have_light(){
        Assert.assertEquals(0,0);

    }
}
