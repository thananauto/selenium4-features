package org.test.practise.excelreader;

import com.creditdatamw.zerocell.annotation.Column;
import com.creditdatamw.zerocell.annotation.RowNumber;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@ToString
public class Person {
    @RowNumber
    private int rowNumber;

    @Column(index=0, name="S.No")
    private String sNo;

    @Column(index=1, name="Name")
    private String name;

    @Column(index=2, name="LoanNumber")
    private Long loanNumber;


    @Column(index=3, name="Age")
    private String age;


}
