package org.test.practise.config;

import org.aeonbits.owner.Config;


@Config.LoadPolicy(Config.LoadType.MERGE)
@Config.Sources({
        "system:properties",
        "system:env",
        "file:${user.dir}/src/test/resources/environ.properties"
})
public interface MultiEnvConfig extends Config {


    @DefaultValue("firefox")
    String browser();
    String env();

    @Key("${env}.db.username")
    String dbUserName();

    @Key("${env}.db.password")
    String dbPassword();

    @Key("test.create.cycle")
    @DefaultValue("qa")
    CustomType testCycle();

    @Key("tester")
    boolean tester();


}
