package org.test.practise.config;

public enum Browsers {
    CHROME("chrome"),
    FIREFOX("firefox"),
    SAFARI("safari");

    String brows;
    Browsers(String chrome) {
        this.brows = chrome;

    }

}
