package org.test.practise.config;

import org.aeonbits.owner.Config;
import org.test.practise.config.Browsers;

import java.util.List;

@Config.Sources("file:${user.dir}/src/test/resources/runner.properties")
public interface ConfigReader extends Config {

    Browsers browserName();
    Long timeOut();
    List<String> message();

    @DefaultValue("Good morning")
    String helloMsg();

    @Key("loveCoffee")
    String teaMsg();
}
