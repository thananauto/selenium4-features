package org.test.practise.excelreader;

import com.creditdatamw.zerocell.Reader;
import org.aeonbits.owner.Config;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class DataReader
{
    @Test(dataProvider = "testdata" )
    public void test(List<Person> personList){

        personList.forEach(System.out::println);
    }

    @DataProvider
    public static Object[] testdata(){

        return new Object[]{ Reader.of(Person.class)
                .from(new File(Objects.requireNonNull(DataReader.class.getClassLoader().getResource("person2.xlsx")).getFile()))
                .sheet("person")
                .list()};
    }
}
