package anonymous;

public interface ITyre {

    public int getTyreCount();

}
