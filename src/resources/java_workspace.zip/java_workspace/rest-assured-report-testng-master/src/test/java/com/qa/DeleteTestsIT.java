package com.qa;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.http.HttpStatus;
import org.testng.annotations.Test;
import qa.annotation.FrameworkAnnotation;
import tech.grasshopper.filter.ExtentRestAssuredFilter;

import static io.restassured.RestAssured.given;

public class DeleteTestsIT extends Base {

    @Test
    @FrameworkAnnotation(code = "204", category = "DELETE", suite = "Smoke")
    public void deleteUser(){
        String id = "3776023";
        RequestSpecification specification = given()
                .spec(reqSpec())
                .pathParam("id", id)
                .filter( new ExtentRestAssuredFilter());
       // //ExtentLogger.logRequest(specification);
        Response response = specification.delete("/public/v2/users/{id}");
       // //ExtentLogger.logResponse(response.asPrettyString());
        response.then()
                //.log()
                //.all()
                .spec(resSpec(HttpStatus.SC_NO_CONTENT));

    }
}
